#!/usr/bin/env python3
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy.stats import norm, t, wilcoxon
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from analysis.statistics import width_matched_source_cluster_bootstrap

def fit_lambda():
    d=pd.read_csv(ROOT/'data'/'scenario_level_fitting_inputs.csv')
    x=d['uncalibrated_scenario_width_gy'].to_numpy(float)
    target=1.9600
    low,high=1.0,1.25
    hist=[]
    for it in range(1,25):
        mid=(low+high)/2
        med=float(np.median(x*mid)); res=med-target
        hist.append((it,mid,med,res))
        if abs(res)<1e-4: return mid,hist
        if res<0: low=mid
        else: high=mid
    return mid,hist

def main():
    lam,hist=fit_lambda()
    print(f'width-match lambda={lam:.6f} -> {lam:.3f}; iterations={len(hist)}; residual={hist[-1][3]:+.6f} Gy')
    assert round(lam,3)==1.081
    d=pd.read_csv(ROOT/'data'/'source_pairs.csv')
    diff=(d['DispersionCalibrated_Coverage_0_1']-d['WidthMatched_Coverage_0_1']).astype(float)
    src=d.assign(_d=diff).groupby('Source_Anatomy_ID')['_d'].mean().to_numpy(float)
    mean=float(src.mean()); se=float(src.std(ddof=1)/np.sqrt(len(src)))
    p=float(norm.sf(mean/se)); p_t=float(t.sf(mean/se,df=len(src)-1)); p_w=float(wilcoxon(src,alternative='greater').pvalue)
    boot=width_matched_source_cluster_bootstrap(ROOT/'data'/'source_pairs.csv',seed=20240527,reps=5000)
    ci=np.quantile(boot,[.025,.975],method='linear')
    normal=(mean-1.96*se,mean+1.96*se)
    print(f'C-WM={mean*100:+.4f} pp; primary site-stratified source bootstrap 95% CI [{ci[0]*100:+.2f}, {ci[1]*100:+.2f}] pp')
    print(f'source-level normal approximation sensitivity 95% CI [{normal[0]*100:+.2f}, {normal[1]*100:+.2f}] pp; p={p:.6f}; t23 p={p_t:.4f}; Wilcoxon p={p_w:.4f}')
    assert int(d['Uncalibrated_Coverage_0_1'].sum())==345
    assert int(d['WidthMatched_Coverage_0_1'].sum())==367
    assert int(d['DispersionCalibrated_Coverage_0_1'].sum())==376
    assert abs(mean-0.02083333333333333)<1e-12
    assert np.allclose(ci,[0.0023148148,0.0416666667],atol=5e-10)
    assert abs(p-0.0290711991)<2e-9
if __name__=='__main__': main()

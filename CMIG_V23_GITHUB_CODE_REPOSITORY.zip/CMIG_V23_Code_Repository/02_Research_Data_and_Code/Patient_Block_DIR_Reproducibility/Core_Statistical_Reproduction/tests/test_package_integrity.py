import unittest
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

class PackageIntegrityTests(unittest.TestCase):
    def test_locked_fraction_structure(self):
        d = pd.read_csv(DATA / "locked_test_fractions.csv")
        self.assertEqual(len(d), 400)
        self.assertEqual(d["Patient_ID"].nunique(), 80)
        self.assertTrue((d.groupby("Patient_ID").size() == 5).all())
        self.assertEqual(d["Registration_ID"].nunique(), 400)

    def test_controlled_source_structure(self):
        d = pd.read_csv(DATA / "source_pairs.csv")
        self.assertEqual(len(d), 432)
        self.assertEqual(d["Source_Anatomy_ID"].nunique(), 24)
        self.assertTrue((d.groupby("Source_Anatomy_ID").size() == 18).all())
        self.assertEqual(d["Pair_ID"].nunique(), 432)

    def test_bootstrap_summary_counts(self):
        c = pd.read_csv(DATA / "clinical_bootstrap_replicates.csv")
        s = pd.read_csv(DATA / "source_bootstrap_replicates.csv")
        w = pd.read_csv(DATA / "width_matched_bootstrap_replicates.csv")
        self.assertEqual(len(c), 5000)
        self.assertEqual(len(s), 5000)
        self.assertEqual(len(w), 5000)

if __name__ == "__main__":
    unittest.main()

# Central 90% interval score

For a dose interval `[L,U]`, reference dose `y` and `alpha=0.10`, the score is `IS = (U-L) + (2/alpha)(L-y) I(y<L) + (2/alpha)(y-U) I(y>U)`. In-band reference values produce `IS=U-L`. The file `interval_score_inputs_432.csv` supplies paired endpoint-level interval bounds, references and scores. Execute `python recompute_interval_score.py` to verify the 432 scores and summary means (2.47 Gy uncalibrated, 2.31 Gy calibrated). These are derived endpoint data; this verification is not a native model rerun.

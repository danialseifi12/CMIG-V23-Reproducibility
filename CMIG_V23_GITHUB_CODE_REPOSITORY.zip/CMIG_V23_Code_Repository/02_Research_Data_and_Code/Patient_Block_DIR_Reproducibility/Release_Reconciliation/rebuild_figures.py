"""Regenerate current article artwork from its documented sources."""
from pathlib import Path
import subprocess,sys
if __name__=='__main__':
    subprocess.run([sys.executable,str(Path(__file__).with_name('figure_build_current.py')),*sys.argv[1:]],check=True)

# Intermediate replay assets

These supplied files reproduce a small two-convolution pooled-response model and historical endpoint WM generator. The original clinical model described in Supplementary Section 20 has a five-level encoder-decoder and a separate recorded checkpoint; this file is not substituted for that model.

01_model_checkpoint_metadata.json records this checkpoint's supplied identity and hash; the original record is retained. 01_model_definition_and_inference.py loads its state dictionary with weights_only=True. 04_replay_inputs_72_scenarios.npz supplies the coarse inputs. The legacy key reference_svf_mm is consumed directly as displacement in warp_dose; no velocity exponentiation or scaling-and-squaring occurs here. Components are x/y/z with z/y/x tensor spatial order. Its legacy linspace normalization and align_corners=False are preserved for matching archived summaries; do not treat them as a native clinical warp specification.

02_gate5_width_matched_generator_original.py fits lambda_width=1.0810546875 from 72 scenario widths, then applies wm = center + lambda_width × Local_Response_Gain × (u − center) + Center_Shift_Gy to each historical endpoint sample. The center is the midpoint of historical U P05/P95. verify_intermediate_replay.py executes the actual checkpoint and generator and compares saved summaries/response parameters and all 43,200 WM values. These historical absolute-dose centers are not assumed identical to the canonical score or final decision registry.

Native clinical images, original clinical model weights, full native-resolution stochastic SVF, QC and dose accumulation are restricted. Passing this replay is not an independent native clinical rerun or measurement-origin verification.

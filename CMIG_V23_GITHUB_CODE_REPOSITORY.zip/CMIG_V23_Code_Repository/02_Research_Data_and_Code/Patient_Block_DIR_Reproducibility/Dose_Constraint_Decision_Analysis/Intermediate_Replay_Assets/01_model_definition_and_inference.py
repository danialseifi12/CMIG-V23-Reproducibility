#!/usr/bin/env python3
"""Small intermediate response replay; not the original five-level clinical network.
The legacy input key reference_svf_mm is consumed as displacement, not velocity.
"""
from pathlib import Path
import argparse, csv
import numpy as np
import torch
torch.set_num_threads(4)
import torch.nn as nn
import torch.nn.functional as F

class PSVFDoseModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.image_encoder = nn.Sequential(
            nn.Conv3d(2, 4, kernel_size=3, padding=1),
            nn.Tanh(),
            nn.Conv3d(4, 8, kernel_size=3, padding=1),
            nn.Tanh(),
            nn.AdaptiveAvgPool3d(1),
        )
        self.disp_head = nn.Linear(8, 3)
        self.response_head = nn.Linear(12, 12)

    def forward(self, fixed, moving, response_features):
        x = torch.cat([fixed, moving], dim=1)
        z = self.image_encoder(x).flatten(1)
        global_disp_mm = self.disp_head(z)
        raw_response = self.response_head(response_features)
        return global_disp_mm, raw_response

def decode_local_response(raw):
    # Six endpoint-specific gains followed by six endpoint-specific center shifts.
    gain = 0.95 + 0.15 * torch.sigmoid(raw[:, :6])
    shift_gy = 3.5 * torch.tanh(raw[:, 6:])
    return gain, shift_gy

def warp_dose(source_dose, displacement_mm, global_disp_mm, spacing_mm=(8.0,8.0,8.0)):
    # Legacy displacement replay: no SVF exponentiation. Retain the original
    # linspace normalization and align_corners=False solely to match archived
    # summaries; this is not the native clinical transform implementation.
    n, _, d, h, w = source_dose.shape
    zz, yy, xx = torch.meshgrid(
        torch.linspace(-1,1,d,device=source_dose.device),
        torch.linspace(-1,1,h,device=source_dose.device),
        torch.linspace(-1,1,w,device=source_dose.device),
        indexing="ij"
    )
    grid = torch.stack([xx,yy,zz], dim=-1)[None].repeat(n,1,1,1,1)
    disp = displacement_mm.clone()
    disp[:,0] += global_disp_mm[:,0,None,None,None]
    disp[:,1] += global_disp_mm[:,1,None,None,None]
    disp[:,2] += global_disp_mm[:,2,None,None,None]
    # vector components x-y-z; tensor spatial order z-y-x
    grid[...,0] += 2.0 * disp[:,0] / max((w-1)*spacing_mm[2], 1e-6)
    grid[...,1] += 2.0 * disp[:,1] / max((h-1)*spacing_mm[1], 1e-6)
    grid[...,2] += 2.0 * disp[:,2] / max((d-1)*spacing_mm[0], 1e-6)
    return F.grid_sample(source_dose, grid, mode="bilinear", padding_mode="border", align_corners=False)

def run(checkpoint_path, input_npz, output_csv=None):
    ckpt = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    model = PSVFDoseModel()
    model.load_state_dict(ckpt["state_dict"])
    model.eval()

    a = np.load(input_npz)
    fixed = torch.from_numpy(a["fixed_image"]).float()[:,None]
    moving = torch.from_numpy(a["moving_image"]).float()[:,None]
    dose = torch.from_numpy(a["source_dose_gy"]).float()[:,None]
    svf = torch.from_numpy(a["reference_svf_mm"]).float()
    response_features = torch.from_numpy(a["response_features"]).float()

    with torch.no_grad():
        global_disp, raw = model(fixed, moving, response_features)
        gain, shift = decode_local_response(raw)
        warped = warp_dose(dose, svf, global_disp)

    out = {
        "scenario_ids": a["scenario_ids"].astype(str),
        "global_disp_mm": global_disp.numpy(),
        "local_response_gain": gain.numpy(),
        "center_shift_gy": shift.numpy(),
        "warped_dose_mean_gy": warped.mean(dim=(1,2,3,4)).numpy(),
        "warped_dose_sd_gy": warped.std(dim=(1,2,3,4)).numpy(),
    }
    if output_csv:
        with open(output_csv, "w", newline="", encoding="utf-8") as f:
            fields = ["Scenario_ID","Disp_X_mm","Disp_Y_mm","Disp_Z_mm",
                      "Warped_Dose_Mean_Gy","Warped_Dose_SD_Gy"]
            w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
            for i,s in enumerate(out["scenario_ids"]):
                w.writerow({
                    "Scenario_ID": s,
                    "Disp_X_mm": f"{out['global_disp_mm'][i,0]:.8f}",
                    "Disp_Y_mm": f"{out['global_disp_mm'][i,1]:.8f}",
                    "Disp_Z_mm": f"{out['global_disp_mm'][i,2]:.8f}",
                    "Warped_Dose_Mean_Gy": f"{out['warped_dose_mean_gy'][i]:.8f}",
                    "Warped_Dose_SD_Gy": f"{out['warped_dose_sd_gy'][i]:.8f}",
                })
    return out

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", default="01_model_checkpoint.pt")
    p.add_argument("--inputs", default="04_replay_inputs_72_scenarios.npz")
    p.add_argument("--output", default="01_inference_replay_summary_72.csv")
    args = p.parse_args()
    run(args.checkpoint, args.inputs, args.output)

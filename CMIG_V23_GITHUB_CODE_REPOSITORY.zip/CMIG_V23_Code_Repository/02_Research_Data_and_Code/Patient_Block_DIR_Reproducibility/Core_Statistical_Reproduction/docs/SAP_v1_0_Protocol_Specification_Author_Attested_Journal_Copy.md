Statistical Analysis Plan (SAP) v1.0

Study-team-confirmed journal copy with 2026 reporting addendum

Protocol freeze: 05 May 2024 | First governed locked-test outcome access: 20 June 2024

Document status: The submitting author confirms that this journal copy reflects the study-team SAP specification, governance dates, and retained study record. This current confirmation is separate from the historical protocol chronology. The source-control identifier is retained as provenance metadata. The document records study-team confirmation and does not reproduce individual handwritten or digital signatures.

1. Study governance, objectives, and blinding safeguards

This SAP establishes the ante-hoc decision rules, statistical hypotheses, sample sizes, and confirmatory testing sequence for evaluating split conformal deformable image registration (DIR) uncertainty.

1.1 Blinding and governance sequence

Prespecification barrier (05 May 2024): hypotheses, decision margins, stopping rules, and statistical testing methods frozen.

Calibration parameter freeze (27–29 May 2024): disease-site conformal factors, covariance shrinkage/ridge parameters, and triage threshold τ=0.50 locked using calibration-cohort observations only.

Outcome blinding barrier: locked-validation ground-truth outcomes remained inaccessible until the calibration objects and analysis implementation were finalized; first governed access is recorded as 20 June 2024.

2. Cohort partitioning and sample size

Calibration cohort: 40 patients (20 prostate, 20 head-and-neck), 200 fractions across M10, M30, M50, M70, and M90.

Locked validation cohort: 80 patients (40 prostate, 40 head-and-neck), 400 fractions across the same five milestones.

Controlled-reference arm: 24 source anatomies (12 per site), three deformation-severity levels, 72 sequences, and 432 paired dose endpoints.

3. Ordered confirmatory testing hierarchy (Gates 1–5)

Testing follows a fixed-sequence gatekeeper architecture. Each directional confirmatory gate uses one-sided α=0.05; conventional two-sided 95% confidence intervals are reported where applicable. A later gate is interpreted confirmatorily only after the preceding gate criterion is met.

Gate 1 — Mid-treatment simultaneous geometric coverage

All prespecified landmarks inside the patient-specific 95% conformal ellipsoid at M50; H0: πM50≤87.5% vs H1: πM50>87.5%; exact one-sided binomial test in N=80; success boundary ≥76/80.

Gate 2 — Longitudinal stability

Site-adjusted binomial-logit model of noncoverage per +20% treatment progression. Primary criterion: model-based one-sided upper 95% OR bound <1.85; patient-cluster sandwich inference is the prespecified robustness sensitivity.

Gate 3 — Human-review prioritization

Frozen Flag=I(Triage_Score≥0.50). Patient-clustered confirmatory criteria: sensitivity >75% and NPV >95%, each evaluated one-sided at α=0.05.

Gate 4 — Controlled-reference dose containment vs uncalibrated

Paired source-anatomy analysis over 432 endpoints; superiority Δ(C−U)>0 at one-sided α=0.05.

Gate 5 — Superiority over pooled-median width-matched benchmark

Global truth-independent pooled-width control with λwidth≈1.081; superiority Δ(C−WM)>0 and noninferiority margin −2.0 percentage points, each evaluated one-sided at α=0.05.

4. Reproducibility implementation for journal review

The reviewer-access derived archive retains 400 clinical rows, 432 endpoint label rows, source-bootstrap summaries, 4,000 landmarks, modality linkage, 72 pooled-width fitting inputs, K-sensitivity and dose/surface tables. The pooled lambda_width is reproducible without reference-dose truth. The study team confirms the corrected scenario mapping, outcome-blind comparator construction, and the distinct NPZ/PyTorch model-asset roles and relationships. Full native image-to-dose execution is outside the released archive. The implemented C−WM bootstrap resamples fixed coverage labels by source anatomy without refitting lambda_width or regenerating comparator endpoints; Gate 5 is reported conditionally.

5. Study-team confirmation for journal submission

The submitting author confirms the accuracy of this SAP specification and its recorded governance dates on behalf of the study team. This confirmation is documented in the current journal copy; no individual signature or historical signing date is inferred. Institutional source records remain the provenance basis.

2026 journal-package provenance addendum (NOT part of the historical SAP)

2026 addendum (not part of the historical SAP): The submitting author confirmed the outstanding study-verification items on 2 October 2026. This is the current confirmation date, not a change to the historical SAP or execution dates. The study team confirms the corrected 72-row scenario mapping, comparator-generation provenance, and relationships of the distinct endpoint-table NPZ, coarse PyTorch replay, and native model. Numerical widths, endpoint labels, fitted lambda and outcomes are unchanged. The C−WM containment bootstrap was checked directly against its implementation and all 5000 archived replicates: it resamples fixed source-level coverage differences without refitting lambda_width or regenerating comparator endpoints. Separate retained width-coefficient replicates are not inputs to that bootstrap. Gate 5 remains a conditional descriptive analysis under this implementation.

Document identifier | SAP-DIR-CONFORMAL-2024-V1.0
Institutional ethics protocol | IR.TUMS.IKHC.REC.1401.098 (study-team-confirmed; consistent with the main manuscript)
Algorithmic/calibration freeze window | 27–29 May 2024
Recorded source-control commit identifier | 7a4d9f2c81e3a985d10b7410fc6b29ef (author-attested provenance metadata; not used as sole timestamp proof)

import unittest
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

class CanonicalSourcePairsLockTests(unittest.TestCase):
    def test_reader_facing_432_view_is_exact_lossless_projection(self):
        s = pd.read_csv(DATA / "source_pairs.csv")
        expected = pd.DataFrame({
            "pair_id": s["Pair_ID"],
            "source_anatomy": s["Source_Anatomy_ID"],
            "anatomical_site": s["Site"],
            "severity": s["Severity"],
            "dose_endpoint": s["Endpoint"],
            "contained_uncalibrated": s["Uncalibrated_Coverage_0_1"],
            "contained_width_matched": s["WidthMatched_Coverage_0_1"],
            "contained_dispersion_calibrated": s["DispersionCalibrated_Coverage_0_1"],
            "width_uncalibrated_gy": s["Uncalibrated_Width"],
            "width_dispersion_calibrated_gy": s["DispersionCalibrated_Width"],
            "interval_score_uncalibrated": s["Uncalibrated_Interval_Score"],
            "interval_score_dispersion_calibrated": s["DispersionCalibrated_Interval_Score"],
        })
        observed = pd.read_csv(DATA / "controlled_reference_endpoints_432_canonical.csv")
        pd.testing.assert_frame_equal(observed, expected, check_exact=True)

    def test_non_authoritative_v2_endpoint_export_is_absent(self):
        self.assertFalse((DATA / "verified_pairwise_endpoints_432.csv").exists())

if __name__ == "__main__":
    unittest.main()

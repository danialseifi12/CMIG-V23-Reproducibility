#!/usr/bin/env python3
from __future__ import annotations
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np

def main() -> None:
    root = Path(__file__).resolve().parent
    path = root / "endpoint_scenarios_432x100_both_methods.csv"
    groups = defaultdict(list)
    meta = {}
    with path.open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            key=(r["Pair_ID"],r["Method"])
            groups[key].append(float(r["Mapped_Dose_Gy"]))
            meta[key]=(float(r["Stored_P05_Gy"]),float(r["Stored_P95_Gy"]))
    assert len(groups) == 864
    max_p05=max_p95=0.0
    for key,vals in groups.items():
        assert len(vals)==100
        q05,q95=np.percentile(np.asarray(vals),[5,95],method="linear")
        p05,p95=meta[key]
        max_p05=max(max_p05,abs(q05-p05))
        max_p95=max(max_p95,abs(q95-p95))
    assert max_p05 < 2e-8 and max_p95 < 2e-8
    print(f"endpoint-method groups={len(groups)}")
    print(f"scenario rows={sum(len(v) for v in groups.values())}")
    print(f"max_abs_P05_replay_error={max_p05:.3e} Gy")
    print(f"max_abs_P95_replay_error={max_p95:.3e} Gy")
    print("percentile_method=NumPy linear")

if __name__ == "__main__":
    main()

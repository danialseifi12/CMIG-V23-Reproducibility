"""Cross-file scientific checks and reproducible secondary release calculations.
Does not modify input tables or regenerate native imaging/model outputs.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy import stats
R=Path(__file__).resolve().parents[1];P=R.parents[1];D=R/'Core_Statistical_Reproduction/data';V=R/'Release_Reconciliation'
fr=pd.read_csv(D/'locked_test_fractions_enriched.csv');frozen=pd.read_csv(D/'locked_test_fractions.csv');lm=pd.read_csv(D/'landmark_level_containment_and_tre.csv');log=pd.read_csv(D/'triage_feature_provenance_logs.csv');z=json.loads((V/'release_reconciliation_results.json').read_text())
checks=[]
def check(name,condition,detail=''):
    checks.append({'check':name,'passed':bool(condition),'detail':detail})
    if not condition:raise AssertionError(name+' '+str(detail))
key=['Patient_ID','Fraction_ID'];j=fr.merge(frozen,on=key,validate='one_to_one',suffixes=('_enriched','_frozen'))
for col in ['A95_mm','f_high_0_1','Triage_Score','Triage_Positive_0_1','True_Failure_0_1','Coverage_0_1']:
    check('enriched_frozen_'+col,np.allclose(j[col+'_enriched'],j[col+'_frozen'],atol=1e-9,rtol=0))
j=fr.merge(log,left_on=key,right_on=['patient_id','milestone'],validate='one_to_one')
for a,b in [('A95_mm','raw_a95_mm'),('f_high_0_1','f_high_severity'),('Triage_Score','triage_score'),('Triage_Positive_0_1','review_flag')]:check('provenance_'+a,np.allclose(j[a],j[b],atol=1e-9,rtol=0))
check('A95_alias',np.allclose(fr.A95_mm,fr.a95_mask_mm,atol=1e-9,rtol=0))
h=np.where(fr.Site.eq('Prostate'),4.5,5.4);eps=2/(fr.Review_Mask_cm3/.008)
check('quantile_tail_necessary_conditions',not np.any(((fr.A95_mm<h)&(fr.f_high_0_1>.05+eps))|((fr.A95_mm>h)&(fr.f_high_0_1<.05-eps))))
rule=(fr.A95_mm>=np.where(fr.Site.eq('Prostate'),4.2,5.05))|(fr.f_high_0_1>=np.where(fr.Site.eq('Prostate'),.18,.20))
check('frozen_rule_all_rows',np.array_equal(rule.astype(int),fr.Triage_Positive_0_1.astype(int)))
mean=lm.groupby(['patient_id','milestone']).tre_mm.mean();actual=pd.MultiIndex.from_frame(fr[key]).map(mean).to_numpy();check('fraction_TRE_mean',np.allclose(actual,fr.tre_mean_mm,atol=1e-12,rtol=0))
inside=lm.groupby(['patient_id','milestone']).inside_conformal_ellipsoid.min();check('fraction_all_landmarks_event',np.array_equal(pd.MultiIndex.from_frame(fr[key]).map(inside).to_numpy(),fr.Coverage_0_1.to_numpy()))
catalog=pd.read_csv(D/'landmark_atlas.csv')
for site,group in lm.groupby('anatomical_site'):
    a=catalog[catalog.Site.eq(site.replace('Head-and-Neck','Head-and-neck'))]
    pairs=set(map(tuple,group[['landmark_id','landmark_name']].drop_duplicates().to_numpy()));cpairs=set(map(tuple,a[['Export_Landmark_ID','Landmark_Name']].to_numpy()))
    check('named_catalog_'+site,pairs==cpairs)
check('undefined_marginal_flag_excluded','Marginal_Inclusion_Flag' not in lm.columns)

cal=pd.read_csv(P/'02_Reproducibility_Package/Calibration_40_Patient_Block_Scores.csv');rep=pd.read_csv(V/'calibration_bootstrap_5000_per_site.csv')
for site,a in cal.groupby('Disease_Site'):
    q=a.Max_Mahalanobis_Q.to_numpy();rng=np.random.default_rng(20261020);r=np.sqrt(rng.choice(q,size=(5000,20),replace=True).max(axis=1));stored=rep.loc[rep.site.eq(site),'r_sim'].to_numpy();c=z['calibration'][site]
    check('calibration_replicates_'+site,np.allclose(r,stored,atol=1e-12,rtol=0))
    cv=100*r.std(ddof=1)/r.mean();check('calibration_CV_'+site,abs(cv-c['CV_pct'])<1e-10)
    # The released CSV reports exact-distribution CV rounded to two decimals.
    sq=np.sort(q);prob=(np.arange(1,21)/20)**20-(np.arange(20)/20)**20
    er=np.dot(prob,np.sqrt(sq));sd=np.sqrt(np.dot(prob,(np.sqrt(sq)-er)**2));exact_cv=100*sd/er
    check('calibration_exact_CV_'+site,abs(exact_cv-c['exact_population_CV_pct'])<1e-10)
    check('calibration_CSV_exact_CV_'+site,np.allclose(a.Bootstrap_Radius_CV_pct,exact_cv,atol=0.005,rtol=0))
    check('calibration_unique_patient_scores_'+site,len(np.unique(q))==20)
    check('calibration_locked_threshold_'+site,abs(q.max()-a.Selected_Site_Q.iloc[0])<1e-10)
    check('calibration_radius_by_patient_'+site,np.allclose(a.Radius_r,np.sqrt(q),atol=9e-7,rtol=0))
    check('calibration_theoretical_support_'+site,abs(a.Bootstrap_Range_Min_r.iloc[0]-np.sqrt(sq[0]))<0.001)

x=lm.largest_semi_axis_mm.to_numpy();y=lm.tre_mm.to_numpy();event=y>3;pos=int(event.sum());neg=len(y)-pos
rho=float(stats.spearmanr(x,y).statistic);auc=float((stats.rankdata(x)[event].sum()-pos*(pos+1)/2)/(pos*neg))
order=np.argsort(-x,kind='stable');ys=event[order];xs=x[order];end=np.r_[np.flatnonzero(np.diff(xs)!=0),len(xs)-1];tp=np.cumsum(ys)[end];precision=tp/(end+1);recall=tp/pos;ap=float(np.sum(np.diff(np.r_[0,recall])*precision))
for k,a in [('spearman_rho',rho),('AUROC',auc),('average_precision',ap)]:check('descriptive_point_'+k,abs(a-z['landmark_descriptive'][k]['point'])<1e-12)
bs=pd.read_csv(V/'generic_landmark_scalar_bootstrap_5000.csv')
for k in ['spearman_rho','AUROC','average_precision']:
    ci=np.nanquantile(bs[k],[.025,.975]);check('descriptive_CI_'+k,np.allclose(ci,z['landmark_descriptive'][k]['CI95'],atol=1e-12,rtol=0))
check('bootstrap_valid_binary_replicates',int(bs.AUROC.notna().sum())==4979)
check('outcomes_remain_primary',(int(fr.Triage_Positive_0_1.sum())==126 and int(fr.True_Failure_0_1.sum())==53 and int(fr.loc[fr.Fraction_ID.eq('M50'),'Coverage_0_1'].sum())==76))

result={'all_passed':all(c['passed'] for c in checks),'checks':checks,'scope':'Released derived-data numerical consistency. Publication files are not included or read.'}
(V/'release_consistency_report.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'PASS derived-data consistency: {len(checks)}/{len(checks)} checks; 400 fractions, 4000 landmarks, 10000 calibration replicates.')

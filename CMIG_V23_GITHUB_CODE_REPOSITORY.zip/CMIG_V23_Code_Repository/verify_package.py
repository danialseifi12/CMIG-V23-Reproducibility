#!/usr/bin/env python3
"""Check the delivery snapshot, or immutable analysis sources during a rerun."""
from pathlib import Path
import csv,hashlib,argparse
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--static',action='store_true');a=p.parse_args()
base=ROOT/'02_Research_Data_and_Code/Patient_Block_DIR_Reproducibility' if a.static else ROOT
manifest=base/'STATIC_FILE_SHA256.csv' if a.static else base/'CHECKSUMS.csv'
bad=[];n=0
for row in csv.DictReader(manifest.open()):
    rel=row.get('File',row.get('Relative_Path'));q=(base/rel).resolve()
    if not q.is_relative_to(base.resolve()):raise ValueError('Unsafe manifest path')
    if not q.is_file() or hashlib.sha256(q.read_bytes()).hexdigest()!=row['SHA256']:bad.append(rel)
    n+=1
if bad:raise SystemExit('FAIL checksums: '+', '.join(bad))
print('PASS SHA-256 integrity:',n,'immutable sources' if a.static else 'delivered files')

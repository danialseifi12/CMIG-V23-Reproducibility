# Finalized width-matched allocation and fit

`data/source_pairs.csv` is the source-of-truth allocation for the finalized 432 endpoint-level C-WM inference. It gives C=376/432 and WM=367/432, with joint states C1/WM1=357, C1/WM0=19, C0/WM1=10, C0/WM0=46. The dedicated disease-site-stratified source-anatomy bootstrap is independently regenerated from these rows and reproduces the reported +2.08 percentage-point contrast and 95% percentile CI of +0.23 to +4.17 percentage points.

The width-scale fit is a separate, now executable layer. `data/scenario_level_fitting_inputs.csv` contains 72 scenario-level uncalibrated widths and the pooled calibrated target. `scripts/width_matching_fit.py` performs truth-independent bisection and reproduces `lambda_width≈1.081` without controlled-reference truth outcomes.

The controlling statistical inputs are the canonical `source_pairs.csv` allocation and the executable 72-scenario pooled-width fit. The C−WM comparison is a conditional fixed-label benchmark.


Current clarification: C−WM containment inference uses fixed archived labels. The separately retained width-coefficient replicate summaries are not inputs to this bootstrap. Comparator provenance is confirmed by the study team; see the archive-level source index for verification scope and limitations.

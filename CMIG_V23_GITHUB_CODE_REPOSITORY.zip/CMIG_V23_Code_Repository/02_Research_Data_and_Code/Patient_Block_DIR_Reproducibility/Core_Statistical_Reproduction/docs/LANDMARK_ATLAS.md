# Released landmark catalog

data/landmark_atlas.csv lists the actual 8 prostate and 12 head-and-neck landmark names present in data/landmark_level_containment_and_tre.csv. Catalog IDs P-LM01 to P-LM08 and H-LM01 to H-LM12 map to the within-site Export_Landmark_ID values. The corresponding editable roster is Supplementary Table S40.

Placement_Rule identifies the paired observer-reference point by the name in the institutional record. Detailed spatial placement instructions and original paired coordinates remain restricted; this derived catalog is not a replacement clinical observer-training atlas. Visibility and exclusion fields retain the shared QC rules. No invented coordinates or substituted anatomical points are supplied.

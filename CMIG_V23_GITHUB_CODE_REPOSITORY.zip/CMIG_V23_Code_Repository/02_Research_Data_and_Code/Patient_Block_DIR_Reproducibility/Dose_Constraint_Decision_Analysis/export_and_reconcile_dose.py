#!/usr/bin/env python3
import re
from pathlib import Path
import numpy as np,pandas as pd
HERE=Path(__file__).resolve().parent;REPRO=HERE.parent;UP=HERE/'Intermediate_Replay_Assets'
sp=pd.read_csv(REPRO/'Core_Statistical_Reproduction'/'data'/'source_pairs.csv')
isi=pd.read_csv(REPRO/'Analysis_Specific_Verification'/'Interval_Score'/'interval_score_inputs_432.csv')
mp=pd.read_csv(REPRO/'Analysis_Specific_Verification'/'Endpoint_Percentile_Replay'/'endpoint_id_mapping_432.csv')
old=pd.read_csv(UP/'Controlled_432_PreSwap_Original.csv');fin=pd.read_csv(HERE/'Controlled_432.csv')
npz=np.load(UP/'02_uncalibrated_ensemble_432x100.npz')
u05,u95=np.percentile(npz['uncalibrated_dose_gy'],[5,95],axis=1,method='linear')
assert np.max(np.abs((u95-u05)-sp['Uncalibrated_Width']))<3e-14
rows=[];sw=[]
for i in range(432):
 pid=f'PAIR_{i+1:04d}';m=re.search(r'(PAIR_\d{4})',str(fin.loc[i,'Notes']))
 locked=m.group(1) if m else pid;j=int(locked.split('_')[1])-1
 shift=0.0 if i==j else (-2.0 if i%6==0 else +2.0)
 for col in ['Ref_MappedDose_Gy','Nominal_MappedDose_Gy','Uncal_P05_Gy','Uncal_P95_Gy','Cal_P05_Gy','Cal_P95_Gy']:
  assert abs(fin.loc[i,col]-(old.loc[j,col]+shift))<1e-9,(i,col)
 row={'Pair_ID':pid,'Row_Index_0Based':i,'Source_Anatomy_ID':mp.loc[i,'Source_Anatomy_ID'],'Scenario_ID':mp.loc[i,'Scenario_ID'],'Disease_Site':fin.loc[i,'Disease_Site'],'Severity':isi.loc[i,'Severity'],'Structure':mp.loc[i,'Structure'],'DVH_Endpoint':mp.loc[i,'DVH_Endpoint'],'Methods_Covered':'U (Uncalibrated) & C (DispersionCalibrated)','Score_Primary_Run_ID':'PSVF_LOCKED_20240529_SCORE_432x100','Score_Primary_NPZ':'Intermediate_Replay_Assets/02_uncalibrated_ensemble_432x100.npz','Score_Replay_CSV':'Analysis_Specific_Verification/Endpoint_Percentile_Replay/endpoint_scenarios_432x100_both_methods.csv','Score_Table_CSV':'Analysis_Specific_Verification/Interval_Score/interval_score_inputs_432.csv','Score_Reference_Dose_Gy':isi.loc[i,'Reference_Dose_Gy'],'Score_Uncal_P05_Gy':isi.loc[i,'Uncal_P05_Gy'],'Score_Uncal_P95_Gy':isi.loc[i,'Uncal_P95_Gy'],'Score_Cal_P05_Gy':isi.loc[i,'Cal_P05_Gy'],'Score_Cal_P95_Gy':isi.loc[i,'Cal_P95_Gy'],'Score_Uncal_IS90_Gy':isi.loc[i,'Uncal_Interval_Score_Gy'],'Score_Cal_IS90_Gy':isi.loc[i,'Cal_Interval_Score_Gy'],'Decision_Primary_Run_ID':'PSVF_LOCKED_20240529_DECISION_EXT432','Decision_PreSwap_Source_CSV':'Intermediate_Replay_Assets/Controlled_432_PreSwap_Original.csv','Decision_PreSwap_Row_0Based':j,'Decision_Locked_Pair_ID_in_Notes':locked,'Decision_D98_D95_Reconciliation_Shift_Gy':shift,'Decision_Final_Row_0Based':i,'Decision_Constraint_ID':fin.loc[i,'Constraint_ID'],'Decision_Limit_Gy':fin.loc[i,'Limit_Gy'],'Decision_PreSwap_Ref_Gy':old.loc[j,'Ref_MappedDose_Gy'],'Decision_Final_Ref_Gy':fin.loc[i,'Ref_MappedDose_Gy'],'Decision_Final_Uncal_P05_Gy':fin.loc[i,'Uncal_P05_Gy'],'Decision_Final_Uncal_P95_Gy':fin.loc[i,'Uncal_P95_Gy'],'Decision_Final_Cal_P05_Gy':fin.loc[i,'Cal_P05_Gy'],'Decision_Final_Cal_P95_Gy':fin.loc[i,'Cal_P95_Gy'],'Decision_Reference_Status':fin.loc[i,'Reference_Status'],'Decision_Uncal_Class':fin.loc[i,'Uncal_Decision'],'Decision_Cal_Class':fin.loc[i,'Cal_Decision'],'Locked_Uncal_Width_Diff_Gy':abs(sp.loc[j,'Uncalibrated_Width']-(fin.loc[i,'Uncal_P95_Gy']-fin.loc[i,'Uncal_P05_Gy'])),'Locked_Cal_Width_Diff_Gy':abs(sp.loc[j,'DispersionCalibrated_Width']-(fin.loc[i,'Cal_P95_Gy']-fin.loc[i,'Cal_P05_Gy'])),'Absolute_Center_Offset_Decision_minus_Score_Gy':fin.loc[i,'Ref_MappedDose_Gy']-isi.loc[i,'Reference_Dose_Gy']}
 rows.append(row)
 if i!=j:sw.append(row)
pd.DataFrame(rows).to_csv(HERE/'dose_source_to_analysis_crosswalk.csv',index=False)
pd.DataFrame(sw).to_csv(HERE/'reconciliation_13_swapped_d98_d95_pairs.csv',index=False)
print('PASS export_and_reconcile_dose.py: 432 endpoints, swapped',len(sw),'rows; max width mismatch',max(r['Locked_Uncal_Width_Diff_Gy'] for r in rows))

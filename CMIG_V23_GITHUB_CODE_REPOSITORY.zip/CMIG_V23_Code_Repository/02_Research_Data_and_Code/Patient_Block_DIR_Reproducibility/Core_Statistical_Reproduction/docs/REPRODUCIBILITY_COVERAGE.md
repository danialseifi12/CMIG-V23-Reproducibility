# Reproducibility coverage

| Analysis component | Released evidence | Reproducibility level |
|---|---|---|
| Gate 1 | Frozen 400-row locked-test source and code | Direct derived-data/statistical reconstruction of the M50 event |
| Gate 2 noncoverage | Frozen fraction rows and GLM/cluster code | Direct reconstruction of model-based and patient-cluster noncoverage inference |
| Gate 3 | Frozen scores/labels, bootstrap rows and feature logs | Counts and reported cluster inference; original image-level feature extraction/score normalization is not distributed |
| Triage AUROC/AUPRC | Frozen continuous scores and metric code | Recalculation for the composite failure outcome |
| Fraction-level modality | Enriched 400-row linkage | Denominator and coverage reconstruction; distinct from primary course modality |
| Landmark containment/TRE | 4,000 landmark rows | Direct containment and descriptive exported-scalar/TRE analyses, with released patient-bootstrap replay; not historical final-conformal discrimination |
| Adjusted longitudinal TRE/volume | Final investigator-supplied analysis table, formulas and complete refit output | Numerical reconstruction; TRE t79 Holm p=0.0033, volume p<0.0001; covariate acquisition is investigator-attested |
| Controlled endpoint C−U | Canonical 432 endpoint rows and bootstrap tables/code | Derived-data containment and interval-score reconstruction, with source-level inference |
| Conditional C−WM | Fixed 432 endpoint coverage labels and saved resamples/code | Conditional label-based reconstruction; Gate 5 itself does not regenerate intervals or propagate width-refit uncertainty; a separate historical WM generator/array check is included |
| Width-matching scale fit | 72 scenario widths and bisection code | Reconstructs pooled-median fit, lambda≈1.081; the fit is approximate and does not establish endpoint-level width equality |
| K sensitivity | 120 endpoint rows and retained repeat-level CV summaries | Containment/agreement counts are recalculated; repeat-level width CV uses retained summaries |
| Clinical dose crossings | 78 evaluation rows | Coded crossing counts and selected width summaries; not every patient-by-structure distribution in Table 5 |
| Surface correspondence | Six aggregate structure rows, 299,100 points | Point-count-weighted mean of structure-level correlations; no pooled pointwise correlation or reconstructed CI |
| U/C endpoint percentiles | 86,400 endpoint-wise sample values | Marginal percentile replay; indices 1–100 are local to each endpoint and method |
| Decision-dose extension | Controlled_432.csv and constraint registry | Internally matched limit-rule replay in a separate absolute-dose layer; physical cross-layer lineage is not independently established |
| Ten retained trace arrays | Selected stored-array workbook | Stored percentiles/array consistency with reconciliation documented; not original native execution or independent source-level validation |
| Image-level DIR/SVF and dose execution | Restricted assets not distributed | Not reproducible from the released archive |

| Historical intermediate replay | Small checkpoint, coarse inputs, response parameters and U/WM NPZ arrays | Actual Torch response replay and regeneration of 43,200 WM values; distinct from original clinical inference |

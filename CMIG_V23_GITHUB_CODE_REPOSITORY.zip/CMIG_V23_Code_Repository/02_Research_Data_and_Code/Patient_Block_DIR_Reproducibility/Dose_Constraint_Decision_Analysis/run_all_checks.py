#!/usr/bin/env python3
"""Run the two controlled-reference supplementary analysis checks and validate key expected outputs."""
from pathlib import Path
import json, subprocess, sys, math
HERE = Path(__file__).resolve().parent
for script in ("recompute_controlled_decisions.py", "verify_original_model_traces.py"):
    print(f"Running {script} ...", flush=True)
    subprocess.run([sys.executable, str(HERE / script)], cwd=HERE, check=True)
summary=json.loads((HERE/'controlled_decision_report.json').read_text(encoding='utf-8'))
trace=json.loads((HERE/'original_trace_verification_report.json').read_text(encoding='utf-8'))
c=summary['counts']
expected={'Uncal_FalseSafe':30,'Cal_FalseSafe':8,'Uncal_ContainsTruth':345,'Cal_ContainsTruth':376,
          'Uncal_NON_SAFE':207,'Cal_NON_SAFE':308,'Uncal_Uncertain':139,'Cal_Uncertain':218,
          'Resolved_FalseSafe':24,'New_FalseSafe':2}
assert summary['n_endpoints']==432 and summary['n_sources']==24
assert all(c[k]==v for k,v in expected.items()),f"Count mismatch: {c}"
assert math.isclose(summary['source_signflip']['exact_two_sided_p'],0.125,rel_tol=0,abs_tol=1e-12)
assert trace['n_selected_endpoints']==10 and trace['independent_sources_represented']==4
assert trace['all_40_bounds_within_1e-8_Gy'] and trace['max_abs_error_Gy']<1e-8
print('PASS: 432-endpoint statistical results and 10 original scenario-output traces verified.')

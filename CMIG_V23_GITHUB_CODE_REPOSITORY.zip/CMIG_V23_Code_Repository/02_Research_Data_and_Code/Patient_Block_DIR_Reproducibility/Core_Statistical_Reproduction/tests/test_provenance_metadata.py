import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT / "config" / "analysis_config.json").read_text(encoding="utf-8"))

class ProvenanceMetadataTests(unittest.TestCase):
    def test_governance_timeline(self):
        g = CFG["governance_timeline"]
        self.assertEqual(g["sap_v1_finalized"], "2024-05-05")
        self.assertEqual(g["patient_partition_and_analysis_freeze_completed"], "2024-05-27")
        self.assertEqual(g["final_locked_analysis_objects_and_deterministic_seeds_frozen"], "2024-05-27 to 2024-05-29")
        self.assertEqual(g["locked_test_outcomes_first_accessed"], "2024-06-20")
        self.assertEqual(g["confirmatory_gates_1_to_5_executed"], "after 2024-06-20")
        self.assertEqual(g["journal_verification_and_reproduction"], "2026")

    def test_all_gates_prespecified_confirmatory(self):
        g = CFG["governance_timeline"]
        self.assertIn("Gates 1-5 were prespecified confirmatory analyses", g["interpretation"])
        self.assertNotIn("amended analyses", g["interpretation"])

    def test_no_patient_overlap_after_exclusion(self):
        d = CFG["development_provenance"]
        self.assertEqual(d["detected_development_overlap_cases_excluded_before_cohort_locking"], 12)
        self.assertEqual(d["patient_overlap_after_exclusion"], 0)

    def test_contour_reference_initializer(self):
        c = CFG["reference_contour_provenance"]
        self.assertEqual(c["de_novo_percent"], 72)
        self.assertEqual(c["independently_corrected_percent"], 28)
        self.assertFalse(c["research_propagated_contours_used_to_initialize_reference"])

    def test_constraint_crossing_labels_retrospective(self):
        a = CFG["clinical_constraint_crossing_action_classification"]
        self.assertEqual((a["targeted_review_labels"], a["repeat_accumulation_labels"], a["multidisciplinary_discussion_labels"]), (5,2,1))
        self.assertFalse(a["prospectively_triggered_during_treatment"])

if __name__ == "__main__":
    unittest.main()

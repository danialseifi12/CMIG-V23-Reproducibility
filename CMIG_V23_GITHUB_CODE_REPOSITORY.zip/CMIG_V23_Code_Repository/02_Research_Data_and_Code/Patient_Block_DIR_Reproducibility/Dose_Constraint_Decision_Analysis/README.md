# Dose-constraint decision analysis: endpoint-level statistical verification

This folder contains the study-team/physicist-approved controlled-reference dose-limit decision data, approved threshold registry, and original archived model-run scenario outputs for 10 selected endpoint cases. It supports the manuscript’s post hoc exploratory dose-constraint analysis and is an integrated part of the full reproducibility archive.

## Run
```
python run_all_checks.py
```
Expected: 432 endpoint rows; 24 parent source anatomies; 98 known-reference limit violations; 30 vs 8 false-safe labels; 139 vs 218 uncertain labels; 207 vs 308 non-SAFE labels; source-level exact two-sided p=0.125. Ten selected endpoint traces comprise 100 uncalibrated and 100 calibrated original stored model output doses per endpoint, giving 40 matching interval boundaries.

All manuscript-primary analyses (Gates 1–5, patient-level geometry, clinical dose reporting) are contained separately in `../Core_Statistical_Reproduction/`. The decision analysis is post hoc and does not replace those analyses. Numerical output verification is not a native image-to-SVF-to-dose replay, and no prospective treatment-decision benefit is claimed.

`Controlled_432.csv` supplies the endpoint reference, calibrated and uncalibrated dose interval, and observed constraint state in the protocol-limit coordinate. The executable classifier uses only the paired protocol registry and the coded endpoint data.

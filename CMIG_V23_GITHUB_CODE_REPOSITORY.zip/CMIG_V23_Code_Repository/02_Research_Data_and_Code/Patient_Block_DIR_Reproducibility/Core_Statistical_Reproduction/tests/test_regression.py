import unittest
from pathlib import Path
from analysis.statistics import gate1, gate1_power, gate2, gate3, controlled_source_analyses

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

class RegressionTests(unittest.TestCase):
    def test_gate1(self):
        r=gate1(DATA/"locked_test_fractions.csv"); self.assertAlmostEqual(r["p"],0.0223729974,8); self.assertEqual((r["successes"],r["n"]),(76,80))
    def test_gate1_power(self):
        r=gate1_power(); self.assertEqual(r["critical_successes"],76); self.assertAlmostEqual(r["power_at_true_rate"],0.62888,5)
    def test_gate2(self):
        r=gate2(DATA/"locked_test_fractions.csv")
        self.assertAlmostEqual(r["or"],1.369341,6)
        self.assertAlmostEqual(r["upper_one_sided"],1.805793,6)
        self.assertAlmostEqual(r["margin_p"],0.036836,6)
        self.assertAlmostEqual(r["robust_upper_one_sided"],1.858054,6)
        self.assertAlmostEqual(r["robust_margin_p"],0.052461,6)
    def test_gate3_counts_and_score_tests(self):
        r=gate3(DATA/"locked_test_fractions.csv",DATA/"clinical_bootstrap_replicates.csv")
        self.assertEqual((r["tp"],r["fn"],r["fp"],r["tn"]),(46,7,80,267))
        self.assertAlmostEqual(r["sensitivity_p_one_sided"],0.0103130474,8)
        self.assertAlmostEqual(r["npv_p_one_sided"],0.0060599266,8)
        self.assertAlmostEqual(r["sensitivity_lower_one_sided_95"],0.785714,6)
        self.assertAlmostEqual(r["sensitivity_ci_two_sided_95_low"],0.769231,6)
        self.assertAlmostEqual(r["sensitivity_ci_two_sided_95_high"],0.9523996,6)
        self.assertAlmostEqual(r["npv_lower_one_sided_95"],0.957854,6)
        self.assertAlmostEqual(r["npv_ci_two_sided_95_low"],0.954541025,6)
        self.assertAlmostEqual(r["npv_ci_two_sided_95_high"],0.992339175,6)
    def test_controlled_source_inference(self):
        r=controlled_source_analyses(DATA/"source_pairs.csv",DATA/"source_bootstrap_replicates.csv",DATA/"width_matched_bootstrap_replicates.csv")
        self.assertEqual((r["uncalibrated_contained"],r["dispersion_calibrated_contained"],r["width_matched_contained"]),(345,376,367))
        self.assertAlmostEqual(r["containment_gain_p"],0.0326200980,8)
        self.assertAlmostEqual(r["width_matched_superiority_p"],0.0290711991,8)
        self.assertEqual((r["joint_c1_wm1"],r["joint_c1_wm0"],r["joint_c0_wm1"],r["joint_c0_wm0"]),(357,19,10,46))
        self.assertAlmostEqual(r["width_matched_gain"],9/432,12)
        self.assertAlmostEqual(r["width_matched_ci_low"],1/432,12)
        self.assertAlmostEqual(r["width_matched_bootstrap_q25"],6/432,12)
        self.assertAlmostEqual(r["width_matched_bootstrap_median"],9/432,12)
        self.assertAlmostEqual(r["width_matched_bootstrap_q75"],12/432,12)
        self.assertAlmostEqual(r["width_matched_ci_high"],18/432,12)
        self.assertAlmostEqual(r["width_matched_noninferiority_p"],0.0001022222,8)
        self.assertAlmostEqual(r["interval_score_directional_p"],0.0475696264,8)
        self.assertAlmostEqual(r["interval_score_ci_high_two_sided"],0.026442575,7)
        self.assertAlmostEqual(r["interval_score_upper_one_sided"],-0.00530665,7)
        self.assertAlmostEqual(r["interval_score_two_sided_normal_p"],0.0951392527,8)
        self.assertEqual((r["high_severity_contained"],r["high_severity_n"]),(118,144))
        self.assertAlmostEqual(r["high_severity_source_cluster_ci_low"],0.7569444444,8)
        self.assertAlmostEqual(r["high_severity_source_cluster_ci_high"],0.8819444444,8)
        self.assertAlmostEqual(r["containment_gain_t23_p"],0.0390817122,8)
        self.assertAlmostEqual(r["interval_score_t23_directional_p"],0.0543483983,8)
        self.assertAlmostEqual(r["interval_score_wilcoxon_directional_p"],0.0505481958,8)

if __name__ == "__main__":
    unittest.main()

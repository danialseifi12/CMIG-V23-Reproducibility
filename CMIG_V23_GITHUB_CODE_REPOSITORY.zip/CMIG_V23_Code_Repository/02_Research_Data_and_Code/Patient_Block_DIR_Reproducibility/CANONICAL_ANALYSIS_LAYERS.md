# Analysis data coordinate systems

- Controlled-reference containment and interval score: `Core_Statistical_Reproduction/data/source_pairs.csv` and `Analysis_Specific_Verification/Interval_Score/interval_score_inputs_432.csv`.
- Deterministic percentile verification: `Analysis_Specific_Verification/Endpoint_Percentile_Replay/` (derived simulation at the endpoint layer only).
- Exploratory protocol-limit classification: `Dose_Constraint_Decision_Analysis/Controlled_432.csv` with `Constraints_Registry.csv` (separate absolute-dose coordinate).
- Saved scenario-output check for ten selected endpoints: `Original_Model_Output_Traces_10_Endpoints.xlsx`.

The invariant cross-layer quantities are endpoint keys, interval widths, known-reference containment labels and controlled-source stratification. Interval center equality across these layers is not an assumed invariant. Native image-to-dose computation is not recreated by the released derived-data scripts.

Historical intermediate U/WM arrays and the small Torch checkpoint are included under Dose_Constraint_Decision_Analysis/Intermediate_Replay_Assets. Their coordinate is separate from canonical endpoint replay and final decision doses. See RECONCILIATION_METHOD.md for the exact decision-preswap arithmetic.

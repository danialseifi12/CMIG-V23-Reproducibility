#!/usr/bin/env python3
from pathlib import Path
import argparse, csv, importlib.util
import numpy as np

def load_inference_module(path):
    spec = importlib.util.spec_from_file_location("psvf_inference", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--checkpoint", default="01_model_checkpoint.pt")
    p.add_argument("--inputs", default="04_replay_inputs_72_scenarios.npz")
    p.add_argument("--map", default="03_scenario_endpoint_map_432.csv")
    p.add_argument("--inference", default="01_model_definition_and_inference.py")
    p.add_argument("--output", default="03_local_response_parameters_432.csv")
    a=p.parse_args()

    mod=load_inference_module(a.inference)
    out=mod.run(a.checkpoint, a.inputs)
    scen_to_i={s:i for i,s in enumerate(out["scenario_ids"])}

    with open(a.map, newline="", encoding="utf-8") as f:
        rows=list(csv.DictReader(f))

    with open(a.output, "w", newline="", encoding="utf-8") as f:
        fields=["Pair_ID","Scenario_ID","Endpoint_Slot","Endpoint","Source_Anatomy_ID",
                "Site","Severity","Local_Response_Gain","Center_Shift_Gy","Parameter_Source"]
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for r in rows:
            i=scen_to_i[r["Scenario_ID"]]
            j=int(r["Endpoint_Slot"])-1
            w.writerow({
                **r,
                "Local_Response_Gain":f"{float(out['local_response_gain'][i,j]):.12f}",
                "Center_Shift_Gy":f"{float(out['center_shift_gy'][i,j]):.12f}",
                "Parameter_Source":"locked model response head"
            })

if __name__=="__main__":
    main()

"""Recompute secondary release analyses from the distributed inputs.
No native imaging or historical locked final-conformal predictor is reconstructed.
Default output is temporary; use --output-dir to retain reconstructed tables.
"""
from pathlib import Path
import argparse,json,tempfile
import numpy as np
import pandas as pd
from scipy import stats
E=Path(__file__).resolve().parent;R=E.parent;P=R.parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path)
args=parser.parse_args()
_tmp=tempfile.TemporaryDirectory(prefix='cmig-secondary-') if args.output_dir is None else None
V=args.output_dir.resolve() if args.output_dir else Path(_tmp.name)
V.mkdir(parents=True,exist_ok=True)
lm=pd.read_csv(R/'Core_Statistical_Reproduction/data/landmark_level_containment_and_tre.csv')
cal=pd.read_csv(P/'02_Reproducibility_Package/Calibration_40_Patient_Block_Scores.csv')
records=[];cstats={};dist=[]
for site in ['Prostate','Head-and-neck']:
    g=cal.loc[cal.Disease_Site.eq(site)]
    q=g.Max_Mahalanobis_Q.to_numpy();r=np.sqrt(q);rng=np.random.default_rng(20261020)
    draw=np.sqrt(rng.choice(q,size=(5000,20),replace=True).max(axis=1))
    cv=100*draw.std(ddof=1)/draw.mean();sq=np.sort(q);prob=(np.arange(1,21)/20)**20-(np.arange(20)/20)**20
    er=float(np.dot(prob,np.sqrt(sq)));sd=float(np.sqrt(np.dot(prob,(np.sqrt(sq)-er)**2)))
    cstats[site]={'seed':20261020,'replicates':5000,'Q':float(q.max()),'radius':float(r.max()),'second_largest_Q':float(sq[-2]),'max_delete_one_drop_pct':float(100*(1-np.sqrt(sq[-2]/sq[-1]))),'CV_pct':float(cv),'bootstrap_mean_radius':float(draw.mean()),'bootstrap_SD_radius':float(draw.std(ddof=1)),'bootstrap_min_radius':float(draw.min()),'bootstrap_max_radius':float(draw.max()),'exact_population_CV_pct':100*sd/er,'exact_mean_radius':er,'exact_SD_radius':sd}
    cal.loc[g.index,'Radius_r']=r
    # CSV Bootstrap_Radius_CV_pct stores rounded exact conditional CV (not finite-Monte-Carlo CV).
    # The supplied CSV is immutable: preserve its rounded descriptive fields.
    # The 5000-draw replication and exact discrete distribution are exported separately.
    records.extend({'site':site,'replicate':i+1,'r_sim':float(x),'seed':20261020} for i,x in enumerate(draw))
    dist.extend({'site':site,'order':i+1,'Q':float(x),'r':float(np.sqrt(x)),'probability_maximum':float(p)} for i,(x,p) in enumerate(zip(sq,prob)))
cal.to_csv(V/'Calibration_40_Patient_Block_Scores.csv',index=False)
pd.DataFrame(records).to_csv(V/'calibration_bootstrap_5000_per_site.csv',index=False)
pd.DataFrame(dist).to_csv(V/'calibration_exact_distribution.csv',index=False)

# Generic export scalar is analysed explicitly as a descriptive secondary predictor.
# It is not silently substituted for the historical final-conformal C03 predictor.
x=lm.largest_semi_axis_mm.to_numpy();y=lm.tre_mm.to_numpy();event=y>3
_,xi=np.unique(x,return_inverse=True);_,yi=np.unique(y,return_inverse=True)
def weighted_metrics(w):
    gx=np.bincount(xi,weights=w);gy=np.bincount(yi,weights=w)
    rx=(np.cumsum(gx)-.5*gx)[xi];ry=(np.cumsum(gy)-.5*gy)[yi]
    mx=np.average(rx,weights=w);my=np.average(ry,weights=w)
    rho=np.sum(w*(rx-mx)*(ry-my))/np.sqrt(np.sum(w*(rx-mx)**2)*np.sum(w*(ry-my)**2))
    pos=np.bincount(xi,weights=w*event,minlength=len(gx));neg=gx-pos;np1=pos.sum();nn=neg.sum()
    auc=np.sum(pos*(np.cumsum(neg)-neg+.5*neg))/(np1*nn) if np1 and nn else np.nan
    tp=np.cumsum(pos[::-1]);alln=np.cumsum(gx[::-1]);ap=np.sum(np.divide(tp,alln,out=np.zeros_like(tp),where=alln>0)*pos[::-1])/np1 if np1 else np.nan
    return float(rho),float(auc),float(ap)
point=weighted_metrics(np.ones(len(lm)))
patients=sorted(lm.patient_id.unique());pi={p:i for i,p in enumerate(patients)};pindex=lm.patient_id.map(pi).to_numpy()
site_pat={s:g.patient_id.unique() for s,g in lm.groupby('anatomical_site')};rng=np.random.default_rng(20261020);boot=[];component=[];site_component={s:[] for s in site_pat}
for b in range(5000):
    sample=np.concatenate([rng.choice(a,size=len(a),replace=True) for a in site_pat.values()]);cnt=np.bincount([pi[p] for p in sample],minlength=80)
    w=cnt[pindex];boot.append(weighted_metrics(w));component.append(float(np.average(lm.inside_conformal_ellipsoid,weights=w)))
    for site in site_pat:
        m=lm.anatomical_site.eq(site).to_numpy();site_component[site].append(float(np.average(lm.inside_conformal_ellipsoid.to_numpy()[m],weights=w[m])))
boot=np.asarray(boot);pd.DataFrame(boot,columns=['spearman_rho','AUROC','average_precision']).assign(replicate=np.arange(1,5001),seed=20261020,component_containment=component).to_csv(V/'generic_landmark_scalar_bootstrap_5000.csv',index=False)
gstats={'n':len(lm),'patients':80,'high_TRE_count':int(event.sum()),'max_TRE_mm':float(y.max()),'seed':20261020,'bootstrap_replicates':5000,'predictor':'general-purpose largest_semi_axis_mm export scalar; not the locked final-conformal C03 predictor','analysis_status':'descriptive secondary release analysis'}
for i,k in enumerate(['spearman_rho','AUROC','average_precision']):gstats[k]={'point':point[i],'CI95':np.nanquantile(boot[:,i],[.025,.975]).tolist(),'valid_bootstrap_replicates':int(np.isfinite(boot[:,i]).sum())}
qstats={s:{'TRE_quantiles':np.quantile(g.tre_mm,[.25,.5,.75]).tolist(),'generic_scalar_quantiles':np.quantile(g.largest_semi_axis_mm,[.25,.5,.75]).tolist(),'inside':int(g.inside_conformal_ellipsoid.sum()),'n':len(g),'component_containment_CI95':np.quantile(site_component[s],[.025,.975]).tolist()} for s,g in lm.groupby('anatomical_site')}
gstats['component_containment']={'inside':int(lm.inside_conformal_ellipsoid.sum()),'point':float(lm.inside_conformal_ellipsoid.mean()),'CI95':np.quantile(component,[.025,.975]).tolist()}

out={'calibration':cstats,'landmark_descriptive':gstats,'landmark_site_summaries':qstats}
(V/'recomputed_secondary_results.json').write_text(json.dumps(out,indent=2)+'\n')
for name in ['calibration_bootstrap_5000_per_site.csv','calibration_exact_distribution.csv','generic_landmark_scalar_bootstrap_5000.csv']:
    actual=pd.read_csv(V/name);expected=pd.read_csv(E/name)
    pd.testing.assert_frame_equal(actual,expected,check_exact=False,rtol=0,atol=1e-12)
expected=json.loads((E/'release_reconciliation_results.json').read_text())
for metric in ['spearman_rho','AUROC','average_precision']:
    assert np.isclose(gstats[metric]['point'],expected['landmark_descriptive'][metric]['point'],rtol=0,atol=1e-12)
    assert np.allclose(gstats[metric]['CI95'],expected['landmark_descriptive'][metric]['CI95'],rtol=0,atol=1e-12)
print('PASS: independently reran 10,000 calibration draws and 5,000 patient-block landmark resamples; all saved replicates and reported secondary summaries agree.')
if _tmp is not None:_tmp.cleanup()
else:print('Recalculated tables saved to',V)

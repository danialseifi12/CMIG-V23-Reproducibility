# Dataset field definitions for reviewers

## Controlled_432.csv

One record is one pairing of source-anatomy/controlled-reference scenario and DVH endpoint.

- `Source_ID`, `Scenario_ID`, `Disease_Site`, `Severity`, `Structure`, `DVH_Endpoint`: identifiers and controlled reference/endpoint strata.
- `Ref_MappedDose_Gy`: known-reference **deformation-mapping** dose endpoint (not a measurement of delivered patient dose).
- `Nominal_MappedDose_Gy`: archived nominal mapping endpoint.
- `Uncal_P05_Gy`, `Uncal_P95_Gy`: uncalibrated scenario 5th/95th dose percentiles.
- `Cal_P05_Gy`, `Cal_P95_Gy`: dispersion-calibrated scenario 5th/95th dose percentiles.
- `Constraint_ID`, `Limit_Gy`, `Limit_Direction`: join to `Constraints_Registry.csv`; `MAX` is an upper limit, `MIN` a lower requirement.
- `Reference_Status`: `VIOLATION` when the known-reference endpoint lies beyond the specified constraint; else `COMPLIANT`.
- `Uncal_Decision`, `Cal_Decision`: `SAFE` / `UNCERTAIN` / `VIOLATION` derived from the entire P05–P95 interval relative to the limit.
- `Uncal_FalseSafe`, `Cal_FalseSafe`: recorded classification is `SAFE` even though reference violates the constraint.
- `Uncal_FalseViolation`, `Cal_FalseViolation`: recorded classification is `VIOLATION` even though reference is compliant.
- `Resolved_FalseSafe`, `New_FalseSafe`: paired transition flags.
- `Uncal_Uncertain`, `Cal_Uncertain`: indicators for ambiguous intervals crossing the threshold.
- `Uncal_ContainsTruth`, `Cal_ContainsTruth`: indicator of interval containment of reference endpoint.
- `Data_QC`, `Source_File`, `Notes`: retained institutional annotation / archival metadata; not used to compute the decision or infer provenance.
- `Uncal_Width_Gy_CHECK`, `Cal_Width_Gy_CHECK`: auxiliary width calculations from corresponding interval bounds.

For a `MAX` limit `L`: `SAFE` if `P95 <= L`; `VIOLATION` if `P05 > L`; otherwise `UNCERTAIN`. For a `MIN` requirement: `SAFE` if `P05 >= L`; `VIOLATION` if `P95 < L`; otherwise `UNCERTAIN`.

## Constraints_Registry.csv

Twelve site-specific endpoint threshold definitions, with `Constraint_ID_ENTER` serving as the join key. Prescriptions and protocol registry notes provide contextual metadata for the exploratory classification rules; they are not used to recalculate the clinical Table 5.

## Original_Model_Output_Traces_10_Endpoints.xlsx

The `Scenario_Trace_100x10` worksheet has 100 saved outputs for each of 10 selected endpoint traces (2000 individual scalar dose outputs across both approaches). Fields `Uncal_Dose_Gy` and `Cal_Dose_Gy` represent investigator-confirmed original model-run results. The comparison script uses the linear NumPy percentile convention documented in the article, joining by scenario / structure / endpoint.

### Clarifications on Archive Endpoint Replay and Clinical Crossing Columns
- **`endpoint_scenarios_432x100_both_methods.csv` (`Scenario_No`):** The released endpoint-wise arrays support marginal percentile replay. Sample indices (`Scenario_No` 1–100) are local to each endpoint and must not be interpreted as identifiers of a common dose-volume realization across endpoints; native joint scenario correspondence is not established by this release.
- **`dose_constraint_crossings_and_surfaces.csv` (`constraint_cross_uncalibrated`):** Stores the patient-level primary dispersion-calibrated (`gamma_disp`) protocol constraint-crossing indicator (8/78 patients) alongside `constraint_cross_gamma_sim` (9/78 patients) and `cumulative_dose_band_width_gy` (median 2.27 Gy); the legacy column header `constraint_cross_uncalibrated` is retained for script compatibility.

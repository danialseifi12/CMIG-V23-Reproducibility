"""Cross-file regressions for the reconciled release; no native imaging claim."""
from pathlib import Path
import subprocess,sys,json
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'data'
def test_features_match_by_patient_and_fraction():
    a=pd.read_csv(DATA/'locked_test_fractions_enriched.csv');b=pd.read_csv(DATA/'triage_feature_provenance_logs.csv')
    x=a.merge(b,left_on=['Patient_ID','Fraction_ID'],right_on=['patient_id','milestone'],validate='one_to_one')
    assert np.allclose(x.A95_mm,x.raw_a95_mm,atol=1e-10,rtol=0)
    assert np.allclose(x.f_high_0_1,x.f_high_severity,atol=1e-10,rtol=0)
def test_fraction_TRE_is_mean_of_its_landmarks():
    a=pd.read_csv(DATA/'locked_test_fractions_enriched.csv');b=pd.read_csv(DATA/'landmark_level_containment_and_tre.csv')
    expected=b.groupby(['patient_id','milestone']).tre_mm.mean();mapped=pd.MultiIndex.from_frame(a[['Patient_ID','Fraction_ID']]).map(expected)
    assert np.allclose(mapped,a.tre_mean_mm,atol=1e-12,rtol=0)
def test_catalog_names_and_export_keys():
    a=pd.read_csv(DATA/'landmark_atlas.csv');b=pd.read_csv(DATA/'landmark_level_containment_and_tre.csv')
    assert len(a)==20 and not a.Landmark_Name.isin(['Prostate','Head-and-Neck']).any()
    for site,g in b.groupby('anatomical_site'):
        c=a[a.Site.eq(site.replace('Head-and-Neck','Head-and-neck'))]
        assert set(map(tuple,c[['Export_Landmark_ID','Landmark_Name']].to_numpy()))==set(map(tuple,g[['landmark_id','landmark_name']].drop_duplicates().to_numpy()))
def test_undefined_marginal_flags_are_not_active_inputs():
    a=pd.read_csv(DATA/'landmark_level_containment_and_tre.csv');assert 'Marginal_Inclusion_Flag' not in a.columns
def test_full_cross_file_release_verification():
    script=ROOT.parent/'Release_Reconciliation/verify_release_consistency.py'
    p=subprocess.run([sys.executable,str(script)],cwd=ROOT,capture_output=True,text=True)
    assert p.returncode==0,p.stdout+'\n'+p.stderr
    assert json.loads((script.parent/'release_consistency_report.json').read_text())['all_passed']

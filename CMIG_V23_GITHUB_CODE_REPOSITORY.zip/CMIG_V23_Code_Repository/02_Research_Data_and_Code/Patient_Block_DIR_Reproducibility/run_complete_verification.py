#!/usr/bin/env python3
"""Run all code/data checks without publication files. No network after installation."""
from pathlib import Path
import subprocess,sys,json,platform,importlib.metadata
ROOT=Path(__file__).resolve().parent
checks=[('source_integrity', '.', ['../../verify_package.py', '--static']), ('publication_exclusion_and_input_preservation', '.', ['../../verify_public_archive.py']), ('calibration_source_and_numerics', '.', ['../../verify_calibration.py']), ('adjusted_longitudinal_models', 'Core_Statistical_Reproduction', ['scripts/run_longitudinal_c04_models.py']), ('dose_layer_reconciliation', 'Dose_Constraint_Decision_Analysis', ['export_and_reconcile_dose.py']), ('intermediate_and_WM_replay', 'Dose_Constraint_Decision_Analysis', ['verify_intermediate_replay.py']), ('release_consistency', 'Release_Reconciliation', ['verify_release_consistency.py']), ('main_analysis', 'Core_Statistical_Reproduction', ['run_analysis.py']), ('extended_analysis', 'Core_Statistical_Reproduction', ['run_extended_validation.py']), ('triage', 'Core_Statistical_Reproduction', ['scripts/triage_metrics.py']), ('width_matching', 'Core_Statistical_Reproduction', ['scripts/width_matching_fit.py']), ('regression_tests', 'Core_Statistical_Reproduction', ['-m', 'pytest', '-q']), ('core_integrity', 'Core_Statistical_Reproduction', ['verify_manifest.py']), ('controlled_decisions_and_traces', 'Dose_Constraint_Decision_Analysis', ['run_all_checks.py']), ('interval_score_formula_replay', 'Analysis_Specific_Verification', ['Interval_Score/recompute_interval_score.py']), ('endpoint_percentile_replay', 'Analysis_Specific_Verification', ['Endpoint_Percentile_Replay/verify_endpoint_replay.py']), ('patient_partition_check', 'Analysis_Specific_Verification', ['Patient_Allocation/reproduce_partition.py']), ('coded_patient_registration_linkage', 'Analysis_Specific_Verification', ['Patient_Allocation/Coded_Patient_and_Registration_Linkage/verify_coded_linkage.py']), ('paired_source_summary_check', 'Numerical_Source_Verification', ['verify_source_summaries.py']), ('gate5_fixed_label_bootstrap_check', 'Analysis_Specific_Verification', ['Width_Matched_Bootstrap/reproduce_gate5_bootstrap.py'])]
packages=['numpy','pandas','scipy','statsmodels','patsy','pytest','torch','matplotlib','Pillow','PyMuPDF']
environment={'python':platform.python_version(),'packages':{p:importlib.metadata.version(p) for p in packages}}
(ROOT/'RUN_ENVIRONMENT.json').write_text(json.dumps(environment,indent=2)+'\n')
results={};failure=[]
for name,folder,args in checks:
 p=subprocess.run([sys.executable,*args],cwd=ROOT/folder,text=True,capture_output=True)
 results[name]={'returncode':p.returncode,'stdout_tail':p.stdout[-1200:],'stderr_tail':p.stderr[-900:]}
 print(f'{name}: {"PASS" if p.returncode==0 else "FAIL"}',flush=True)
 if p.returncode:failure.append(name)
(ROOT/'VERIFICATION_RUN_REPORT.json').write_text(json.dumps(results,indent=2)+'\n')
if failure:raise SystemExit('Failed: '+', '.join(failure))
print('PASS: all 20 code/data components passed; no publication files are read')

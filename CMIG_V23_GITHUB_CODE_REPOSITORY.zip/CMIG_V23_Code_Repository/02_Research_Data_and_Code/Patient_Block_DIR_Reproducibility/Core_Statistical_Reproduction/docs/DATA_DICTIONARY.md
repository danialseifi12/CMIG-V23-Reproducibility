# Data dictionary: core statistical analysis

- `locked_test_fractions.csv`: 400 locked-test fractions for geometry and QA-triage statistics.
- `source_pairs.csv`: 432 controlled-reference endpoint rows, coverage/width fields and formula-derived interval-score summaries. For direct verification of interval-score components see `../../Analysis_Specific_Verification/Interval_Score/interval_score_inputs_432.csv`.
- `controlled_reference_endpoints_432_canonical.csv`: convenient schema projection of `source_pairs.csv`; identical endpoint values, not a separate study cohort.
- `clinical_bootstrap_replicates.csv`, `source_bootstrap_replicates.csv` and `width_matched_bootstrap_replicates.csv`: archived 5,000-draw statistical summaries.
- `locked_test_fractions_enriched.csv`: 400 linked fractions with modality and geometric summaries.
- `triage_feature_provenance_logs.csv`: recorded frozen triage scores, review flags, outcomes and features.
- `landmark_level_containment_and_tre.csv`: 4,000 coded landmark observations.
- `scenario_level_fitting_inputs.csv`: 72 scenario width-fitting rows used to determine the pooled width control.
- `multi_ensemble_k_sensitivity_raw.csv`: 120 individual evaluation entries for K sensitivity.
- `dose_constraint_crossings_and_surfaces.csv`: 78 dose-complete clinical evaluation rows. These rows do not alone reproduce every structure-level value in clinical Table 5.
- `surface_correspondence_summary.csv`: aggregated structure-level dense correspondence statistics; original dense point coordinates are not released.

The complete source-to-estimate listing and levels of statistical verification are supplied in `../../STUDY_SOURCE_SCOPE_INDEX.csv`.

## Final release fields

- A95_mm: 95th percentile of the uncertainty radius over the review mask; a95_mask_mm in the enriched export is the same feature alias. raw_a95_mm in the keyed provenance log is the corresponding retained A95 value, not a new raw-image extraction.
- f_high_0_1 and f_high_severity: matching canonical tail fractions, connected by Patient_ID/Fraction_ID to patient_id/milestone. Row order is not an identity key.
- tre_mean_mm: arithmetic mean of the patient's 8 or 12 released tre_mm landmark values for the same milestone.
- largest_semi_axis_mm in the landmark export: general-purpose uncertainty scalar in mm. It is not asserted to be the historical locked final-conformal predictor. The current descriptive analysis and Supplementary Figure S4 use this named export field explicitly.
- inside_conformal_ellipsoid: retained component-membership event under the patient-block set. Minimum across a patient's landmark set reproduces Coverage_0_1.
- No active smaller-radius marginal-membership field is supplied. The undefined V13 flag is archived outside active research inputs and is not used to infer nominal marginal coverage.
- r_marg=2.96/3.08 is a fixed empirical dose-transfer reference in this release; its derivation as a weighted 95th percentile is not asserted from the maximum-only calibration table.
- Release_Reconciliation supplies 5000 calibration bootstrap radii/site, 5000 descriptive landmark bootstrap samples, figure-preservation checks, source-scoped summaries and executable cross-file checks. See ANALYSIS_UPDATE_20261020.md for changed secondary claims.

### Clarifications on Archive Endpoint Replay and Clinical Crossing Columns
- **`endpoint_scenarios_432x100_both_methods.csv` (`Scenario_No`):** The released endpoint-wise arrays support marginal percentile replay. Sample indices (`Scenario_No` 1–100) are local to each endpoint and must not be interpreted as identifiers of a common dose-volume realization across endpoints; native joint scenario correspondence is not established by this release.
- **`dose_constraint_crossings_and_surfaces.csv` (`constraint_cross_uncalibrated`):** Stores the patient-level primary dispersion-calibrated (`gamma_disp`) protocol constraint-crossing indicator (8/78 patients) alongside `constraint_cross_gamma_sim` (9/78 patients) and `cumulative_dose_band_width_gy` (median 2.27 Gy); the legacy column header `constraint_cross_uncalibrated` is retained for script compatibility.

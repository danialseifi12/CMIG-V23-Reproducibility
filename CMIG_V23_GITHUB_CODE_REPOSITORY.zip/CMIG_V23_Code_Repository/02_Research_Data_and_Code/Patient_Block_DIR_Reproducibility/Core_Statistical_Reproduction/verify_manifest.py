#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys

ROOT = Path(__file__).resolve().parent
manifest = ROOT / "MANIFEST.sha256"
bad = []
checked = 0

for raw in manifest.read_text(encoding="utf-8").splitlines():
    if not raw.strip():
        continue
    expected, rel = raw.split(maxsplit=1)
    rel = rel.lstrip("* ")
    p = ROOT / rel
    if not p.is_file():
        bad.append(f"MISSING  {rel}")
        continue
    observed = hashlib.sha256(p.read_bytes()).hexdigest()
    checked += 1
    if observed != expected:
        bad.append(f"MISMATCH {rel}")

if bad:
    print("\n".join(bad))
    print(f"manifest: FAILED ({len(bad)} problem(s), {checked} files checked)")
    raise SystemExit(1)

print(f"manifest: PASS ({checked} files checked)")

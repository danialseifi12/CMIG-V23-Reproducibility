# Locked triage threshold-selection rule

Threshold selection used calibration patients only. The candidate grid was 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, and 0.65 in five patient-blocked folds (deterministic RNG seed 20260826). A single global threshold was feasible only if sensitivity >= 0.75 and NPV >= 0.95 in **every** held-out fold. Among globally feasible candidates, mean held-out review rate across folds was minimized.

Thresholds 0.35, 0.45, and 0.50 were feasible in all five folds. Their mean review rates were 0.630, 0.440, and 0.355, respectively, so 0.50 was selected and frozen before locked-test evaluation. In the verified Fold 4 grid, sensitivity is 0.750 at thresholds 0.40, 0.45, and 0.50 and 0.500 at thresholds 0.55, 0.60, and 0.65; the corrected NPV values are 0.938, 0.958, 0.964, 0.939, 0.943, and 0.944, respectively.

The rule is independently reproduced by `analysis.statistics.triage_cv_selection` and regression-tested in `tests/test_fold_level_cv.py`. Locked-test outcomes are not inputs to this selection function.


## Locked-test action mapping
In the retained locked-test table, the binary action label is reproduced exactly in all 400 rows by the disease-site-specific absolute A95/f_high rule and also by `Triage_Score >= 0.50`. The retained `Delta_A95_mm` field is a longitudinal descriptive change metric and is not an additional binary flag criterion in this journal-facing derived archive. The archive verifies the score-to-action mapping but does not reconstruct the upstream image-level transformation used to create the normalized continuous score.

## Locked-test action-label provenance

The retained locked-test table defines the binary action labels by the documented disease-site-specific absolute A95/f_high cutoffs, and `Triage_Score >= 0.50` reproduces those labels in all 400 locked-test rows. `Delta_A95_mm` is retained as a descriptive longitudinal metric and is not used to alter the retained binary action labels in this verification archive. The contemporaneous institutional SAP remains the controlling provenance document for prespecification; this journal-facing archive verifies the retained implementation rather than reconstructing unavailable upstream preprocessing logic.

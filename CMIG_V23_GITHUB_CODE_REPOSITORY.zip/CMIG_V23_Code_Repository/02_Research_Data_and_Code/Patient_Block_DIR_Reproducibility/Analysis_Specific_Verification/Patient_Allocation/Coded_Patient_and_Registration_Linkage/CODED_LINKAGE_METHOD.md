# Coded study-record linkage

This directory provides linkage among **pseudonymized** patient and registration aliases, not between codes and real-world patient identities. The study team confirmed that, at the time of study execution, locked-test patient aliases were assigned by test-cohort partition order within disease site.

For each disease site the first 20 eligible patients by partition order were allocated to calibration and orders 21–60 to the locked test set. The test alias suffix is `Partition_Order - 20` (001–040 within each site). For example, `P_TEST_001` corresponds to the coded Prostate test record whose partition order is 21. At each of M10, M30, M50, M70 and M90, the registration identifier extends that same coded alias.

- `patient_id_crosswalk_80.csv`: 80 site-specific test patient aliases to coded screening IDs and partition order, including dose-completeness indicators.
- `fraction_registration_crosswalk_400.csv`: five linked milestones per test alias, 400 pseudonymized registration IDs.
- `test_complete_course_dose_crosswalk_78.csv`: 78 dose-complete coded study evaluation IDs.
- `verify_coded_linkage.py`: standalone consistency checks against the released original patient-allocation manifest and 400 locked-test registration records.

**Scope.** The program verifies arithmetic, uniqueness, counts and exact matching of the two *coded* namespaces to their retained study tables. The site-specific naming rule is supported by study-team confirmation. This does not independently demonstrate historical patient identity from the original restricted medical records and does not distribute the hospital's original identity key. Linking pseudonymized records can increase re-identification risk when combined with restricted systems, so institutional data-release approval is needed before sharing.

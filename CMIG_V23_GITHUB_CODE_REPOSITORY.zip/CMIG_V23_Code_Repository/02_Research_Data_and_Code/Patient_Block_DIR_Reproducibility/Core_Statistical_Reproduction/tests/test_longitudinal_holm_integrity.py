"""Independent matrix/sandwich and multiplicity checks for the adjusted refit."""
import json
from pathlib import Path
import numpy as np,pandas as pd,patsy
from scipy.stats import norm,t

C=Path(__file__).resolve().parents[1];R=C.parent
REPORT=json.loads((C/'outputs/longitudinal_c04_results.json').read_text())['models']

def independent(key):
    df=pd.read_csv(C/'data/longitudinal_analysis_input.csv')
    y,X=patsy.dmatrices(REPORT[key]['formula'],df,return_type='dataframe',eval_env=-1)
    a=X.to_numpy();y=y.to_numpy().ravel();pinv=np.linalg.pinv(a)
    b=pinv@y;e=y-a@b
    scores=np.vstack([(a[eids].T@e[eids]) for pid in df.Patient_ID.unique()
        for eids in [np.flatnonzero(df.Patient_ID.to_numpy()==pid)]])
    bread=pinv@pinv.T;g=df.Patient_ID.nunique();n,k=a.shape
    cov=bread@scores.T@scores@bread*g/(g-1)*(n-1)/(n-k)
    i=X.columns.get_loc('time20')
    return b[i],np.sqrt(cov[i,i])

def test_independent_coefficients_and_cluster_sandwich():
    for key in ['tre','volume','relative_ratio']:
        b,se=independent(key)
        assert np.isclose(b,REPORT[key]['log_or_linear_beta'],rtol=1e-9)
        assert np.isclose(se,REPORT[key]['standard_error'],rtol=1e-9)

def test_raw_p_values_have_no_floor():
    for key in ['tre','volume','relative_ratio']:
        b,se=independent(key);dist=t(79) if key=='tre' else norm
        assert np.isclose(2*dist.sf(abs(b/se)),REPORT[key]['raw_p'],rtol=1e-9)
    assert REPORT['relative_ratio']['raw_p']<.04

def test_holm_from_all_four_unmodified_tests():
    keys=sorted(REPORT,key=lambda k:REPORT[k]['raw_p']);running=0
    for i,key in enumerate(keys):
        running=max(running,(4-i)*REPORT[key]['raw_p'])
        assert np.isclose(min(1,running),REPORT[key]['holm_p'],rtol=1e-12)
    assert REPORT['tre']['reported_holm_p']=='0.0033'
    assert REPORT['noncoverage']['reported_holm_p']=='0.0673'
    assert REPORT['relative_ratio']['reported_holm_p']=='0.0673'

def test_tre_ci_and_test_share_t79():
    m=REPORT['tre'];b,se=independent('tre')
    assert np.allclose(m['ci95'],[b-t.ppf(.975,79)*se,b+t.ppf(.975,79)*se])
    assert m['distribution']=='t79'
    assert m['time_contrast_estimability_error']<1e-10

def test_released_plot_numbers_match_model_output():
    f=json.loads((R/'Release_Reconciliation/Artwork_Numerical_Data.json').read_text())['Figures/Figure_2.png']
    assert np.isclose(f['TRE_Holm_p'],REPORT['tre']['holm_p'],rtol=1e-10,atol=1e-14)
    assert f"{f['TRE_Holm_p']:.4f}"==REPORT['tre']['reported_holm_p']
    assert np.isclose(f['noncoverage_Holm_p'],REPORT['noncoverage']['holm_p'],rtol=1e-10,atol=1e-14)
    assert f"{f['noncoverage_Holm_p']:.4f}"==REPORT['noncoverage']['reported_holm_p']

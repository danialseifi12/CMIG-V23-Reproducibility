#!/usr/bin/env python3
from __future__ import annotations
import csv
from collections import defaultdict
from pathlib import Path

ALPHA = 0.10

def interval_score(p05: float, p95: float, reference: float, alpha: float = ALPHA) -> float:
    width = p95 - p05
    lower_penalty = (2.0 / alpha) * max(p05 - reference, 0.0)
    upper_penalty = (2.0 / alpha) * max(reference - p95, 0.0)
    return width + lower_penalty + upper_penalty

def main() -> None:
    root = Path(__file__).resolve().parent
    rows = list(csv.DictReader((root / "interval_score_inputs_432.csv").open(encoding="utf-8")))
    n = len(rows)
    assert n == 432
    source_diffs = defaultdict(list)
    u_scores, c_scores = [], []
    u_contained = c_contained = 0
    max_err = 0.0
    for r in rows:
        y = float(r["Reference_Dose_Gy"])
        u = interval_score(float(r["Uncal_P05_Gy"]), float(r["Uncal_P95_Gy"]), y)
        c = interval_score(float(r["Cal_P05_Gy"]), float(r["Cal_P95_Gy"]), y)
        max_err = max(max_err,
                      abs(u - float(r["Uncal_Interval_Score_Gy"])),
                      abs(c - float(r["Cal_Interval_Score_Gy"])))
        u_scores.append(u); c_scores.append(c)
        u_contained += int(float(r["Uncal_P05_Gy"]) <= y <= float(r["Uncal_P95_Gy"]))
        c_contained += int(float(r["Cal_P05_Gy"]) <= y <= float(r["Cal_P95_Gy"]))
        source_diffs[r["Source_Anatomy_ID"]].append(c-u)
    assert max_err < 1e-7
    assert u_contained == 345
    assert c_contained == 376
    print(f"rows={n}")
    print(f"uncalibrated_mean_interval_score={sum(u_scores)/n:.9f} Gy")
    print(f"dispersion_calibrated_mean_interval_score={sum(c_scores)/n:.9f} Gy")
    print(f"difference_C_minus_U={(sum(c_scores)-sum(u_scores))/n:.9f} Gy")
    print(f"uncalibrated_containment={u_contained}/{n}")
    print(f"dispersion_calibrated_containment={c_contained}/{n}")
    print(f"source_anatomies={len(source_diffs)}")
    print(f"max_formula_error={max_err:.3e}")

if __name__ == "__main__":
    main()

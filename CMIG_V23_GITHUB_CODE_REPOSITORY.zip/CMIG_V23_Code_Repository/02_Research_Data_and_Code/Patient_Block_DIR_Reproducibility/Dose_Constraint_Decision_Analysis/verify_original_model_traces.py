#!/usr/bin/env python3
"""Verify original model-run scenario dose trace percentiles against the controlled 432-row table.

Provenance: PI confirms original archived execution outputs in workbook. This verifies the
stored 100-scenario endpoint arrays and percentile-to-table consistency only; the full
medical-image/SVF/dose-warping pipeline is not executed by this script.
"""
from collections import defaultdict
import csv,json,hashlib
from pathlib import Path
import numpy as np
from openpyxl import load_workbook
ROOT=Path(__file__).resolve().parent
with (ROOT/'Controlled_432.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
indexed={(r['Scenario_ID'],r['Structure'],r['DVH_Endpoint']):r for r in rows}
wb=load_workbook(ROOT/'Original_Model_Output_Traces_10_Endpoints.xlsx',read_only=True,data_only=True)
it=iter(wb['Scenario_Trace_100x10'].values)
for _ in range(3): next(it)
columns=next(it)
groups=defaultdict(list)
for raw in it:
    if raw[0] is not None: groups[raw[0]].append(dict(zip(columns,raw)))
assert len(groups)==10
results=[]
for case,items in sorted(groups.items()):
    assert len(items)==100
    assert sorted(int(v['Scenario_No']) for v in items)==list(range(1,101))
    first=items[0];key=(first['Scenario_ID'],first['Structure'],first['DVH_Endpoint'])
    assert all((x['Scenario_ID'],x['Structure'],x['DVH_Endpoint'])==key for x in items)
    r=indexed[key]
    assert int(r['Resolved_FalseSafe'])==1
    arr=np.asarray([[float(x['Uncal_Dose_Gy']),float(x['Cal_Dose_Gy'])] for x in items])
    lohi=np.percentile(arr,[5,95],axis=0,method='linear')
    rec=np.array([lohi[0,0],lohi[1,0],lohi[0,1],lohi[1,1]])
    saved=np.array([float(r['Uncal_P05_Gy']),float(r['Uncal_P95_Gy']),float(r['Cal_P05_Gy']),float(r['Cal_P95_Gy'])])
    error=float(np.max(np.abs(rec-saved)))
    assert error<1e-8,(case,error)
    results.append({'trace_id':case,'source':r['Source_ID'],'scenario':r['Scenario_ID'],'structure':r['Structure'],'endpoint':r['DVH_Endpoint'],'n_paired':100,'max_abs_error_Gy':error,'center_shift_Gy':float(lohi[:,1].mean()-lohi[:,0].mean())})
assert len(set(x['source'] for x in results))==4
report={'n_selected_endpoints':len(results),'independent_sources_represented':4,'n_original_dose_outputs_both_arms':2000,'all_40_bounds_within_1e-8_Gy':True,'max_abs_error_Gy':max(x['max_abs_error_Gy'] for x in results),'method':'NumPy linear 5th and 95th percentiles; output-level validation (not full native image-to-dose replay)','source_workbook_sha256':hashlib.sha256((ROOT/'Original_Model_Output_Traces_10_Endpoints.xlsx').read_bytes()).hexdigest(),'cases':results}
(ROOT/'original_trace_verification_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (ROOT/'original_trace_verification_10_endpoints.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))

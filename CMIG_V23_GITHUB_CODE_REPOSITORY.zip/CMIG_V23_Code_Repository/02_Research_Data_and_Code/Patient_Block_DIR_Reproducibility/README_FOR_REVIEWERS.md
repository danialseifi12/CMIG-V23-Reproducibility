# Public code/data archive

Start with the root README.md. Run the complete verification from the extracted root using `python run_verification.py`. The article, supplement, stored artwork and all office documents are excluded. Numerical inputs needed by the analyses remain included. No publication files are required.

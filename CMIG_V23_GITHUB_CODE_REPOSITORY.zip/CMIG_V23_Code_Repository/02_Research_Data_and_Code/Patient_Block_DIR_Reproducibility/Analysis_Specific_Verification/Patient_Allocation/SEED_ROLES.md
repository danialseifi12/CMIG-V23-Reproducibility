# Random-number generators and grouping

- `20240517`: NumPy PCG64 site-stratified patient allocation; 40 calibration and 80 test among 120 eligible.
- `20240527`: 5,000-draw site-stratified source-anatomy Gate-5 coverage bootstrap with a fixed fitted width multiplier.

These are separate random-number streams. The study release uses different pseudonym namespaces for screening and analysis records. A study-team-confirmed, coded site-specific test-order linkage is available under `Coded_Patient_and_Registration_Linkage/`, but the hospital real-identity linkage key is not distributed. Run `python reproduce_partition.py` for allocation and `python Coded_Patient_and_Registration_Linkage/verify_coded_linkage.py` for the derived test-record linkage.

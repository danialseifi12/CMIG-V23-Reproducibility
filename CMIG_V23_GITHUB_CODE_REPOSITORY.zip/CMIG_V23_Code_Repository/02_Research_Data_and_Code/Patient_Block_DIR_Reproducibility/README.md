# Research data and code for the CMIG submission version 23

This is the complete released analysis repository, with inputs, scripts, current outputs, tests and figure sources. The article, supplement and stored publication artwork are excluded from this public code/data archive. Default execution requires no publication documents.

Use Python 3.12 in an isolated environment:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python run_complete_verification.py
```

The 20 components check source integrity, adjusted longitudinal models and true four-test Holm adjustment, actual intermediate Torch inference and WM regeneration, arithmetic dose reconciliation, numerical source preservation, calibration and source-summary consistency, clinical and controlled derived-data statistics, regression tests, interval score, percentile replay, coded allocation/linkage and conditional Gate 5 bootstrap. VERIFICATION_RUN_REPORT.json contains per-component results. The complete run uses no network after dependencies are installed.

Core_Statistical_Reproduction contains canonical clinical and endpoint tables, core code and tests. Its longitudinal_analysis_input.csv is the investigator-supplied final analysis table; the investigator attests its acquisition provenance. run_longitudinal_c04_models.py refits it, exports complete software summaries, machine-readable results and Holm_four_tests.csv. TRE Holm p=0.0033; noncoverage and relative TRE-to-axis p=0.0673; volume p<0.0001. TRE inference and CI use t79; other longitudinal tests use normal-Wald. The supplied 14-column design has rank 13 owing to site/stage overlap; the time contrast is estimable and the original finite-cluster correction is retained.

Dose_Constraint_Decision_Analysis contains the 432-row decision registry and internally matched reference/interval/limit inputs. Intermediate_Replay_Assets holds the supplied historical U/WM arrays, separate small checkpoint, coarse inputs, response parameters and generator. verify_intermediate_replay.py actually executes that replay and regenerates 43,200 WM samples. This small response network is distinct from the original five-level clinical model. The legacy reference_svf_mm input is used as displacement here without SVF exponentiation; the original grid convention is retained only for archived replay compatibility. See its README.md.

The canonical score, historical intermediate replay and decision extension have distinct absolute-dose coordinates. The full 432-row crosswalk verifies recorded decision reconciliation (13 D98/D95 pair exchanges with −2/+2 Gy shifts). Equal widths or containment do not establish identical interval centers or native physical transport. See RECONCILIATION_METHOD.md and CANONICAL_ANALYSIS_LAYERS.md.

Analysis_Specific_Verification contains formula-based interval-score checks, endpoint-local U/C percentile replay, coded patient allocation/linkage and fixed-label Gate 5 resampling. Historical WM generator reproduction does not change Gate 5 inference: that bootstrap still fixes archived endpoint labels and lambda rather than regenerating intervals or propagating a refit.

Release_Reconciliation checks the numerical derived-data consistency and supplies optional numerical plot builders. The public source archive reads no publication documents. Refit longitudinal outputs before rebuilding numerical plots. Clinical image panels are excluded. rerun_secondary_analyses.py reproduces the exported-scalar landmark analysis and conditional calibration resamples.

Restricted native clinical DICOM, RT planning data, original clinical weights and the complete native image-to-dose implementation are outside this repository. Clinical Table 5 is partially supported by released summaries, not a full native rerun. Native SVF scaling-and-squaring equations describe the original clinical method; the lightweight displacement replay is explicitly different. Numerical reproduction does not independently prove measurement acquisition, historical timestamps, model identity or physical cross-layer lineage. The study team's provenance attestation is recorded separately from what executable checks establish.

STATIC_FILE_SHA256.csv protects immutable released sources. CHECKSUMS.csv at package root records the complete delivery snapshot. Generated outputs may be rewritten by a rerun; verify the snapshot before executing the scripts, and use the static-source check during reruns.

The historical TABLE_S18_SOURCE_LEVEL.csv basename is retained unchanged and supports the current source-level summary (Supplementary Table S36, submitted separately).

#!/usr/bin/env python3
from pathlib import Path
import json, subprocess, sys
import numpy as np
import pandas as pd
from scripts.triage_metrics import summarize
from scripts.width_matching_fit import fit_lambda
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; OUT=ROOT/'outputs'; OUT.mkdir(exist_ok=True)
checks=[]
def ck(name,obs,exp,tol=0):
    ok=abs(float(obs)-float(exp))<=tol
    checks.append({'check':name,'observed':float(obs),'expected':float(exp),'tolerance':float(tol),'passed':bool(ok)})

def main():
    lf=pd.read_csv(DATA/'locked_test_fractions_enriched.csv')
    ck('locked_rows',len(lf),400)
    for mod,n,c in [('kV-CBCT',285,272),('Helical kVCT',60,54),('MVCT',55,53)]:
        g=lf[lf.acquisition_modality.eq(mod)]; ck(f'modality.{mod}.n',len(g),n); ck(f'modality.{mod}.covered',g.Coverage_0_1.sum(),c)
    tri=summarize(lf)
    for k,e,tol in [('tp',46,0),('fn',7,0),('fp',80,0),('tn',267,0),('auroc',0.8856505899624816,1e-12),('auprc',0.6056073113600279,1e-12)]: ck('triage.'+k,tri[k],e,tol)
    land=pd.read_csv(DATA/'landmark_level_containment_and_tre.csv')
    ck('landmarks.n',len(land),4000); ck('landmarks.inside',land.inside_conformal_ellipsoid.sum(),3979)
    agg=land.groupby(['patient_id','milestone']).inside_conformal_ellipsoid.min().reset_index()
    for m,e in [('M10',78),('M30',77),('M50',76),('M70',75),('M90',73)]: ck(f'landmarks.simultaneous.{m}',agg.loc[agg.milestone.eq(m),'inside_conformal_ellipsoid'].sum(),e)
    for site,tre,a in [('Prostate',1.33,3.17),('Head-and-Neck',1.55,3.90)]:
        g=land[land.anatomical_site.eq(site)]; ck(f'landmarks.{site}.tre_median',g.tre_mm.median(),tre,1e-12); ck(f'landmarks.{site}.axis_median',g.largest_semi_axis_mm.median(),a,1e-12)
    k=pd.read_csv(DATA/'multi_ensemble_k_sensitivity_raw.csv')
    ck('K50.accepted',k.acceptance_K50.sum(),104); ck('K100.accepted',k.acceptance_K100.sum(),105); ck('K200.accepted',k.acceptance_K200.sum(),106); ck('K100_K200.agreement',k.agreement_K100_K200.sum(),117)
    dose=pd.read_csv(DATA/'dose_constraint_crossings_and_surfaces.csv')
    ck('dose.n',len(dose),78); ck('dose.primary_crossings',dose.constraint_cross_uncalibrated.sum(),8); ck('dose.gamma_sim_crossings',dose.constraint_cross_gamma_sim.sum(),9); ck('dose.band_width_median',dose.cumulative_dose_band_width_gy.median(),2.27,1e-12)
    surf=pd.read_csv(DATA/'surface_correspondence_summary.csv')
    ck('surface.points',surf.dense_point_count.sum(),299100); ck('surface.rho_min',surf.spearman_rho.min(),0.29,1e-12); ck('surface.rho_max',surf.spearman_rho.max(),0.44,1e-12); ck('surface.rho_weighted',np.average(surf.spearman_rho,weights=surf.dense_point_count),0.371938816449348,1e-12)
    lam,hist=fit_lambda(); ck('width_fit.lambda_rounded',round(lam,3),1.081,1e-12); ck('width_fit.target_residual_abs',abs(hist[-1][3]),0.0,1e-4)
    sp=pd.read_csv(DATA/'source_pairs.csv'); ck('controlled.n',len(sp),432); ck('controlled.U',sp.Uncalibrated_Coverage_0_1.sum(),345); ck('controlled.WM',sp.WidthMatched_Coverage_0_1.sum(),367); ck('controlled.C',sp.DispersionCalibrated_Coverage_0_1.sum(),376); ck('controlled.high_severity_C',sp.loc[sp.Severity.eq('High'),'DispersionCalibrated_Coverage_0_1'].sum(),118)
    report={'all_passed':all(x['passed'] for x in checks),'checks':checks,'score_reconciliation_note':'Canonical frozen locked-test Triage_Score is retained; one legacy enriched export differed in one non-threshold-crossing score and was reconciled to the frozen source without changing flag or outcome.'}
    (OUT/'extended_validation_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    with (OUT/'extended_validation_report.txt').open('w',encoding='utf-8') as f:
        f.write(f"Extended validation: {sum(x['passed'] for x in checks)}/{len(checks)} checks passed\n")
        for x in checks: f.write(f"{'PASS' if x['passed'] else 'FAIL'}\t{x['check']}\t{x['observed']}\t(expected {x['expected']})\n")
    print(f"extended validation: {sum(x['passed'] for x in checks)}/{len(checks)} checks passed")
    return 0 if report['all_passed'] else 1
if __name__=='__main__': raise SystemExit(main())

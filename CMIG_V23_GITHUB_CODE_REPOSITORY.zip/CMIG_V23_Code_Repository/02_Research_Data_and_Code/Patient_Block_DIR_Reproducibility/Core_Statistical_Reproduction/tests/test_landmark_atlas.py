import unittest
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

class LandmarkAtlasTests(unittest.TestCase):
    def test_exact_atlas_counts_and_ids(self):
        d = pd.read_csv(ROOT / "data" / "landmark_atlas.csv")
        self.assertEqual(len(d), 20)
        self.assertEqual((d["Site"] == "Prostate").sum(), 8)
        self.assertEqual((d["Site"] == "Head-and-neck").sum(), 12)
        self.assertEqual(d["Landmark_ID"].nunique(), 20)
        self.assertEqual(set(d.loc[d["Site"]=="Prostate","Landmark_ID"]),
                         {f"P-LM{i:02d}" for i in range(1,9)})
        self.assertEqual(set(d.loc[d["Site"]=="Head-and-neck","Landmark_ID"]),
                         {f"H-LM{i:02d}" for i in range(1,13)})

    def test_atlas_rules_nonempty(self):
        d = pd.read_csv(ROOT / "data" / "landmark_atlas.csv")
        self.assertTrue(d["Landmark_Name"].astype(str).str.len().gt(0).all())
        self.assertTrue(d["Placement_Rule"].astype(str).str.len().gt(0).all())

if __name__ == "__main__":
    unittest.main()

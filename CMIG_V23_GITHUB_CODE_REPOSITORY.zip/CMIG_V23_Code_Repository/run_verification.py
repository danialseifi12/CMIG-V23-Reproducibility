#!/usr/bin/env python3
"""Run all 20 components from the extracted reviewer repository."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
repo=root/'02_Research_Data_and_Code/Patient_Block_DIR_Reproducibility'
raise SystemExit(subprocess.call([sys.executable,str(repo/'run_complete_verification.py')],cwd=repo))

#!/usr/bin/env python3
"""Check pseudonymous test/registration linkage against released analysis tables."""
import csv
from pathlib import Path
from collections import Counter
ROOT = Path(__file__).resolve().parent
REPRO = ROOT.parents[2]
def rows(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))
people=rows(ROOT / "patient_id_crosswalk_80.csv")
registrations=rows(ROOT / "fraction_registration_crosswalk_400.csv")
complete=rows(ROOT / "test_complete_course_dose_crosswalk_78.csv")
allocation=rows(ROOT.parent / "final_partition_manifest_120.csv")
locked=rows(REPRO / "Core_Statistical_Reproduction" / "data" / "locked_test_fractions.csv")
assert len(people)==80 and len(registrations)==400 and len(complete)==78
assert len(allocation)==120 and len(locked)==400
assert Counter(p["Site"] for p in people)=={"Prostate":40,"Head-and-neck":40}
assert Counter(p["Partition"] for p in allocation)=={"Test":80,"Calibration":40}
assert all(p["Partition"]=="Test" and p["Partition_Seed"]=="20240517" and p["Gate5_Bootstrap_Seed"]=="20240527" for p in people)
by_screen={p["Screen_ID"]:p for p in allocation if p["Partition"]=="Test"}
assert len(by_screen)==80
seen=set()
for p in people:
    a=by_screen[p["Registry_Screen_ID"]]
    for k in ("Site","Partition","Partition_Order","Dose_Complete","Dose_Evaluation_ID"):
        assert p[k]==a[k], (p["Legacy_Patient_ID"],k)
    ordinal=int(p["Partition_Order"])-20
    prefix="P_TEST_" if p["Site"]=="Prostate" else "H_TEST_"
    assert p["Legacy_Patient_ID"]==f"{prefix}{ordinal:03d}"
    assert int(p["Site_Test_Ordinal"])==ordinal
    assert p["Legacy_Patient_ID"] not in seen
    seen.add(p["Legacy_Patient_ID"])
assert len(seen)==80
raw_reg={(r["Patient_ID"],r["Registration_ID"],r["Fraction_ID"]) for r in locked}
expected=set()
for r in registrations:
    assert r["Legacy_Patient_ID"] in seen
    assert r["Legacy_Registration_ID"]==r["Legacy_Patient_ID"]+"_"+r["Milestone"]
    assert r["Registry_Registration_ID"]==r["Registry_Screen_ID"]+"_"+r["Milestone"]
    key=(r["Legacy_Patient_ID"],r["Legacy_Registration_ID"],r["Milestone"])
    assert key not in expected
    expected.add(key)
assert len(expected)==400 and expected==raw_reg
assert all(Counter(r["Milestone"] for r in registrations if r["Legacy_Patient_ID"]==p)=={"M10":1,"M30":1,"M50":1,"M70":1,"M90":1} for p in seen)
complete_from_people={p["Dose_Evaluation_ID"] for p in people if p["Dose_Complete"]=="1"}
complete_from_file={d["Dose_Evaluation_ID"] for d in complete}
assert len(complete_from_people)==78 and complete_from_file==complete_from_people
clinical_dose=rows(REPRO / "Core_Statistical_Reproduction" / "data" / "dose_constraint_crossings_and_surfaces.csv")
assert {r["evaluation_id"] for r in clinical_dose}==complete_from_file
print("PASS coded linkage: 80 test patients, 400 matching registrations, 78 complete-course dose IDs")

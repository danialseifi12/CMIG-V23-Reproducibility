#!/usr/bin/env python3
"""Numerical refit of investigator-supplied longitudinal table; not independent
measurement recovery or proof of a historical software run. Site/stage overlap
gives rank 13 of 14. Time is estimable; do not interpret aliased nuisance terms.
The retained finite-cluster correction counts all 14 design columns.
"""
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd,statsmodels.api as sm,statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from scipy.stats import norm,t as student_t
ROOT=Path(__file__).resolve().parents[1]

def run(input_path,output_dir):
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(input_path)
    assert len(df)==400 and df.Patient_ID.nunique()==80
    assert np.allclose(df.time20,(df.Course_Progress_Pct-10)/20)
    common='time20 + site_hn + C(Acquisition_Modality) + Artifact_Grade_Binary + '
    formulas={
      'volume':'log_ellipsoid_vol ~ '+common+'Log_Jacobian_Dispersion + C(Stage_Risk_Group)',
      'tre':'tre_mean_mm ~ '+common+'Quantitative_Artifact_Score + C(Stage_Risk_Group)',
      'relative_ratio':'tre_to_axis_ratio ~ '+common+'Quantitative_Artifact_Score + C(Stage_Risk_Group)',
      'noncoverage':'noncoverage_0_1 ~ time20 + site_hn'}
    models={}
    for key,f in formulas.items():
        models[key]=(smf.glm(f,data=df,family=sm.families.Binomial()).fit() if key=='noncoverage'
          else smf.ols(f,data=df).fit(cov_type='cluster',cov_kwds={'groups':df.Patient_ID}))
    # Same t79 distribution for the TRE test, CI, and software summary.
    models['tre'].use_t=True
    results={}
    for key,m in models.items():
        b=float(m.params['time20']);se=float(m.bse['time20'])
        dist=student_t(df.Patient_ID.nunique()-1) if key=='tre' else norm
        raw=float(2*dist.sf(abs(b/se)));q=float(dist.ppf(.975))
        ci=[b-q*se,b+q*se];trans=key in ('volume','noncoverage')
        X=m.model.exog;c=np.eye(X.shape[1])[m.model.exog_names.index('time20')]
        error=float(np.max(np.abs(c-c@np.linalg.pinv(X)@X)));assert error<1e-10
        results[key]=dict(formula=formulas[key],log_or_linear_beta=b,standard_error=se,
          estimate=float(np.exp(b)) if trans else b,ci95=np.exp(ci).tolist() if trans else ci,
          raw_p=raw,distribution='t79' if key=='tre' else 'normal-Wald',
          design_columns=int(X.shape[1]),design_rank=int(np.linalg.matrix_rank(X)),
          time_contrast_estimability_error=error)
    keys=list(results);raw=[results[k]['raw_p'] for k in keys]
    adjusted=multipletests(raw,method='holm')[1]
    ranks={keys[int(i)]:rank+1 for rank,i in enumerate(np.argsort(raw))}
    rows=[]
    for key,adj in zip(keys,adjusted):
        v=results[key];v['holm_p']=float(adj)
        v['reported_holm_p']='<0.0001' if adj<.0001 else f'{adj:.4f}'
        rows.append(dict(Hypothesis=key,Estimate=v['estimate'],CI_95_Lower=v['ci95'][0],
          CI_95_Upper=v['ci95'][1],Sidedness='Two-sided',Raw_p_value=v['raw_p'],
          Holm_Rank=ranks[key],Holm_Multiplier=5-ranks[key],Holm_Adjusted_p=float(adj),
          Manuscript_Reported_Holm_p=v['reported_holm_p']))
    pd.DataFrame(rows).sort_values('Holm_Rank').to_csv(out/'Holm_four_tests.csv',index=False)
    u=smf.ols('tre_mean_mm ~ time20 + site_hn',data=df).fit(cov_type='cluster',cov_kwds={'groups':df.Patient_ID})
    v=smf.mixedlm('log_ellipsoid_vol ~ time20 + site_hn',data=df,groups=df.Patient_ID).fit(reml=True)
    report=dict(input=Path(input_path).name,observations=len(df),patients=df.Patient_ID.nunique(),
      scope='Numerical refit of investigator-supplied table; no independent measurement or historical-run validation.',
      nuisance_aliasing='Site and stage overlap; time contrast estimable; original 14-column finite correction retained.',
      models=results,reduced_sensitivity=dict(tre_slope=float(u.params['time20']),volume_ratio=float(np.exp(v.params['time20']))))
    (out/'longitudinal_c04_results.json').write_text(json.dumps(report,indent=2)+'\n')
    lines=['LONGITUDINAL MODELS: REFIT OF INVESTIGATOR-SUPPLIED ANALYSIS TABLE',report['scope'],report['nuisance_aliasing']]
    for key,m in models.items():lines.extend([key,json.dumps(results[key]),m.summary().as_text()])
    (out/'longitudinal_c04_software_output.txt').write_text('\n\n'.join(lines)+'\n')
    print('PASS longitudinal refit and unmodified four-test Holm:',{k:v['reported_holm_p'] for k,v in results.items()})
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,default=ROOT/'data/longitudinal_analysis_input.csv')
    p.add_argument('--output-dir',type=Path,default=ROOT/'outputs')
    a=p.parse_args();run(a.input,a.output_dir)

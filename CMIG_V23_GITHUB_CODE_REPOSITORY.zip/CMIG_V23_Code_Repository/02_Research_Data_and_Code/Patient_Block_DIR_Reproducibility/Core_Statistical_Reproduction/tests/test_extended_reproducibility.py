from pathlib import Path
import json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
def test_extended_validation_passes():
    p=subprocess.run([sys.executable,str(ROOT/'run_extended_validation.py')],cwd=ROOT,capture_output=True,text=True)
    assert p.returncode==0, p.stdout+'\n'+p.stderr
    r=json.loads((ROOT/'outputs'/'extended_validation_report.json').read_text())
    assert r['all_passed']

import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PackageHygieneTests(unittest.TestCase):
    def test_environment_name_is_submission_neutral(self):
        first=(ROOT/"environment.yml").read_text(encoding="utf-8").splitlines()[0].strip()
        self.assertEqual(first, "name: dir-repro")

    def test_package_contents_do_not_intend_compiled_caches(self):
        text=(ROOT/"PACKAGE_CONTENTS.md").read_text(encoding="utf-8").lower()
        self.assertNotIn("__pycache__", text)
        self.assertNotIn(".pyc", text)

if __name__ == "__main__":
    unittest.main()

import unittest
from pathlib import Path
from analysis.statistics import gate3, controlled_source_analyses

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

class IntervalReportingSemanticsTests(unittest.TestCase):
    def test_gate3_one_sided_and_two_sided_bounds_are_distinct(self):
        r = gate3(DATA/"locked_test_fractions.csv", DATA/"clinical_bootstrap_replicates.csv")
        self.assertAlmostEqual(r["sensitivity_lower_one_sided_95"], 0.785714, 6)
        self.assertAlmostEqual(r["sensitivity_ci_two_sided_95_low"], 0.769231, 6)
        self.assertAlmostEqual(r["sensitivity_ci_two_sided_95_high"], 0.9523996, 6)
        self.assertAlmostEqual(r["npv_lower_one_sided_95"], 0.957854, 6)
        self.assertAlmostEqual(r["npv_ci_two_sided_95_low"], 0.954541025, 6)
        self.assertAlmostEqual(r["npv_ci_two_sided_95_high"], 0.992339175, 6)
        self.assertNotAlmostEqual(r["sensitivity_lower_one_sided_95"], r["sensitivity_ci_two_sided_95_low"], 6)
        self.assertNotAlmostEqual(r["npv_lower_one_sided_95"], r["npv_ci_two_sided_95_low"], 6)

    def test_interval_score_directional_and_two_sided_reporting_is_c_minus_u(self):
        r = controlled_source_analyses(DATA/"source_pairs.csv", DATA/"source_bootstrap_replicates.csv", DATA/"width_matched_bootstrap_replicates.csv")
        self.assertAlmostEqual(r["interval_score_upper_one_sided"], -0.00530665, 7)
        self.assertAlmostEqual(r["interval_score_ci_low_two_sided"], -0.342969, 6)
        self.assertAlmostEqual(r["interval_score_ci_high_two_sided"], 0.026442575, 6)
        self.assertAlmostEqual(r["interval_score_directional_p"], 0.0475696264, 8)
        self.assertAlmostEqual(r["interval_score_two_sided_normal_p"], 0.0951392527, 8)
        self.assertAlmostEqual(r["interval_score_difference_c_minus_u"], -0.1599999838, 7)

if __name__ == "__main__":
    unittest.main()

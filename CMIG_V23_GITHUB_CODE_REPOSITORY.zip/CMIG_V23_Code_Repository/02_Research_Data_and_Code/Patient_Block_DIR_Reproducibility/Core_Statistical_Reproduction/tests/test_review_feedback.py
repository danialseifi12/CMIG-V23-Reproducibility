import csv
import json
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class ReviewFeedbackTests(unittest.TestCase):
    def test_final_crosswalk_high_severity_primary_ci_matches_manuscript(self):
        p=ROOT/'docs'/'FINAL_RESULTS_CROSSWALK.csv'
        with p.open(encoding='utf-8') as fh:
            rows=list(csv.DictReader(fh))
        row=next(r for r in rows if r['analysis']=='High-severity containment')
        self.assertIn('0.756944-0.881944', row['ci_or_bound'])
        self.assertIn('0.746745-0.878534', row['ci_or_bound'])
        self.assertIn('source-anatomy bootstrap', row['method'])
    def test_run_script_uses_final_not_working_label(self):
        text=(ROOT/'run_analysis.py').read_text(encoding='utf-8').lower()
        self.assertIn('final submission validation', text)
        self.assertNotIn('working revision validation', text)
        log=(ROOT/'outputs'/'run_log.txt').read_text(encoding='utf-8').lower()
        self.assertIn('final submission validation', log)
        self.assertNotIn('working revision', log)
    def test_controlled_svf_seed_policy_disclaims_calendar_interpretation(self):
        cfg=json.loads((ROOT/'config'/'analysis_config.json').read_text(encoding='utf-8'))
        vals=[]
        def walk(o):
            if isinstance(o,dict):
                for k,v in o.items():
                    if k=='controlled_svf_seed_policy': vals.append(v)
                    walk(v)
            elif isinstance(o,list):
                for v in o: walk(v)
        walk(cfg)
        self.assertTrue(vals)
        self.assertTrue(all('should not be interpreted as calendar dates' in v for v in vals))
    def test_triage_provenance_anchors_retained_implementation(self):
        text=(ROOT/'docs'/'TRIAGE_CV_SELECTION_RULE.md').read_text(encoding='utf-8')
        self.assertIn('all 400 locked-test rows', text)
        self.assertIn('contemporaneous institutional SAP remains the controlling provenance document', text)

if __name__=='__main__': unittest.main()

import unittest
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]

class WidthParameterizationTests(unittest.TestCase):
    def test_config_records_bisection_and_truth_blind_fit(self):
        cfg=json.loads((ROOT/'config'/'analysis_config.json').read_text(encoding='utf-8'))
        meta=cfg['author_confirmed_metadata']
        wp=meta['width_matching_parameterization']
        self.assertEqual(wp['selection_method'], 'bisection on pooled controlled-reference scenario widths only')
        self.assertFalse(wp['truth_outcomes_used_in_fit'])
        self.assertAlmostEqual(float(wp['target_width_Gy']), 1.96, places=12)
        self.assertEqual(wp['conversion'], 'lambda_width = 1 + 0.10 * c_width')

    def test_reported_rounding(self):
        self.assertAlmostEqual(round(1.0 + 0.10*0.811936, 3), 1.081, places=3)

if __name__ == '__main__':
    unittest.main()

#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import pandas as pd
from pathlib import Path
from analysis.statistics import (gate1, gate1_tipping, gate1_power, gate2, gate3, controlled_source_analyses, triage_cv_selection, controlled_endpoint_summary, triage_rule_consistency, gate3_gee_sensitivity)

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

EXPECTED = {
    "gate1.estimate": (0.95, 1e-12),
    "gate1.ci_low": (0.8769012636, 2e-9),
    "gate1.ci_high": (0.9862106060, 2e-9),
    "gate1.p": (0.0223729974, 2e-9),
    "gate1_power.power_at_true_rate": (0.62888, 2e-5),
    "gate2.or": (1.369341, 2e-6),
    "gate2.upper_one_sided": (1.805793, 2e-6),
    "gate2.margin_p": (0.036836, 2e-6),
    "gate2.robust_upper_one_sided": (1.858054, 2e-6),
    "gate2.robust_margin_p": (0.052461, 2e-6),
    "gate3.sensitivity": (0.8679245283, 2e-10),
    "gate3.sensitivity_lower_one_sided_95": (0.785714, 2e-6),
    "gate3.sensitivity_ci_two_sided_95_low": (0.769231, 2e-6),
    "gate3.sensitivity_ci_two_sided_95_high": (0.9523996, 2e-7),
    "gate3.sensitivity_p_one_sided": (0.0103130474, 2e-9),
    "gate3.npv": (0.9744525547, 2e-10),
    "gate3.npv_lower_one_sided_95": (0.957854, 2e-6),
    "gate3.npv_ci_two_sided_95_low": (0.954541025, 2e-7),
    "gate3.npv_ci_two_sided_95_high": (0.992339175, 2e-7),
    "gate3.npv_p_one_sided": (0.0060599266, 2e-9),
    "controlled.containment_gain": (0.0717592593, 2e-10),
    "controlled.containment_gain_ci_low": (0.002315, 2e-6),
    "controlled.containment_gain_ci_high": (0.152778, 2e-6),
    "controlled.containment_gain_p": (0.0326200980, 2e-9),
    "controlled.containment_gain_t23_p": (0.0390817122, 2e-9),
    "controlled.high_severity_estimate": (0.8194444444, 2e-10),
    "controlled.high_severity_ci_low": (0.746745, 2e-6),
    "controlled.high_severity_ci_high": (0.878534, 2e-6),
    "controlled.high_severity_source_cluster_ci_low": (0.7569444444, 2e-9),
    "controlled.high_severity_source_cluster_ci_high": (0.8819444444, 2e-9),
    "controlled.site_uncalibrated_prostate": (0.8333333333, 2e-10),
    "controlled.site_uncalibrated_head_and_neck": (0.7638888889, 2e-10),
    "controlled.site_dispersion_calibrated_prostate": (0.8472222222, 2e-10),
    "controlled.site_dispersion_calibrated_head_and_neck": (0.8935185185, 2e-10),
    "controlled.site_width_matched_prostate": (0.8379629630, 2e-10),
    "controlled.site_width_matched_head_and_neck": (0.8611111111, 2e-10),
    "controlled.severity_uncalibrated_low": (0.8402777778, 2e-10),
    "controlled.severity_uncalibrated_medium": (0.8263888889, 2e-10),
    "controlled.severity_uncalibrated_high": (0.7291666667, 2e-10),
    "controlled.severity_width_matched_low": (0.8888888889, 2e-10),
    "controlled.severity_width_matched_medium": (0.8888888889, 2e-10),
    "controlled.severity_width_matched_high": (0.7708333333, 2e-10),
    "controlled.pooled_uncalibrated_width_median_Gy": (1.767867, 2e-9),
    "controlled.pooled_dispersion_calibrated_width_median_Gy": (1.9583765, 2e-9),
    "controlled.pooled_width_percent_increase": (10.7762348638, 2e-8),
    "controlled.width_matched_gain": (0.0208333333, 2e-10),
    "controlled.joint_c1_wm1": (357, 1e-12),
    "controlled.joint_c1_wm0": (19, 1e-12),
    "controlled.joint_c0_wm1": (10, 1e-12),
    "controlled.joint_c0_wm0": (46, 1e-12),
    "controlled.width_matched_ci_low": (0.0023148148, 2e-9),
    "controlled.width_matched_bootstrap_q25": (0.0138888889, 2e-10),
    "controlled.width_matched_bootstrap_median": (0.0208333333, 2e-10),
    "controlled.width_matched_bootstrap_q75": (0.0277777778, 2e-10),
    "controlled.width_matched_ci_high": (0.0416666667, 2e-10),
    "controlled.width_matched_superiority_p": (0.0290711991, 2e-9),
    "controlled.width_matched_ni_lower_one_sided": (0.0046296296, 2e-10),
    "controlled.width_matched_noninferiority_p": (0.0001022222, 2e-9),
    "controlled.width_matched_noninferiority_t23_p": (0.0005714021, 2e-9),
    "controlled.interval_score_difference_c_minus_u": (-0.1599999838, 2e-9),
    "controlled.interval_score_ci_low_two_sided": (-0.342969, 2e-6),
    "controlled.interval_score_ci_high_two_sided": (0.026442575, 2e-7),
    "controlled.interval_score_upper_one_sided": (-0.00530665, 2e-7),
    "controlled.interval_score_directional_p": (0.0475696264, 2e-9),
    "controlled.interval_score_two_sided_normal_p": (0.0951392527, 2e-9),
    "controlled.interval_score_t23_directional_p": (0.0543483983, 2e-9),
    "controlled.interval_score_wilcoxon_directional_p": (0.0505481958, 2e-9),
    "controlled.width_scale_internal_bootstrap_median": (0.811936, 2e-9),
    "controlled.lambda_width_operational_bootstrap_median": (1.0811936, 2e-9),
    "controlled.lambda_width_reported_rounded": (1.081, 1e-12),
    "forensic_integrity.width_adjusted_diff_mismatches": (0.0, 0.0),
    "forensic_integrity.config_width_matched_expected": (367.0, 0.0),
}


def flatten(prefix, obj, out):
    if isinstance(obj, dict):
        for k, v in obj.items():
            flatten(f"{prefix}.{k}" if prefix else k, v, out)
    else:
        out[prefix] = obj


def main():
    results = {}
    results["gate1"] = gate1(DATA / "locked_test_fractions.csv")
    results["gate1_power"] = gate1_power()
    results["gate2"] = gate2(DATA / "locked_test_fractions.csv")
    results["gate3"] = gate3(DATA / "locked_test_fractions.csv", DATA / "clinical_bootstrap_replicates.csv")
    results["gate3_gee_sensitivity"] = gate3_gee_sensitivity(DATA / "locked_test_fractions.csv")
    results["triage_rule_consistency"] = triage_rule_consistency(DATA / "locked_test_fractions.csv")
    results["controlled"] = controlled_source_analyses(DATA / "source_pairs.csv", DATA / "source_bootstrap_replicates.csv", DATA / "width_matched_bootstrap_replicates.csv")

    # Direct synchronization guards: final rowwise C-WM contrast and locked expected count.
    source_rows = pd.read_csv(DATA / "source_pairs.csv")
    c_minus_wm = source_rows["DispersionCalibrated_Coverage_0_1"].astype(int) - source_rows["WidthMatched_Coverage_0_1"].astype(int)
    width_diff_mismatches = int((source_rows["Width_Adjusted_Diff"].astype(int) != c_minus_wm).sum())
    cfg = json.loads((ROOT / "config" / "analysis_config.json").read_text(encoding="utf-8"))
    results["forensic_integrity"] = {
        "width_adjusted_diff_mismatches": width_diff_mismatches,
        "config_width_matched_expected": int(cfg["expected_counts"]["width_matched_contained"]),
    }

    flat = {}
    flatten("", results, flat)
    checks = []
    for key, (expected, tol) in EXPECTED.items():
        observed = float(flat[key])
        passed = abs(observed - expected) <= tol
        checks.append({"check": key, "observed": observed, "expected": expected, "tolerance": tol, "passed": passed})

    report = {"all_passed": all(c["passed"] for c in checks), "checks": checks, "results": results}
    with open(OUT / "validation_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    with open(OUT / "results.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["statistic", "value"])
        for k in sorted(flat):
            if isinstance(flat[k], (int, float)):
                w.writerow([k, flat[k]])

    gate1_tipping(n=results["gate1"]["n"], base_successes=results["gate1"]["successes"]).to_csv(OUT / "gate1_tipping_point_recomputed.csv", index=False)

    controlled_endpoint_summary(DATA / "source_pairs.csv").to_csv(OUT / "controlled_endpoint_summary.csv", index=False)

    # Recompute the documented global calibration-CV selection rule through the
    # same tested helper used by the regression suite.
    cv_result = triage_cv_selection(DATA / "triage_cv_fold_grid.csv")
    cv_result["summary"].to_csv(DATA / "triage_cv_candidate_summary.csv", index=False)

    with open(OUT / "run_log.txt", "w", encoding="utf-8") as f:
        f.write(f"Final submission validation: {sum(c['passed'] for c in checks)}/{len(checks)} checks passed\n")
        f.write("Gate 3 p-values are recomputed by patient-cluster null score tests.\n")
        f.write("Gate 3 one-sided 95% lower bounds and complementary two-sided 95% CIs are recomputed separately from archived patient-cluster bootstrap summaries.\n")
        f.write("Controlled-source C-U CIs are recomputed from archived source-anatomy bootstrap summaries; the finalized pooled-median-width contrast is recomputed from its dedicated 5,000-replicate disease-site-stratified source-anatomy bootstrap file.\n")
        f.write("Controlled-source p-values are recomputed from 24 source-anatomy paired contributions; t(23) and Wilcoxon small-sample sensitivities are also reported.\n")
        f.write("Width matching distinguishes the internal c_width coefficient from operational lambda_width=1+0.10*c_width.\n")
        f.write("Interval-score rows are explicitly C-U (dispersion-calibrated minus uncalibrated), not width-matched.\n")
        f.write("Calibration CV selection requires fold feasibility in all five folds, then minimizes mean review rate.\n" )
        f.write("Gate 1 is recomputed directly from the 80 locked M50 rows rather than from a hard-coded numerator.\n" )
        f.write("Endpoint-level controlled-reference summaries are regenerated directly from source_pairs.csv.\n" )
        f.write("Cross-source consistency checks independently lock site and severity aggregates (including width-matched subgroups), pooled controlled-width medians, joint C-WM counts, rowwise C-WM contrasts, config expectations, the dedicated regenerated 5,000-replicate C-WM bootstrap, and the machine-readable Table S36 source to source_pairs.csv.\n")
        f.write("High-severity containment includes a disease-site-stratified source-anatomy bootstrap CI.\n")

    print(f"validation: {sum(c['passed'] for c in checks)}/{len(checks)} checks passed")
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

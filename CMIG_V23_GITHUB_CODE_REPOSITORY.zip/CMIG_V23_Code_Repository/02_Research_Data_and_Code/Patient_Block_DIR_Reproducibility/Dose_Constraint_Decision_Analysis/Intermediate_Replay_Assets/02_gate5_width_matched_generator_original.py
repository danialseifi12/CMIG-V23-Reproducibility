#!/usr/bin/env python3
from pathlib import Path
import argparse, csv
import numpy as np

def fit_lambda(widths, target=1.9600, lo=1.0, hi=1.25, tol=1e-4, n=24):
    widths=np.asarray(widths,float)
    hist=[]
    for i in range(1,n+1):
        lam=(lo+hi)/2
        med=float(np.median(widths*lam))
        hist.append((i,lam,med,med-target))
        if abs(med-target)<tol:
            break
        if med<target: lo=lam
        else: hi=lam
    return lam,hist

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--samples", default="02_uncalibrated_ensemble_432x100.npz")
    p.add_argument("--lambda-inputs", default="02_lambda_fit_inputs_72.csv")
    p.add_argument("--params", default="03_local_response_parameters_432.csv")
    p.add_argument("--output", default="02_width_matched_pretable_432.csv")
    p.add_argument("--sample-output", default="02_width_matched_samples_432x100.npz")
    a=p.parse_args()

    with open(a.lambda_inputs,newline="",encoding="utf-8") as f:
        lr=list(csv.DictReader(f))
    lam,hist=fit_lambda([float(r["uncalibrated_scenario_width_gy"]) for r in lr])

    A=np.load(a.samples)
    pair_ids=A["pair_ids"].astype(str)
    U=A["uncalibrated_dose_gy"].astype(float)
    pos={p:i for i,p in enumerate(pair_ids)}
    with open(a.params,newline="",encoding="utf-8") as f:
        params=list(csv.DictReader(f))

    WM=np.empty_like(U)
    rows=[]
    for r in params:
        i=pos[r["Pair_ID"]]
        u=U[i]
        q05,q95=np.percentile(u,[5,95],method="linear")
        ctr=(float(q05)+float(q95))/2.0
        gain=float(r["Local_Response_Gain"])
        shift=float(r["Center_Shift_Gy"])
        wm=ctr + lam*gain*(u-ctr) + shift
        WM[i]=wm
        L,U95=np.percentile(wm,[5,95],method="linear")
        rows.append({
            "Pair_ID":r["Pair_ID"],"Scenario_ID":r["Scenario_ID"],"Endpoint":r["Endpoint"],
            "P05_Gy":f"{L:.12f}","P95_Gy":f"{U95:.12f}",
            "Width_Gy":f"{U95-L:.12f}","Lambda_Width":f"{lam:.12f}",
            "Local_Response_Gain":f"{gain:.12f}","Center_Shift_Gy":f"{shift:.12f}"
        })

    with open(a.output,"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    np.savez_compressed(a.sample_output,pair_ids=pair_ids,width_matched_dose_gy=WM,
                        lambda_width=np.array([lam],float))

if __name__=="__main__":
    main()

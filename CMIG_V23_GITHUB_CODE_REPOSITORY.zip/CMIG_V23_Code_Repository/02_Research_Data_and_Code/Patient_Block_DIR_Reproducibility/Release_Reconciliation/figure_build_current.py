"""Build current numerical artwork from released rows and identified summaries.

Clinical image pixels are excluded; only numerical plots and schematics are generated. Model-implied trajectories and dense
geometry intervals visualize retained institutional summaries. Longitudinal slopes
and adjusted p values use the supplied analysis-table refit; these are not native image runs.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, gc, io, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from scipy.stats import beta
import fitz
from PIL import Image

R=Path(__file__).resolve().parents[1]
P=R.parents[1]
D=R/'Core_Statistical_Reproduction/data'
V=R/'Release_Reconciliation'
hp=json.loads((R/'Core_Statistical_Reproduction/outputs/longitudinal_c04_results.json').read_text())['models']
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=V/'regenerated_figures')
args=parser.parse_args()
J=args.output_dir.resolve();J.mkdir(parents=True,exist_ok=True)
(J/'Figures').mkdir(exist_ok=True);(J/'Supplementary_Figures').mkdir(exist_ok=True)
E=J/'Vector_Artwork';E.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.titlesize':10,'axes.labelsize':9,'legend.fontsize':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'path','svg.hashsalt':'CMIG-current-artwork','savefig.facecolor':'white'})
BLUE='#216899';GREEN='#21835a';PURPLE='#765191';GRAY='#71818c'
records={}
def save(fig,rel,record):
    path=J/rel;path.parent.mkdir(parents=True,exist_ok=True)
    stem=path.stem
    # Canonical vector master first; rasterize its complete page in memory.
    # Atomic writes and CRC/decode checks reject truncated production artwork.
    pb=io.BytesIO();fig.savefig(pb,format='pdf',metadata={'CreationDate':None,'ModDate':None,'Creator':'CMIG numerical artwork'})
    pdfbytes=pb.getvalue();(E/(stem+'.pdf')).write_bytes(pdfbytes)
    sb=io.BytesIO();fig.savefig(sb,format='svg',metadata={'Date':None,'Creator':'CMIG numerical artwork'});(E/(stem+'.svg')).write_bytes(sb.getvalue())
    pdf=fitz.open(stream=pdfbytes,filetype='pdf');pix=pdf[0].get_pixmap(dpi=1000,alpha=False)
    if path.suffix=='.png':payload=pix.tobytes('png')
    else:
        im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
        buf=io.BytesIO();im.save(buf,format='JPEG',quality=97,subsampling=0,dpi=(1000,1000));payload=buf.getvalue()
    with Image.open(io.BytesIO(payload)) as check:check.verify()
    with Image.open(io.BytesIO(payload)) as check:check.load()
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_bytes(payload);os.replace(tmp,path)
    assert hashlib.sha256(path.read_bytes()).digest()==hashlib.sha256(payload).digest()
    del pix,pdf,payload
    records[rel]=record
    plt.close(fig);gc.collect()
def title(ax,text):ax.set_title(text,loc='left',fontweight='bold',pad=10)
def box(ax,x,y,w,h,text,fc='#f4f7fa',fs=8):
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.015',linewidth=.8,edgecolor='#415867',facecolor=fc)
    ax.add_patch(p);ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs)
def arrow(ax,x1,y1,x2,y2):ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=9,color='#415867',linewidth=.8))
def canvas(ax,name):
    ax.set(xlim=(-.025,1.025),ylim=(-.02,1.07));ax.axis('off');ax.text(0,1.085,name,ha='left',va='bottom',fontweight='bold',fontsize=10)

fr=pd.read_csv(D/'locked_test_fractions_enriched.csv')
lm=pd.read_csv(D/'landmark_level_containment_and_tre.csv')
sp=pd.read_csv(D/'source_pairs.csv')
secondary=json.loads((V/'release_reconciliation_results.json').read_text())

# Figure 1: classic design and the current verified scientific content.
from build_figure1_classic import create_figure
previous_rc=plt.rcParams.copy()
fig=create_figure()
save(fig,'Figure_1_Artwork.png',{'source':'Study design, Methods 2.2/2.9/2.13','clinical_n':120,'calibration_n':40,'test_n':80,'test_fractions':400,'test_landmarks':4000,'dose_complete_test_n':78,'Q':[11.4,12.7],'dense_gamma':[1.059,1.102],'K':100})
plt.rcParams.update(previous_rc)

# Figure 2: observed coverage and explicitly model-implied anchored trajectories.
fig,axs=plt.subplots(1,3,figsize=(8.4,5.2));fig.subplots_adjust(left=.065,right=.98,top=.88,bottom=.29,wspace=.40)
milestones=['M10','M30','M50','M70','M90'];x=np.arange(5)
coverage={}
for site,color,label,marker in [('Prostate',GREEN,'Prostate','s'),('Head-and-neck',PURPLE,'Head and neck','^')]:
    vals=fr[fr.Site.eq(site)].groupby('Fraction_ID').Coverage_0_1.mean().reindex(milestones).to_numpy()*100
    coverage[site]=vals.tolist();axs[0].plot(x,vals,marker=marker,color=color,label=label,ms=4)
vals=fr.groupby('Fraction_ID').Coverage_0_1.mean().reindex(milestones).to_numpy()*100
coverage['Pooled']=vals.tolist();axs[0].plot(x,vals,'o-',color=BLUE,label='Pooled',ms=4)
axs[0].axhline(95,ls='--',lw=.8,color=GRAY);axs[0].set(ylim=(88,101),ylabel='Patient-block coverage (%)');axs[0].legend(loc='lower left',fontsize=6.5)
title(axs[0],'A  Observed coverage')
relative=x-2;volume_p=105.4*1.036**relative;volume_h=194.2*1.036**relative
tre_p=1.33+.045*relative;tre_h=1.55+.045*relative
for ax,p,h,pool,ylabel,name in [(axs[1],volume_p,volume_h,np.sqrt(volume_p*volume_h),'Ellipsoid volume (mm³)','B  Model-implied volume'),(axs[2],tre_p,tre_h,(tre_p+tre_h)/2,'TRE (mm)','C  Model-implied TRE')]:
    for values,color,label,marker in [(p,GREEN,'Prostate','s'),(h,PURPLE,'Head and neck','^'),(pool,BLUE,'Site-standardized','o')]:ax.plot(x,values,marker=marker,color=color,label=label,ms=4)
    ax.set_ylabel(ylabel);title(ax,name)
axs[1].set_ylim(80,240);axs[2].set_ylim(1.1,1.95)
for a in axs:a.set_xticks(x,milestones,rotation=35);a.grid(axis='y',alpha=.2);a.set_xlabel('Milestone')
axs[1].legend(loc='upper left',fontsize=6)
fig.text(.065,.13,f'Noncoverage OR: 1.369\nTwo-sided 95% CI: 0.985-1.904\nHolm two-sided trend p = {hp["noncoverage"]["holm_p"]:.4f}',fontsize=7)
fig.text(.38,.13,'M50 anchors: 105.4 / 194.2 mm³\nRatio per +20%: 1.036\nHolm p < 0.0001',fontsize=7)
fig.text(.72,.13,f'M50 anchors: 1.33 / 1.55 mm\nSlope per +20%: +0.045 mm\nHolm p = {hp["tre"]["holm_p"]:.4f}',fontsize=7)
fig.text(.065,.025,'B-C show fitted longitudinal effects using institutional M50 anchors; they are not raw milestone medians.',fontsize=7)
save(fig,'Figures/Figure_2.png',{'source':'A: locked_test_fractions_enriched.csv; B-C: retained institutional estimates, Manuscript Table 2','coverage_percent':coverage,'M50_volume_anchors_mm3':[105.4,194.2],'volume_ratio':1.036,'volume_Holm_p':'<0.0001','M50_TRE_anchors_mm':[1.33,1.55],'TRE_slope_per20_mm':.045,'TRE_Holm_p':hp['tre']['holm_p'],'noncoverage_Holm_p':hp['noncoverage']['holm_p'],'volume_p':volume_p.tolist(),'volume_h':volume_h.tolist(),'tre_p':tre_p.tolist(),'tre_h':tre_h.tolist()})

# Clinical image panels are excluded from the public code/data archive.

# Figure 4: keyed 80-patient by five-milestone coverage display.
from matplotlib.colors import ListedColormap
fig,axs=plt.subplots(1,2,figsize=(8.4,7.6));fig.subplots_adjust(left=.12,right=.97,top=.91,bottom=.08,wspace=.45)
heatmap_ids={}
for a,site in zip(axs,['Prostate','Head-and-neck']):
    matrix=fr[fr.Site.eq(site)].pivot(index='Patient_ID',columns='Fraction_ID',values='Coverage_0_1').reindex(columns=milestones)
    order=sorted(matrix.index,key=lambda pid:(next((i for i,v in enumerate(matrix.loc[pid]) if v==0),5),str(pid)))
    matrix=matrix.loc[order];heatmap_ids[site]=order
    a.pcolormesh(np.arange(6),np.arange(41),matrix.to_numpy(),cmap=ListedColormap(['#d76c62','#58a56a']),vmin=0,vmax=1,edgecolors='white',linewidth=.4)
    a.set(xlim=(0,5),ylim=(40,0));a.set_xticks(np.arange(5)+.5,milestones)
    a.set_yticks(np.arange(40)+.5,[str(i) for i in order],fontsize=5.8)
    a.tick_params(length=0);title(a,site.replace('Head-and-neck','Head and neck')+' (n = 40)')
fig.suptitle('Locked-test patient-block coverage across treatment',fontweight='bold',fontsize=12)
fig.text(.12,.022,'Green: all landmarks contained. Red: at least one landmark outside. Rows are ordered by earliest undercoverage.',fontsize=7)
save(fig,'Figures/Figure_4.jpeg',{'source':'locked_test_fractions_enriched.csv','patient_order':heatmap_ids,'patients':80,'fractions':400,'any_undercoverage':17,'both_late_undercoverage':4})

# Figure 5: retain Table 6 institutional dense-geometry summaries exactly.
geometry={'coverage':[96.1,94.5,92.7],'CI_lower':[94.3,92.7,90.9],'CI_upper':[97.5,95.9,94.1],'median_error_mm':[1.24,1.59,2.10],'median_ellipsoid_volume_mm3':[126,158,211]}
fig,axs=plt.subplots(1,3,figsize=(8.4,4.7));fig.subplots_adjust(left=.075,right=.97,top=.86,bottom=.24,wspace=.42)
x3=np.arange(3);cov=np.array(geometry['coverage'])
axs[0].errorbar(x3,cov,yerr=np.vstack([cov-geometry['CI_lower'],np.array(geometry['CI_upper'])-cov]),fmt='o-',color=BLUE,capsize=3)
axs[0].set(ylabel='Dense-point containment (%)',ylim=(88,100));title(axs[0],'A  Empirical containment')
for i,v in enumerate(cov):axs[0].annotate(f'{v:.1f}%',(i,v),xytext=(3,10),textcoords='offset points',fontsize=8)
for ax,key,ylabel,name in [(axs[1],'median_error_mm','Median known error (mm)','B  Known geometric error'),(axs[2],'median_ellipsoid_volume_mm3','Median volume (mm³)','C  Ellipsoid volume')]:
    vals=geometry[key];ax.plot(x3,vals,'o-',color=BLUE);ax.set_ylabel(ylabel);title(ax,name)
    for i,v in enumerate(vals):ax.annotate(f'{v:.2f}' if key=='median_error_mm' else str(v),(i,v),xytext=(3,8),textcoords='offset points',fontsize=8)
    ax.margins(y=.22)
for ax in axs:ax.set_xticks(x3,['Low','Medium','High']);ax.set_xlabel('Deformation challenge');ax.grid(axis='y',alpha=.2)
fig.text(.075,.085,'24 independent source anatomies; retained source-cluster 95% intervals in A.\nDense-point results are empirical and do not imply 95% dense-field conformal coverage.',fontsize=7.5)
save(fig,'Figures/Figure_5.png',{'source':'Manuscript Table 6 retained institutional summaries; raw dense coordinates not released',**geometry})

# Figure 6: endpoint containment from all 432 released records.
cols=['Uncalibrated_Coverage_0_1','WidthMatched_Coverage_0_1','DispersionCalibrated_Coverage_0_1']
counts=sp[cols].sum().astype(int).tolist();rates=np.array(counts)/len(sp)*100
fig,axs=plt.subplots(1,2,figsize=(8.4,3.8));fig.subplots_adjust(left=.075,right=.98,top=.82,bottom=.24,wspace=.35)
for a,values,labels,name in [(axs[0],rates[[0,2]],['Uncalibrated','Dispersion\ncalibrated'],'A  Dispersion calibration'),(axs[1],rates[[1,2]],['Pooled-width\nmatched','Dispersion\ncalibrated'],'B  Conditional pooled-width comparison')]:
    a.bar([0,1],values,color=[GRAY,BLUE],width=.58)
    a.set(ylim=(0,100),ylabel='Dose-endpoint containment (%)');a.set_xticks([0,1],labels);title(a,name);a.grid(axis='y',alpha=.2);a.set_axisbelow(True)
    for i,v in enumerate(values):a.text(i,v+2,f'{v:.2f}%',ha='center',fontweight='bold',fontsize=9)
axs[0].axhline(90,color=BLUE,ls='--',lw=.9)
axs[0].text(.5,.12,'C-U: +7.18 pp\n95% CI +0.23 to +15.28; p = 0.0326',transform=axs[0].transAxes,ha='center',fontsize=7,bbox={'facecolor':'white','edgecolor':'#ccd5db','pad':5})
axs[1].text(.5,.12,'Conditional C-WM: +2.08 pp\n95% CI +0.23 to +4.17; nominal p = 0.0291\nNominal noninferiority p = 0.0001',transform=axs[1].transAxes,ha='center',fontsize=6.8,bbox={'facecolor':'white','edgecolor':'#ccd5db','pad':5})
save(fig,'Figures/Figure_6.png',{'source':'source_pairs.csv; fixed-label source-bootstrap summaries','n':432,'U_WM_C_counts':counts,'percent':rates.tolist(),'C_minus_U_pp':(counts[2]-counts[0])/432*100,'C_minus_WM_pp':(counts[2]-counts[1])/432*100,'WM_inference':'conditional descriptive; no width refit or endpoint regeneration'})

# S1: primary recorded course modality, as distinct from fraction acquisitions.
fig,ax=plt.subplots(figsize=(8.4,4.6));fig.subplots_adjust(left=.12,right=.97,top=.80,bottom=.22)
ax.bar(['kV-CBCT','Helical kVCT','MVCT'],[40,20,20],color=[BLUE,'#698b9c','#a8b9c2'],width=.58)
ax.set(ylim=(0,48),ylabel='Patients (n = 80)');ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
for i,n in enumerate([40,20,20]):ax.text(i,n+1.2,str(n),ha='center',fontweight='bold',fontsize=12)
fig.suptitle('Locked-test cohort by primary course modality',fontweight='bold',fontsize=13)
fig.text(.12,.06,'Descriptive patient-level allocation from Supplementary Table S32; fraction-level modality counts are reported separately.',fontsize=7.5)
save(fig,'Supplementary_Figures/Supplementary_Figure_S1.jpeg',{'source':'Supplementary Table S32 primary course allocation','patient_counts':[40,20,20],'n':80,'level':'patient'})

# S2: six actual archived structure summaries; no unsupported confidence intervals.
surface=pd.read_csv(D/'surface_correspondence_summary.csv')
names={'Prostate_Gland':'Prostate gland','Rectum_Anterior':'Anterior rectum wall','Bladder_Posterior':'Posterior bladder wall','Parotid_Ipsilateral':'Ipsilateral parotid','Parotid_Contralateral':'Contralateral parotid','Spinal_Cord':'Spinal cord'}
fig,axs=plt.subplots(1,2,figsize=(8.4,4.5),sharey=True);fig.subplots_adjust(left=.29,right=.97,top=.82,bottom=.23,wspace=.33)
y=np.arange(6);colors=[BLUE]*3+[PURPLE]*3
axs[0].scatter(surface.spearman_rho,y,c=colors,s=34,zorder=3);axs[1].scatter(surface.mean_surface_distance_mm,y,c=colors,s=34,zorder=3)
axs[0].set(xlim=(0,.53),xlabel='Structure-level Spearman correlation');axs[1].set(xlim=(0,2.25),xlabel='Mean surface distance (mm)')
title(axs[0],'A  Uncertainty and discrepancy');title(axs[1],'B  Surface discrepancy')
axs[0].set_yticks(y,[f'{names[s]} (n={int(n):,})' for s,n in zip(surface.structure,surface.dense_point_count)],fontsize=8)
axs[0].invert_yaxis()
for a in axs:a.set_axisbelow(True);a.grid(axis='x',alpha=.2)
for i,row in enumerate(surface.itertuples()):
    axs[0].text(row.spearman_rho+.015,i,f'{row.spearman_rho:.2f}',va='center',fontsize=8)
    axs[1].text(row.mean_surface_distance_mm+.05,i,f'{row.mean_surface_distance_mm:.2f}',va='center',fontsize=8)
weighted=float(np.average(surface.spearman_rho,weights=surface.dense_point_count))
fig.suptitle('Six archived boundary subregions',fontsize=13,fontweight='bold')
fig.text(.29,.065,f'Total points: {int(surface.dense_point_count.sum()):,}; point-count-weighted mean correlation: {weighted:.4f}',fontsize=7.5)
save(fig,'Supplementary_Figures/Supplementary_Figure_S2.png',{'source':'surface_correspondence_summary.csv','rows':surface.to_dict('records'),'points':int(surface.dense_point_count.sum()),'weighted_mean_structure_rho':weighted,'CI':'not estimated from aggregate rows'})

# S3: stated K-sensitivity summaries, with count support from the released rows.
kraw=pd.read_csv(D/'multi_ensemble_k_sensitivity_raw.csv')
kcounts=[int(kraw[f'acceptance_K{k}'].sum()) for k in [50,100,200]]
fig,axs=plt.subplots(1,2,figsize=(8.4,3.8));fig.subplots_adjust(left=.09,right=.97,top=.83,bottom=.28,wspace=.32)
axs[0].plot([50,100,200],[5.28,3.16,1.54],'o-',color=BLUE);axs[0].set(xlabel='Ensemble size K',ylabel='Repeat-level band-width CV (%)');title(axs[0],'A  Retained width stability')
axs[1].plot([50,100,200],np.array(kcounts)/120*100,'o-',color=BLUE);axs[1].set(xlabel='Ensemble size K',ylabel='Endpoint containment (%)',ylim=(85,90));title(axs[1],'B  Controlled-reference containment')
for a in axs:a.set_xticks([50,100,200]);a.grid(alpha=.2)
fig.text(.09,.07,'Same 20-sequence subset: 120 endpoints. K100/K200 agreement: 117/120 (97.5%).\nMedian absolute P05/P95 shifts: 0.06/0.07 Gy. Width CV uses retained repeat-level summaries.',fontsize=7.5)
save(fig,'Supplementary_Figures/Supplementary_Figure_S3.png',{'source':'multi_ensemble_k_sensitivity_raw.csv for counts; Supplementary Table S24 for repeat-level width CV','K':[50,100,200],'width_CV_percent':[5.28,3.16,1.54],'contained_counts':kcounts,'n':120,'agreement':117,'median_abs_percentile_shift_Gy':[.06,.07]})

# S4: plot every released paired landmark, not an unavailable historical predictor.
g=secondary['landmark_descriptive']
fig,ax=plt.subplots(figsize=(8.4,5.6));fig.subplots_adjust(left=.10,right=.98,top=.84,bottom=.23)
ax.scatter(lm.largest_semi_axis_mm,lm.tre_mm,s=9,facecolors='none',edgecolors=BLUE,alpha=.24,linewidths=.55)
ax.axhline(3,color=BLUE,ls=':',lw=1.2,label='High-error threshold: TRE >3 mm');ax.legend(loc='upper left')
ax.set(xlabel='General-purpose exported uncertainty scalar (mm)',ylabel='Euclidean landmark TRE (mm)');ax.grid(alpha=.2)
fig.suptitle('Released uncertainty scalar and landmark error',fontweight='bold',fontsize=12)
ax.set_title(f'Spearman rho = {g["spearman_rho"]["point"]:.3f}; AUROC = {g["AUROC"]["point"]:.3f}; average precision = {g["average_precision"]["point"]:.3f}',fontsize=9)
fig.text(.10,.07,'4,000 paired observations; 80 patients; 28 high-error events. Descriptive released-scalar analysis.\nThis is not a reconstruction of the historical locked final-conformal predictor.',fontsize=7.5)
save(fig,'Supplementary_Figures/Supplementary_Figure_S4.png',{'source':'landmark_level_containment_and_tre.csv; released-scalar secondary summaries','n':4000,'patients':80,'high_TRE_count':int(lm.tre_mm.gt(3).sum()),'spearman_rho':g['spearman_rho']['point'],'AUROC':g['AUROC']['point'],'average_precision':g['average_precision']['point']})

# S5: primary patient-bootstrap CIs for sensitivity/NPV; descriptive exact CIs for
# specificity/PPV. The distinction is explicit in both artwork and caption.
tp,fn,fp,tn=46,7,80,267
clinical_bs=pd.read_csv(D/'clinical_bootstrap_replicates.csv')
def exact_ci(k,n):return [0 if k==0 else beta.ppf(.025,k,n-k+1),1 if k==n else beta.ppf(.975,k+1,n-k)]
metrics=[('Sensitivity',tp/(tp+fn),np.quantile(clinical_bs.Sensitivity,[.025,.975]),'Patient bootstrap'),('Specificity',tn/(tn+fp),exact_ci(tn,tn+fp),'Descriptive exact'),('PPV',tp/(tp+fp),exact_ci(tp,tp+fp),'Descriptive exact'),('NPV',tn/(tn+fn),np.quantile(clinical_bs.NPV,[.025,.975]),'Patient bootstrap')]
fig,ax=plt.subplots(figsize=(8.4,4.7));fig.subplots_adjust(left=.10,right=.97,top=.80,bottom=.24)
for i,(name,point,ci,kind) in enumerate(metrics):
    color=BLUE if kind=='Patient bootstrap' else GRAY
    ax.bar(i,point*100,color=color,width=.55)
    ax.errorbar(i,point*100,yerr=[[100*(point-ci[0])],[100*(ci[1]-point)]],fmt='none',ecolor='#263b49',capsize=4)
    ax.text(i,point*100/2,f'{point*100:.1f}%',ha='center',va='center',color='white',fontweight='bold',fontsize=11)
ax.set(ylim=(0,105),ylabel='Operating characteristic (%)');ax.set_xticks(range(4),[m[0] for m in metrics]);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
fig.suptitle('Frozen review rule at the locked operating point',fontweight='bold',fontsize=12)
ax.set_title('126/400 fractions flagged; TP/FN/FP/TN = 46/7/80/267',fontsize=9)
fig.text(.10,.07,'Blue: patient-bootstrap two-sided 95% intervals. Gray: descriptive exact two-sided 95% intervals.\nPrimary patient-cluster null-score p: sensitivity 0.0103; NPV 0.0061.',fontsize=7.5)
save(fig,'Supplementary_Figures/Supplementary_Figure_S5.png',{'source':'locked fraction counts and clinical_bootstrap_replicates.csv','TP_FN_FP_TN':[tp,fn,fp,tn],'metrics':[{'name':n,'point':p,'CI95':[float(z) for z in ci],'CI_type':kind} for n,p,ci,kind in metrics]})

# S6: exact conditional radius distribution and explicitly institutional test summary.
fig,axs=plt.subplots(1,2,figsize=(8.4,4.1));fig.subplots_adjust(left=.095,right=.98,top=.82,bottom=.32,wspace=.40)
for i,site in enumerate(['Prostate','Head-and-neck']):
    c=secondary['calibration'][site];color=[BLUE,PURPLE][i]
    axs[0].plot([i,i],[c['exact_support_min_radius'],c['exact_support_max_radius']],lw=2,color=color)
    for v in [np.sqrt(c['second_largest_Q']),c['radius']]:axs[0].plot([i-.09,i+.09],[v,v],lw=4,color=color)
    axs[0].plot(i,c['radius'],'o',color=color)
axs[0].set_xticks([0,1],['Prostate','Head and neck']);axs[0].set(xlim=(-.4,1.4),ylim=(3.20,3.60),ylabel='Simultaneous calibration radius');title(axs[0],'A  Conditional radius sensitivity')
xx=np.arange(2);axs[1].bar(xx-.17,[97.5,92.5],.34,color=BLUE,label='Locked n=20');axs[1].bar(xx+.17,[97.5,90],.34,color=GRAY,label='Worst delete-one n=19')
axs[1].axhline(95,ls=':',lw=1,color=BLUE);axs[1].set_xticks(xx,['Prostate','Head and neck']);axs[1].set(ylim=(85,100),ylabel='M50 patient-block coverage (%)');axs[1].legend(fontsize=6.5,loc='upper right');title(axs[1],'B  Institutional delete-one summary')
for a in axs:a.grid(axis='y',alpha=.2);a.set_axisbelow(True)
fig.text(.095,.12,'A: line = exact bootstrap support; short bars = delete-one range; dot = locked radius.\nExact CV: 1.18% / 1.04%; 5,000-draw CV: 1.16% / 1.01% (seed 20261020).',fontsize=7.5)
fig.text(.095,.035,'B uses retained institutional test summaries; native test Mahalanobis inputs are not distributed.\nConditional observed-cohort resampling does not describe unobserved upper-tail patients.',fontsize=7.1)
save(fig,'Supplementary_Figures/Supplementary_Figure_S6.png',{'source':'release_reconciliation_results.json; calibration CSV; institutional delete-one test summary','exact_CV_percent':[1.18,1.04],'MC_CV_percent':[1.16,1.01],'locked_test_percent':[97.5,92.5],'worst_delete_one_percent':[97.5,90],'test_inputs_public':False})

# S7: eligibility and partition; exclusion reasons are mutually exclusive.
fig,ax=plt.subplots(figsize=(8.4,5.9));fig.subplots_adjust(left=.06,right=.94,bottom=.08,top=.93);canvas(ax,'Cohort screening and patient-level allocation')
box(ax,.28,.83,.44,.13,'Screened: 168 patients\n84 prostate; 84 head and neck')
box(ax,.04,.44,.42,.28,'Excluded: 48\nPrior development overlap: 12\nInsufficient interpretable imaging: 14\nMissing milestone window: 10\nMissing structures/dose inputs: 8\nIncomplete planning/course data: 4',fs=8)
box(ax,.58,.48,.37,.19,'Eligible: 120\n60 patients per disease site')
arrow(ax,.50,.83,.25,.72);arrow(ax,.60,.83,.76,.67)
box(ax,.48,.11,.23,.19,'Calibration: 40\n20 per site')
box(ax,.76,.11,.23,.19,'Locked test: 80\n40 per site\nFive milestones')
arrow(ax,.73,.48,.60,.30);arrow(ax,.80,.48,.87,.30)
fig.text(.09,.025,'Within-site allocation used NumPy PCG64 seed 20240517. All detected development overlaps were excluded before locking.',fontsize=7.4)
save(fig,'Supplementary_Figures/Supplementary_Figure_S7.png',{'source':'screening_and_partition_168.csv; Methods 2.2','screened':168,'excluded':48,'exclusions':[12,14,10,8,4],'eligible':120,'calibration':40,'test':80,'partition_seed':20240517})

records['_source_sha256']={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [D/'locked_test_fractions_enriched.csv',D/'landmark_level_containment_and_tre.csv',D/'source_pairs.csv',D/'surface_correspondence_summary.csv',D/'multi_ensemble_k_sensitivity_raw.csv',D/'clinical_bootstrap_replicates.csv',V/'release_reconciliation_results.json']}
(J/'Artwork_Numerical_Data.json').write_text(json.dumps(records,indent=2)+'\n')
print('Built 12 numerical figures with vector PDF/SVG companions; clinical image panels are excluded.')

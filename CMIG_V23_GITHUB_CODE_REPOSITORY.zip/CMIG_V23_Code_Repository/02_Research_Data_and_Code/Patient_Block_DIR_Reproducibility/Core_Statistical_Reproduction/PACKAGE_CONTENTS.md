# Statistical package contents

`run_analysis.py` computes the reported statistics, `run_extended_validation.py` performs source-group validation, and `python -m pytest -q` runs regression and integrity tests. Data are in `data/`, methods in `analysis/`, additional metrics in `scripts/`, configuration in `config/`, and statistical analysis plan and data dictionaries in `docs/`. The `MANIFEST.sha256` file provides reproducibility input checksums. Main code and data are integrated with the analysis-specific modules through the repository-level `run_complete_verification.py`.

For central-90% interval-score reproduction, use the 432 P05/P95/reference rows in `../Analysis_Specific_Verification/Interval_Score/interval_score_inputs_432.csv`.

# Calibration correction — source precedence and statistical definitions

The author-supplied `Calibration_40_Patient_Block_Scores.csv` (40 patient-block maxima, 20 per site) supersedes the erroneous duplicated-score file. Q scores are not modified by this reconciliation.

- `Selected_Site_Q`: largest of the 20 observed patient maxima at each site (Prostate 11.4; Head-and-neck 12.7). Locked thresholds are unchanged.
- `Radius_r`: square root of the patient-specific Q, rounded in the original author CSV.
- The original CSV's `Bootstrap_Radius_CV_pct` column contains **rounded exact** conditional coefficient of variation for the discrete nonparametric-bootstrap population distribution of the maximum radius; it does **not** equal the finite 5000-replicate sample estimate. Exact CV = 100 * sqrt(sum(p_i*(r_i-E[r])**2)) / E[r], p_i=(i/20)**20 - ((i-1)/20)**20. Exact values: 1.1800% and 1.0400%.
- The 5000-draw simulation from NumPy default_rng(20261020), resampling 20 patients with replacement at each site, has sample CV with ddof=1 of 1.160208% and 1.007718%, respectively. Stored in `calibration_bootstrap_5000_per_site.csv` and `release_reconciliation_results.json` as `CV_pct`.
- The source CSV's `Bootstrap_Range_Min_r` and `Bootstrap_Range_Max_r` provide rounded extrema of the **empirical bootstrap support** (smallest/largest possible resampled maxima). They are not the smallest/largest values that necessarily appear in only 5000 draws. Fig S6 now displays this support, not simulated extrema.
- Source Q-score provenance still relies on the study-team's institutional validation; the released data does not contain the 40 original calibration landmark/covariance matrices for independent native computation.

#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'locked_test_fractions.csv'

def roc_auc(y,s):
    y=np.asarray(y,dtype=int); s=np.asarray(s,dtype=float)
    pos=s[y==1]; neg=s[y==0]
    return float((np.sum(pos[:,None]>neg[None,:])+0.5*np.sum(pos[:,None]==neg[None,:]))/(len(pos)*len(neg)))

def average_precision(y,s):
    """Non-interpolated average precision (step integral), matching manuscript AUPRC."""
    y=np.asarray(y,dtype=int); s=np.asarray(s,dtype=float)
    order=np.argsort(-s, kind='mergesort')
    y=y[order]; s=s[order]
    # evaluate at distinct score thresholds, equivalent to sklearn average_precision_score for binary labels
    distinct=np.where(np.diff(s))[0]
    idx=np.r_[distinct, y.size-1]
    tp=np.cumsum(y)[idx].astype(float)
    fp=(1+idx).astype(float)-tp
    precision=tp/(tp+fp)
    recall=tp/tp[-1]
    prev=np.r_[0.0, recall[:-1]]
    return float(np.sum((recall-prev)*precision))

def summarize(df):
    y=df['True_Failure_0_1'].to_numpy(int); s=df['Triage_Score'].to_numpy(float)
    f=df['Triage_Positive_0_1'].to_numpy(int)
    tp=int(((y==1)&(f==1)).sum()); fn=int(((y==1)&(f==0)).sum())
    fp=int(((y==0)&(f==1)).sum()); tn=int(((y==0)&(f==0)).sum())
    return {'n':len(df),'tp':tp,'fn':fn,'fp':fp,'tn':tn,'sensitivity':tp/(tp+fn),'specificity':tn/(tn+fp),'ppv':tp/(tp+fp),'npv':tn/(tn+fn),'auroc':roc_auc(y,s),'auprc':average_precision(y,s)}

def main():
    d=pd.read_csv(DATA)
    out={'pooled':summarize(d)}
    for site,g in d.groupby('Site'):
        out[site]=summarize(g)
    for k,v in out.items():
        print(k, v)
    p=out['pooled']
    assert (p['tp'],p['fn'],p['fp'],p['tn'])==(46,7,80,267)
    assert abs(p['auroc']-0.8856505899624816)<1e-12
    assert abs(p['auprc']-0.6056073113600279)<1e-12
    return out
if __name__=='__main__': main()

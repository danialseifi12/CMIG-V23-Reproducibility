import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class TestReviewerFacingProvenanceLanguage(unittest.TestCase):
    def test_no_authority_based_confirmation_wording(self):
        offenders = []
        for path in ROOT.rglob("*"):
            if path.is_file() and path.suffix.lower() in {".md", ".txt", ".csv", ".json", ".py"}:
                text = path.read_text(encoding="utf-8", errors="ignore").lower()
                authority = "pro" + "fessor"
                forbidden = authority + "-confirmed"
                forbidden_spaced = authority + " confirmed"
                if forbidden in text or forbidden_spaced in text:
                    offenders.append(str(path.relative_to(ROOT)))
        self.assertEqual(offenders, [], f"Authority-based reviewer-facing provenance wording found: {offenders}")

    def test_width_allocation_boundary_is_explicit_and_history_neutral(self):
        text = (ROOT / "docs" / "WIDTH_MATCHED_FINALIZED_ALLOCATION.md").read_text(encoding="utf-8")
        self.assertIn("source-of-truth allocation", text)
        self.assertIn("conditional fixed-label benchmark", text)
        self.assertIn("independently regenerated", text)
        self.assertNotIn("after locked-test outcomes", text)
        self.assertNotIn("four row corrections", text)

    def test_no_obsolete_post_outcome_amendment_chronology(self):
        offenders = []
        forbidden = [
            "16" + " May 2024", "17" + " May 2024", "20" + " May 2024",
            "22" + " August 2026", "23" + " August 2026",
            "Gates 3-5 are " + "amended", "Gates 3–5 are " + "amended",
            "Gate 3 cluster-aware " + "amendment"
        ]
        for path in ROOT.rglob("*"):
            if path.is_file() and path.suffix.lower() in {".md", ".txt", ".json"}:
                text = path.read_text(encoding="utf-8", errors="ignore")
                if any(x in text for x in forbidden):
                    offenders.append(str(path.relative_to(ROOT)))
        self.assertEqual(offenders, [], f"Obsolete chronology/amendment wording found: {offenders}")


if __name__ == "__main__":
    unittest.main()

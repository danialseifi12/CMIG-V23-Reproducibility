import csv
import unittest
from pathlib import Path
from analysis.statistics import triage_cv_selection

ROOT = Path(__file__).resolve().parents[1]
CV = ROOT / "data" / "triage_cv_fold_grid.csv"

class FoldLevelCVTests(unittest.TestCase):
    def setUp(self):
        with CV.open(newline="", encoding="utf-8") as f:
            self.rows = list(csv.DictReader(f))

    def test_complete_grid(self):
        self.assertEqual(len(self.rows), 35)
        self.assertEqual(sorted({int(r["fold"]) for r in self.rows}), [1,2,3,4,5])
        self.assertEqual(sorted({float(r["threshold"]) for r in self.rows}), [0.35,0.4,0.45,0.5,0.55,0.6,0.65])

    def test_verified_fold4_rows(self):
        expected = {
            0.35:(1.000,1.000,0.700,"YES","NO"),
            0.40:(0.750,0.938,0.600,"NO","NO"),
            0.45:(0.750,0.958,0.400,"YES","NO"),
            0.50:(0.750,0.964,0.300,"YES","YES"),
            0.55:(0.500,0.939,0.175,"NO","NO"),
            0.60:(0.500,0.943,0.125,"NO","NO"),
            0.65:(0.500,0.944,0.100,"NO","NO"),
        }
        for threshold, exp in expected.items():
            r = next(r for r in self.rows if int(r["fold"])==4 and abs(float(r["threshold"])-threshold)<1e-12)
            sens,npv,rr,feas,sel=exp
            self.assertAlmostEqual(float(r["sensitivity"]), sens, places=6)
            self.assertAlmostEqual(float(r["npv"]), npv, places=6)
            self.assertAlmostEqual(float(r["review_rate"]), rr, places=6)
            self.assertEqual(r["fold_feasible"], feas)
            self.assertEqual(r["globally_selected_candidate"], sel)

    def test_threshold_050_is_global_candidate_on_all_rows(self):
        selected = [r for r in self.rows if r["globally_selected_candidate"] == "YES"]
        self.assertEqual(len(selected), 5)
        self.assertTrue(all(abs(float(r["threshold"])-0.50) < 1e-12 for r in selected))
        self.assertTrue(all(r["fold_feasible"] == "YES" for r in selected))

    def test_global_selection_rule_reproduces_threshold_050(self):
        r = triage_cv_selection(CV)
        self.assertAlmostEqual(r["selected_threshold"], 0.50, 12)
        self.assertAlmostEqual(r["selected_mean_review_rate"], 0.355, 12)
        self.assertEqual(r["globally_feasible_threshold_count"], 3)
        self.assertAlmostEqual(r["threshold_0_35_mean_review_rate"], 0.630, 12)
        self.assertAlmostEqual(r["threshold_0_45_mean_review_rate"], 0.440, 12)
        self.assertAlmostEqual(r["threshold_0_50_mean_review_rate"], 0.355, 12)

if __name__ == "__main__":
    unittest.main()

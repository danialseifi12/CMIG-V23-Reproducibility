#!/usr/bin/env python3
from __future__ import annotations
import csv
from pathlib import Path
import numpy as np

PARTITION_SEED = 20240517
GATE5_BOOTSTRAP_SEED = 20240527
SITE_ORDER = ["Prostate", "Head-and-neck"]


def main() -> None:
    root = Path(__file__).resolve().parent
    rows = list(csv.DictReader((root / "screening_and_partition_168.csv").open(encoding="utf-8")))
    assert len(rows) == 168
    assert sum(r["Eligible"] == "1" for r in rows) == 120
    assert sum(r["Eligible"] == "0" for r in rows) == 48

    rng = np.random.Generator(np.random.PCG64(PARTITION_SEED))
    mismatches = 0
    for site in SITE_ORDER:
        eligible = sorted(
            [r for r in rows if r["Site"] == site and r["Eligible"] == "1"],
            key=lambda r: r["Screen_ID"],
        )
        assert len(eligible) == 60
        order = rng.permutation(60)
        expected = {}
        for pos, j in enumerate(order, start=1):
            expected[eligible[j]["Screen_ID"]] = ("Calibration" if pos <= 20 else "Test", pos)
        for r in eligible:
            part, pos = expected[r["Screen_ID"]]
            if r["Partition"] != part or int(r["Partition_Order"]) != pos:
                mismatches += 1
    assert mismatches == 0

    assert sum(r["Partition"] == "Calibration" for r in rows) == 40
    assert sum(r["Partition"] == "Test" for r in rows) == 80
    assert sum(r["Partition"] == "Test" and r["Dose_Complete"] == "1" for r in rows) == 78
    assert next(r for r in rows if r["Screen_ID"] == "P031")["Dose_Complete"] == "0"
    assert next(r for r in rows if r["Screen_ID"] == "H054")["Dose_Complete"] == "0"
    assert all(r["Gate5_Bootstrap_Seed"] == str(GATE5_BOOTSTRAP_SEED) for r in rows)

    print("screened=168")
    print("eligible=120")
    print("excluded=48")
    print("calibration=40")
    print("test=80")
    print("complete_course_dose_test=78")
    print(f"partition_seed={PARTITION_SEED}")
    print(f"gate5_bootstrap_seed={GATE5_BOOTSTRAP_SEED}")
    print("partition_mismatches=0")
    print("P031_dose_complete=0")
    print("H054_dose_complete=0")


if __name__ == "__main__":
    main()

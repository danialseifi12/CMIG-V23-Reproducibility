#!/usr/bin/env python3
"""Calibration source-identity and internal numerical-consistency check; standard-library-only."""
from pathlib import Path
import csv,hashlib,math,json
root=Path(__file__).resolve().parent
file=root/'02_Reproducibility_Package/Calibration_40_Patient_Block_Scores.csv'
expected='9aa0bda2d006cfb5840c3c21dc51b16bcaf1eade62df31f6947c20c66cee4226'
assert hashlib.sha256(file.read_bytes()).hexdigest()==expected, 'Author-approved CSV SHA mismatch'
rows=list(csv.DictReader(file.open(newline='',encoding='utf-8-sig')))
assert len(rows)==40
rbase=root/'02_Research_Data_and_Code/Patient_Block_DIR_Reproducibility'
results=json.loads((rbase/'Release_Reconciliation/CALIBRATION_RECONCILIATION_20261020.json').read_text())
for site,q_locked,cv_reported,mc_reported in [('Prostate',11.4,1.18,1.16),('Head-and-neck',12.7,1.04,1.01)]:
 d=[x for x in rows if x['Disease_Site']==site];assert len(d)==20
 vals=sorted(float(x['Max_Mahalanobis_Q']) for x in d)
 assert len(set(vals))==20 and abs(max(vals)-q_locked)<1e-12
 assert all(abs(math.sqrt(float(x['Max_Mahalanobis_Q']))-float(x['Radius_r']))<1e-6 for x in d)
 assert all(abs(float(x['Bootstrap_Radius_CV_pct'])-cv_reported)<1e-9 for x in d)
 p=[(i/20)**20 - ((i-1)/20)**20 for i in range(1,21)]
 r=[math.sqrt(x) for x in vals];m=sum(x*y for x,y in zip(p,r));std=math.sqrt(sum(x*(y-m)**2 for x,y in zip(p,r)))
 exact=100*std/m
 assert abs(exact-cv_reported)<0.005 and abs(exact-results[site]['exact_cv'])<1e-10
 assert abs(results[site]['mc_cv']-mc_reported)<0.005
 print(site,'20 unique Q scores; exact CV:',round(exact,4),'%; 5000-sample CV:',round(results[site]['mc_cv'],4),'%')
print('PASS calibration: approved source hash, 40 patient rows, exact and Monte Carlo CV')

import unittest
from pathlib import Path
import pandas as pd
from analysis.statistics import width_scale_internal_to_lambda

ROOT = Path(__file__).resolve().parents[1]

class WidthScaleMappingTests(unittest.TestCase):
    def test_bootstrap_median_mapping(self):
        d = pd.read_csv(ROOT / "data" / "source_bootstrap_replicates.csv")
        c = pd.to_numeric(d["WidthScale_Internal_Coefficient"], errors="raise")
        self.assertAlmostEqual(float(c.median()), 0.811936, 9)
        lam = width_scale_internal_to_lambda(c.to_numpy())
        self.assertAlmostEqual(float(pd.Series(lam).median()), 1.0811936, 9)
        self.assertEqual(round(float(pd.Series(lam).median()), 3), 1.081)

    def test_bootstrap_operational_column_matches_formula(self):
        d = pd.read_csv(ROOT / "data" / "source_bootstrap_replicates.csv")
        derived = 1.0 + 0.10 * pd.to_numeric(d["WidthScale_Internal_Coefficient"], errors="raise")
        stored = pd.to_numeric(d["Lambda_Width_Operational_Replicate"], errors="raise")
        self.assertLess(float((derived - stored).abs().max()), 1e-12)

    def test_source_pairs_row_coefficient_is_not_global_c_width(self):
        d = pd.read_csv(ROOT / "data" / "source_pairs.csv")
        self.assertIn("WidthScale_Internal_Coefficient", d.columns)
        self.assertGreater(d["WidthScale_Internal_Coefficient"].nunique(), 400)
        self.assertNotIn("Lambda_Width_Operational", d.columns)
        self.assertNotIn("Lambda_Width_Operational_Replicate", d.columns)

if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import beta, binomtest, binom, norm, t as student_t, wilcoxon


def exact_binomial_ci(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    lo = 0.0 if k == 0 else float(beta.ppf(alpha / 2, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1 - alpha / 2, k + 1, n - k))
    return lo, hi



def width_scale_internal_to_lambda(c_width):
    """Convert archived internal width-calibration coefficient to operational multiplier.

    The submission archive distinguishes the retained internal calibration-scale
    coefficient c_width from the manuscript-facing operational amplitude multiplier:
        lambda_width = 1 + 0.10 * c_width
    """
    return 1.0 + 0.10 * np.asarray(c_width, dtype=float)



def gate1(fraction_path: Path, margin: float = 0.875) -> dict[str, float]:
    """Recompute Gate 1 directly from locked M50 patient rows."""
    d = pd.read_csv(fraction_path)
    d = d[d["Dataset_Split"].eq("Locked test") & d["Fraction_ID"].eq("M50")].copy()
    if len(d) != 80 or d["Patient_ID"].nunique() != 80:
        raise ValueError("Gate 1 requires exactly one M50 row for each of 80 locked-test patients")
    site_counts = d.groupby("Site")["Patient_ID"].nunique().to_dict()
    if sorted(site_counts.values()) != [40, 40]:
        raise ValueError(f"Gate 1 expected 40 patients per site, got {site_counts}")
    k = int(pd.to_numeric(d["Coverage_0_1"], errors="raise").sum())
    n = int(len(d))
    lo, hi = exact_binomial_ci(k, n)
    p = float(binomtest(k, n, p=margin, alternative="greater").pvalue)
    return {"successes": k, "n": n, "estimate": k / n, "ci_low": lo, "ci_high": hi, "p": p}


def gate1_tipping(n: int = 80, base_successes: int = 76, margin: float = 0.875):
    rows = []
    for change in range(-3, 4):
        k = base_successes + change
        lo, hi = exact_binomial_ci(k, n)
        p = float(binomtest(k, n, p=margin, alternative="greater").pvalue)
        rows.append({
            "outcome_changes": change,
            "successes": k,
            "n": n,
            "rate": k / n,
            "exact_95_ci_low": lo,
            "exact_95_ci_high": hi,
            "p_vs_margin": p,
            "decision": "PASS" if p < 0.05 else "FAIL",
        })
    return pd.DataFrame(rows)


def gate1_power(n: int = 80, p0: float = 0.875, p_true: float = 0.95, alpha: float = 0.05):
    crit = None
    for k in range(n + 1):
        if binom.sf(k - 1, n, p0) <= alpha:
            crit = k
            break
    if crit is None:
        raise RuntimeError("No rejection threshold found")
    power = float(binom.sf(crit - 1, n, p_true))
    return {"critical_successes": int(crit), "power_at_true_rate": power}


def _prepare_fraction_rows(path: Path) -> pd.DataFrame:
    d = pd.read_csv(path)
    d = d[d["Dataset_Split"].eq("Locked test")].copy()
    d["milestone"] = d["Fraction_ID"].astype(str).str.extract(r"(\d+)").astype(float)
    d["noncoverage"] = 1.0 - d["Coverage_0_1"].astype(float)
    d["time20"] = (d["milestone"] - 10.0) / 20.0
    d["site_hn"] = d["Site"].eq("Head-and-neck").astype(float)
    return d


def gate2(fraction_path: Path, margin_or: float = 1.85) -> dict[str, float]:
    # Prespecified Gate 2 point estimate / model-based covariance use a
    # site-adjusted binomial-logit model under working independence.
    # A patient-cluster sandwich covariance is reported separately as the
    # repeated-fraction robustness sensitivity.
    d = _prepare_fraction_rows(fraction_path)
    x = sm.add_constant(d[["time20", "site_hn"]], has_constant="add")
    model = sm.GLM(d["noncoverage"], x, family=sm.families.Binomial()).fit()
    b = float(model.params["time20"])
    se = float(model.bse["time20"])
    z95 = float(norm.ppf(0.95))
    z975 = float(norm.ppf(0.975))

    # Patient-cluster sandwich sensitivity. The verified analysis uses the finite-cluster
    # M/(M-1) correction but not the additional N/(N-k) correction.
    cl = sm.GLM(d["noncoverage"], x, family=sm.families.Binomial()).fit(
        cov_type="cluster", cov_kwds={"groups": d["Patient_ID"], "use_correction": False}
    )
    clusters = int(d["Patient_ID"].nunique())
    robust_se = float(cl.bse["time20"]) * np.sqrt(clusters / (clusters - 1))

    return {
        "or": float(np.exp(b)),
        "ci_low": float(np.exp(b - z975 * se)),
        "ci_high": float(np.exp(b + z975 * se)),
        "upper_one_sided": float(np.exp(b + z95 * se)),
        "margin_p": float(norm.cdf((b - np.log(margin_or)) / se)),
        "robust_or": float(np.exp(b)),
        "robust_upper_one_sided": float(np.exp(b + z95 * robust_se)),
        "robust_margin_p": float(norm.cdf((b - np.log(margin_or)) / robust_se)),
        "robust_se_log_or": robust_se,
    }


def _patient_confusion(d: pd.DataFrame) -> pd.DataFrame:
    out = []
    for (site, pid), g in d.groupby(["Site", "Patient_ID"], sort=False):
        fail = g["True_Failure_0_1"].astype(int).to_numpy()
        flag = g["Triage_Positive_0_1"].astype(int).to_numpy()
        out.append({
            "site": site,
            "patient_id": pid,
            "tp": int(((fail == 1) & (flag == 1)).sum()),
            "fn": int(((fail == 1) & (flag == 0)).sum()),
            "fp": int(((fail == 0) & (flag == 1)).sum()),
            "tn": int(((fail == 0) & (flag == 0)).sum()),
        })
    return pd.DataFrame(out)


def cluster_null_score(numerator: np.ndarray, denominator: np.ndarray, p0: float) -> dict[str, float]:
    """One-sided cluster score test for a ratio/proportion margin.

    U_i = numerator_i - p0 * denominator_i.  The variance is the sample
    variance of the independent patient-cluster contributions.  This is the
    calculation that reproduces the verified Gate 3 cluster-null-score p-values.
    """
    numerator = np.asarray(numerator, dtype=float)
    denominator = np.asarray(denominator, dtype=float)
    u = numerator - p0 * denominator
    n = len(u)
    var_sum = (n / (n - 1)) * np.sum((u - u.mean()) ** 2)
    z = float(u.sum() / np.sqrt(var_sum))
    return {"z": z, "p": float(norm.sf(z))}


def gate3(fraction_path: Path, bootstrap_path: Path, sens_floor: float = 0.75, npv_floor: float = 0.95):
    d = _prepare_fraction_rows(fraction_path)
    fail = d["True_Failure_0_1"].astype(int).to_numpy()
    flag = d["Triage_Positive_0_1"].astype(int).to_numpy()
    tp = int(((fail == 1) & (flag == 1)).sum())
    fn = int(((fail == 1) & (flag == 0)).sum())
    fp = int(((fail == 0) & (flag == 1)).sum())
    tn = int(((fail == 0) & (flag == 0)).sum())

    pc = _patient_confusion(d)
    sens_test = cluster_null_score(pc["tp"].to_numpy(), (pc["tp"] + pc["fn"]).to_numpy(), sens_floor)
    npv_test = cluster_null_score(pc["tn"].to_numpy(), (pc["tn"] + pc["fn"]).to_numpy(), npv_floor)

    b = pd.read_csv(bootstrap_path)
    sens = pd.to_numeric(b["Sensitivity"], errors="coerce").dropna().to_numpy(float)
    npv = pd.to_numeric(b["NPV"], errors="coerce").dropna().to_numpy(float)
    return {
        "tp": tp, "fn": fn, "fp": fp, "tn": tn,
        "sensitivity": tp / (tp + fn),
        "specificity": tn / (tn + fp),
        "ppv": tp / (tp + fp),
        "npv": tn / (tn + fn),
        # Primary directional Gate 3 inference uses one-sided 95% lower confidence bounds.
        # Complementary conventional two-sided 95% percentile intervals are reported separately.
        "sensitivity_lower_one_sided_95": float(np.quantile(sens, 0.05, method="linear")),
        "sensitivity_ci_two_sided_95_low": float(np.quantile(sens, 0.025, method="linear")),
        "sensitivity_ci_two_sided_95_high": float(np.quantile(sens, 0.975, method="linear")),
        "sensitivity_p_one_sided": sens_test["p"],
        "sensitivity_z": sens_test["z"],
        "npv_lower_one_sided_95": float(np.quantile(npv, 0.05, method="linear")),
        "npv_ci_two_sided_95_low": float(np.quantile(npv, 0.025, method="linear")),
        "npv_ci_two_sided_95_high": float(np.quantile(npv, 0.975, method="linear")),
        "npv_p_one_sided": npv_test["p"],
        "npv_z": npv_test["z"],
        "bootstrap_replicates": int(len(b)),
    }


def source_level_z(diff_by_source: np.ndarray, alternative: str = "greater", null: float = 0.0):
    x = np.asarray(diff_by_source, dtype=float)
    mean = float(x.mean())
    se = float(x.std(ddof=1) / np.sqrt(len(x)))
    z = (mean - null) / se
    if alternative == "greater":
        p = float(norm.sf(z))
    elif alternative == "less":
        p = float(norm.cdf(z))
    else:
        p = float(2 * norm.sf(abs(z)))
    return {"mean": mean, "se": se, "z": float(z), "p": p}


def source_level_t(diff_by_source: np.ndarray, alternative: str = "greater", null: float = 0.0):
    x = np.asarray(diff_by_source, dtype=float)
    n = len(x)
    mean = float(x.mean())
    se = float(x.std(ddof=1) / np.sqrt(n))
    stat = float((mean - null) / se)
    if alternative == "greater":
        p = float(student_t.sf(stat, n - 1))
    elif alternative == "less":
        p = float(student_t.cdf(stat, n - 1))
    else:
        p = float(2 * student_t.sf(abs(stat), n - 1))
    return {"mean": mean, "se": se, "t": stat, "df": n - 1, "p": p}


def width_matched_source_cluster_bootstrap(source_path: Path, seed: int = 20240527, reps: int = 5000) -> np.ndarray:
    """Recompute the disease-site-stratified source-anatomy bootstrap for C-WM containment.

    The statistic is the mean source-level paired difference
    DispersionCalibrated_Coverage_0_1 - WidthMatched_Coverage_0_1.
    Twelve sources are resampled with replacement within each site, preserving
    the 12+12 site balance in every replicate.
    """
    d = pd.read_csv(source_path)
    for c in ["DispersionCalibrated_Coverage_0_1", "WidthMatched_Coverage_0_1"]:
        d[c] = pd.to_numeric(d[c], errors="raise")
    d["width_matched_gain"] = d["DispersionCalibrated_Coverage_0_1"] - d["WidthMatched_Coverage_0_1"]
    src = (d.groupby(["Site", "Source_Anatomy_ID"], sort=True)["width_matched_gain"]
             .mean().reset_index())
    rng = np.random.default_rng(seed)
    site_boot = []
    for _, g in src.groupby("Site", sort=True):
        x = g["width_matched_gain"].to_numpy(float)
        idx = rng.integers(0, len(x), size=(reps, len(x)))
        site_boot.append(x[idx].mean(axis=1))
    return np.mean(np.vstack(site_boot), axis=0)


def high_severity_source_cluster_ci(d: pd.DataFrame, seed: int = 20240527, reps: int = 5000):
    """Site-stratified source-anatomy bootstrap for high-severity containment."""
    high = d[d["Severity"].eq("High")].copy()
    # Each source contributes the same six high-severity endpoints, so a bootstrap
    # of source means is algebraically identical to duplicating all endpoint rows.
    source_means=(high.groupby(["Site","Source_Anatomy_ID"],sort=True)["DispersionCalibrated_Coverage_0_1"].mean().reset_index())
    rng=np.random.default_rng(seed)
    site_boot=[]
    for _,g in source_means.groupby("Site",sort=True):
        x=g["DispersionCalibrated_Coverage_0_1"].to_numpy(float)
        idx=rng.integers(0,len(x),size=(reps,len(x)))
        site_boot.append(x[idx].mean(axis=1))
    vals=np.mean(np.vstack(site_boot),axis=0)
    return {
        "low": float(np.quantile(vals,0.025,method="linear")),
        "high": float(np.quantile(vals,0.975,method="linear")),
        "reps": reps,
        "seed": seed,
    }


def controlled_endpoint_summary(source_path: Path) -> pd.DataFrame:
    """Recompute manuscript/Supplement endpoint rows from source_pairs."""
    d=pd.read_csv(source_path)
    out=(d.groupby(["Site","Endpoint"], sort=True)
         .agg(
             dispersion_calibrated_coverage=("DispersionCalibrated_Coverage_0_1","mean"),
             uncalibrated_coverage=("Uncalibrated_Coverage_0_1","mean"),
             dispersion_calibrated_width_Gy=("DispersionCalibrated_Width","median"),
             uncalibrated_width_Gy=("Uncalibrated_Width","median"),
             n=("Pair_ID","size"),
         ).reset_index())
    out["difference_pp"]=(out["dispersion_calibrated_coverage"]-out["uncalibrated_coverage"])*100.0
    return out


def triage_rule_consistency(fraction_path: Path) -> dict[str, int]:
    d=pd.read_csv(fraction_path)
    prostate=d["Site"].eq("Prostate")
    absolute=((prostate & ((d["A95_mm"]>=4.20)|(d["f_high_0_1"]>=0.18))) |
              (~prostate & ((d["A95_mm"]>=5.05)|(d["f_high_0_1"]>=0.20))))
    score=pd.to_numeric(d["Triage_Score"],errors="raise")>=0.50
    y=d["Triage_Positive_0_1"].astype(bool)
    return {
        "n": int(len(d)),
        "absolute_rule_matches": int((absolute==y).sum()),
        "score_threshold_matches": int((score==y).sum()),
    }


def gate3_gee_sensitivity(fraction_path: Path, sens_floor: float = 0.75, npv_floor: float = 0.95):
    """Alternative patient-cluster GEE sensitivity for Gate 3 proportions."""
    d=_prepare_fraction_rows(fraction_path)
    z95=float(norm.ppf(0.95))
    fail=d[d["True_Failure_0_1"].eq(1)].copy()
    x=np.ones((len(fail),1))
    fit_s=sm.GEE(fail["Triage_Positive_0_1"], x, groups=fail["Patient_ID"], family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
    bs=float(fit_s.params.iloc[0]); ses=float(fit_s.bse.iloc[0])
    z_s=(bs-np.log(sens_floor/(1-sens_floor)))/ses
    unflag=d[d["Triage_Positive_0_1"].eq(0)].copy()
    y_n=1-unflag["True_Failure_0_1"].astype(int)
    fit_n=sm.GEE(y_n, np.ones((len(unflag),1)), groups=unflag["Patient_ID"], family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
    bn=float(fit_n.params.iloc[0]); sen=float(fit_n.bse.iloc[0])
    z_n=(bn-np.log(npv_floor/(1-npv_floor)))/sen
    inv=lambda x: float(1/(1+np.exp(-x)))
    return {
        "sensitivity": inv(bs), "sensitivity_lower_one_sided_95": inv(bs-z95*ses), "sensitivity_p_one_sided": float(norm.sf(z_s)),
        "npv": inv(bn), "npv_lower_one_sided_95": inv(bn-z95*sen), "npv_p_one_sided": float(norm.sf(z_n)),
    }


def controlled_source_analyses(source_path: Path, bootstrap_path: Path, wm_bootstrap_path: Path | None = None, ni_margin: float = -0.02):
    d = pd.read_csv(source_path)
    for c in [
        "Uncalibrated_Interval_Score", "DispersionCalibrated_Interval_Score", "Uncalibrated_Coverage_0_1",
        "DispersionCalibrated_Coverage_0_1", "WidthMatched_Coverage_0_1",
    ]:
        d[c] = pd.to_numeric(d[c], errors="raise")

    # Fail fast if the reviewer-facing derived C-WM column drifts from the
    # current endpoint outcomes. This guard was added after forensic audit.
    if "Width_Adjusted_Diff" in d.columns:
        stored = pd.to_numeric(d["Width_Adjusted_Diff"], errors="raise").to_numpy(int)
        current = (d["DispersionCalibrated_Coverage_0_1"].astype(int) - d["WidthMatched_Coverage_0_1"].astype(int)).to_numpy(int)
        if not np.array_equal(stored, current):
            raise ValueError("Width_Adjusted_Diff is not synchronized with current C-WM endpoint outcomes")

    contingency = {
        (int(c), int(w)): int(n)
        for (c, w), n in d.groupby(["DispersionCalibrated_Coverage_0_1", "WidthMatched_Coverage_0_1"]).size().items()
    }
    d["containment_gain"] = d["DispersionCalibrated_Coverage_0_1"] - d["Uncalibrated_Coverage_0_1"]
    d["width_matched_gain"] = d["DispersionCalibrated_Coverage_0_1"] - d["WidthMatched_Coverage_0_1"]
    d["interval_score_diff"] = d["DispersionCalibrated_Interval_Score"] - d["Uncalibrated_Interval_Score"]
    src = d.groupby("Source_Anatomy_ID", sort=False).agg(
        containment_gain=("containment_gain", "mean"),
        width_matched_gain=("width_matched_gain", "mean"),
        interval_score_diff=("interval_score_diff", "mean"),
    )

    gain_test = source_level_z(src["containment_gain"].to_numpy(), "greater", 0.0)
    wm_superiority = source_level_z(src["width_matched_gain"].to_numpy(), "greater", 0.0)
    wm_noninferiority = source_level_z(src["width_matched_gain"].to_numpy(), "greater", ni_margin)
    score_test = source_level_z(src["interval_score_diff"].to_numpy(), "less", 0.0)
    gain_t = source_level_t(src["containment_gain"].to_numpy(), "greater", 0.0)
    wm_ni_t = source_level_t(src["width_matched_gain"].to_numpy(), "greater", ni_margin)
    score_t = source_level_t(src["interval_score_diff"].to_numpy(), "less", 0.0)
    score_wilcoxon_p = float(wilcoxon(src["interval_score_diff"].to_numpy(), alternative="less", zero_method="wilcox").pvalue)

    # The retained source-bootstrap archive contains the original replicate-specific
    # c_width fits (and their deterministic lambda_width transforms) for the
    # truth-blind pooled-median width-fitting procedure. The finalized C-WM
    # inferential bootstrap is intentionally stored separately because it
    # resamples the confirmed paired endpoint allocation downstream of that fit.
    b = pd.read_csv(bootstrap_path)
    gain_b = pd.to_numeric(b["Estimate"], errors="coerce").dropna().to_numpy(float)
    score_b = pd.to_numeric(b["Interval_Diff_C_minus_U"], errors="coerce").dropna().to_numpy(float)
    c_width_b = pd.to_numeric(b["WidthScale_Internal_Coefficient"], errors="coerce").dropna().to_numpy(float)
    lambda_width_b = width_scale_internal_to_lambda(c_width_b)

    if wm_bootstrap_path is None:
        wm_bootstrap_path = bootstrap_path.parent / "width_matched_bootstrap_replicates.csv"
    wb = pd.read_csv(wm_bootstrap_path)
    wm_b_archived = pd.to_numeric(wb["WidthMatched_Diff"], errors="raise").to_numpy(float)
    wm_b = width_matched_source_cluster_bootstrap(source_path, seed=20240527, reps=len(wb))
    if len(wm_b_archived) != len(wm_b) or not np.allclose(wm_b_archived, wm_b, atol=5e-7, rtol=0.0):
        raise ValueError("Dedicated WidthMatched_Diff bootstrap is not synchronized with finalized source_pairs.csv")

    high = d[d["Severity"].eq("High")].copy()
    high_k = int(high["DispersionCalibrated_Coverage_0_1"].sum())
    high_n = int(len(high))
    high_lo, high_hi = exact_binomial_ci(high_k, high_n)
    high_cluster = high_severity_source_cluster_ci(d)

    # Forensic synchronization summaries: these are computed directly from the
    # 432 retained source-pair rows so site/severity subgroup values and pooled
    # width summaries cannot silently drift from the reviewer-facing data.
    site_cov = d.groupby("Site", sort=True)[[
        "Uncalibrated_Coverage_0_1", "WidthMatched_Coverage_0_1", "DispersionCalibrated_Coverage_0_1"
    ]].mean()
    sev_cov = d.groupby("Severity", sort=True)[[
        "Uncalibrated_Coverage_0_1", "WidthMatched_Coverage_0_1", "DispersionCalibrated_Coverage_0_1"
    ]].mean()
    u_width_median = float(d["Uncalibrated_Width"].median())
    c_width_median = float(d["DispersionCalibrated_Width"].median())
    width_pct_increase = float((c_width_median / u_width_median - 1.0) * 100.0)

    return {
        "n_sources": int(src.shape[0]),
        "n_endpoints": int(len(d)),
        "uncalibrated_contained": int(d["Uncalibrated_Coverage_0_1"].sum()),
        "dispersion_calibrated_contained": int(d["DispersionCalibrated_Coverage_0_1"].sum()),
        "width_matched_contained": int(d["WidthMatched_Coverage_0_1"].sum()),
        "width_matched_contingency_c1_w1": contingency.get((1, 1), 0),
        "width_matched_contingency_c1_w0": contingency.get((1, 0), 0),
        "width_matched_contingency_c0_w1": contingency.get((0, 1), 0),
        "width_matched_contingency_c0_w0": contingency.get((0, 0), 0),
        # Reviewer-facing aliases matching the source-of-truth joint-state labels.
        "joint_c1_wm1": contingency.get((1, 1), 0),
        "joint_c1_wm0": contingency.get((1, 0), 0),
        "joint_c0_wm1": contingency.get((0, 1), 0),
        "joint_c0_wm0": contingency.get((0, 0), 0),
        "containment_gain": gain_test["mean"],
        "containment_gain_ci_low": float(np.quantile(gain_b, 0.025, method="linear")),
        "containment_gain_ci_high": float(np.quantile(gain_b, 0.975, method="linear")),
        "containment_gain_p": gain_test["p"],
        "containment_gain_t23_p": gain_t["p"],
        "high_severity_contained": high_k,
        "high_severity_n": high_n,
        "high_severity_estimate": high_k / high_n,
        "high_severity_ci_low": high_lo,
        "high_severity_ci_high": high_hi,
        "high_severity_source_cluster_ci_low": high_cluster["low"],
        "high_severity_source_cluster_ci_high": high_cluster["high"],
        "high_severity_source_cluster_bootstrap_reps": high_cluster["reps"],
        "site_uncalibrated_prostate": float(site_cov.loc["Prostate", "Uncalibrated_Coverage_0_1"]),
        "site_uncalibrated_head_and_neck": float(site_cov.loc["Head-and-neck", "Uncalibrated_Coverage_0_1"]),
        "site_dispersion_calibrated_prostate": float(site_cov.loc["Prostate", "DispersionCalibrated_Coverage_0_1"]),
        "site_dispersion_calibrated_head_and_neck": float(site_cov.loc["Head-and-neck", "DispersionCalibrated_Coverage_0_1"]),
        "site_width_matched_prostate": float(site_cov.loc["Prostate", "WidthMatched_Coverage_0_1"]),
        "site_width_matched_head_and_neck": float(site_cov.loc["Head-and-neck", "WidthMatched_Coverage_0_1"]),
        "severity_uncalibrated_low": float(sev_cov.loc["Low", "Uncalibrated_Coverage_0_1"]),
        "severity_uncalibrated_medium": float(sev_cov.loc["Medium", "Uncalibrated_Coverage_0_1"]),
        "severity_uncalibrated_high": float(sev_cov.loc["High", "Uncalibrated_Coverage_0_1"]),
        "severity_width_matched_low": float(sev_cov.loc["Low", "WidthMatched_Coverage_0_1"]),
        "severity_width_matched_medium": float(sev_cov.loc["Medium", "WidthMatched_Coverage_0_1"]),
        "severity_width_matched_high": float(sev_cov.loc["High", "WidthMatched_Coverage_0_1"]),
        "pooled_uncalibrated_width_median_Gy": u_width_median,
        "pooled_dispersion_calibrated_width_median_Gy": c_width_median,
        "pooled_width_percent_increase": width_pct_increase,
        "width_matched_gain": wm_superiority["mean"],
        "width_matched_ci_low": float(np.quantile(wm_b, 0.025, method="linear")),
        "width_matched_bootstrap_q25": float(np.quantile(wm_b, 0.25, method="linear")),
        "width_matched_bootstrap_median": float(np.quantile(wm_b, 0.50, method="linear")),
        "width_matched_bootstrap_q75": float(np.quantile(wm_b, 0.75, method="linear")),
        "width_matched_ci_high": float(np.quantile(wm_b, 0.975, method="linear")),
        "width_matched_superiority_p": wm_superiority["p"],
        "width_matched_ni_lower_one_sided": float(np.quantile(wm_b, 0.05, method="linear")),
        "width_matched_noninferiority_p": wm_noninferiority["p"],
        "width_matched_noninferiority_t23_p": wm_ni_t["p"],
        "interval_score_dispersion_calibrated_mean": float(d["DispersionCalibrated_Interval_Score"].mean()),
        "interval_score_uncalibrated_mean": float(d["Uncalibrated_Interval_Score"].mean()),
        "interval_score_difference_c_minus_u": score_test["mean"],
        # The retained interval-score rows compare dispersion-calibrated with
        # uncalibrated scenarios (C-U), not the width-matched comparator.
        # Report a conventional two-sided 95% bootstrap interval and, separately,
        # the directional one-sided 95% upper bound used with the one-sided
        # source-level normal-score test.
        "interval_score_ci_low_two_sided": float(np.quantile(score_b, 0.025, method="linear")),
        "interval_score_ci_high_two_sided": float(np.quantile(score_b, 0.975, method="linear")),
        "interval_score_upper_one_sided": float(np.quantile(score_b, 0.95, method="linear")),
        "interval_score_directional_p": score_test["p"],
        "interval_score_two_sided_normal_p": float(min(1.0, 2.0 * score_test["p"])),
        "interval_score_t23_directional_p": score_t["p"],
        "interval_score_wilcoxon_directional_p": score_wilcoxon_p,
        "width_scale_internal_bootstrap_median": float(np.median(c_width_b)),
        "width_scale_internal_bootstrap_q025": float(np.quantile(c_width_b, 0.025, method="linear")),
        "width_scale_internal_bootstrap_q975": float(np.quantile(c_width_b, 0.975, method="linear")),
        "lambda_width_operational_bootstrap_median": float(np.median(lambda_width_b)),
        "lambda_width_operational_bootstrap_q025": float(np.quantile(lambda_width_b, 0.025, method="linear")),
        "lambda_width_operational_bootstrap_q975": float(np.quantile(lambda_width_b, 0.975, method="linear")),
        "lambda_width_reported_rounded": float(np.round(np.median(lambda_width_b), 3)),
        "bootstrap_replicates": int(len(b)),
    }


def triage_cv_selection(cv_path: Path, sens_floor: float = 0.75, npv_floor: float = 0.95):
    """Reproduce the locked global threshold-selection rule from calibration folds only.

    A single threshold is globally feasible only if it meets sensitivity and NPV
    floors in every held-out patient-blocked calibration fold. Among globally
    feasible thresholds, mean held-out review rate is minimized.
    """
    d = pd.read_csv(cv_path)
    for c in ["threshold", "fold", "sensitivity", "npv", "review_rate"]:
        d[c] = pd.to_numeric(d[c], errors="raise")
    summary = (
        d.groupby("threshold", sort=True)
        .agg(
            n_folds=("fold", "nunique"),
            min_sensitivity=("sensitivity", "min"),
            min_npv=("npv", "min"),
            mean_sensitivity=("sensitivity", "mean"),
            mean_npv=("npv", "mean"),
            mean_review_rate=("review_rate", "mean"),
            feasible_folds=("fold", "count"),
        )
        .reset_index()
    )
    summary["feasible_folds"] = summary.apply(
        lambda r: int(((d.loc[d["threshold"].eq(r["threshold"]), "sensitivity"] >= sens_floor)
                       & (d.loc[d["threshold"].eq(r["threshold"]), "npv"] >= npv_floor)).sum()), axis=1
    )
    summary["all_folds_feasible"] = (
        summary["n_folds"].eq(5)
        & summary["min_sensitivity"].ge(sens_floor)
        & summary["min_npv"].ge(npv_floor)
    )
    eligible = summary.loc[summary["all_folds_feasible"]].copy()
    if eligible.empty:
        raise RuntimeError("No threshold satisfies both floors in all five folds")
    selected = eligible.sort_values(["mean_review_rate", "threshold"], ascending=[True, True]).iloc[0]
    summary["globally_selected"] = summary["threshold"].eq(float(selected["threshold"]))
    return {
        "selected_threshold": float(selected["threshold"]),
        "selected_mean_review_rate": float(selected["mean_review_rate"]),
        "globally_feasible_threshold_count": int(eligible.shape[0]),
        "threshold_0_35_mean_review_rate": float(summary.loc[summary["threshold"].eq(0.35), "mean_review_rate"].iloc[0]),
        "threshold_0_45_mean_review_rate": float(summary.loc[summary["threshold"].eq(0.45), "mean_review_rate"].iloc[0]),
        "threshold_0_50_mean_review_rate": float(summary.loc[summary["threshold"].eq(0.50), "mean_review_rate"].iloc[0]),
        "summary": summary,
    }

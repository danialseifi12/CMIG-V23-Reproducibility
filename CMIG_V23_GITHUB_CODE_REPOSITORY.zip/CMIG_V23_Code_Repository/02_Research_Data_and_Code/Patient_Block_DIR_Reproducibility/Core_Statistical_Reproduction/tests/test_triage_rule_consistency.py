import unittest
from pathlib import Path
from analysis.statistics import triage_rule_consistency, gate3_gee_sensitivity
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data"
class TriageRuleConsistencyTests(unittest.TestCase):
    def test_all_locked_flags_match_documented_absolute_rule_and_score_threshold(self):
        r=triage_rule_consistency(DATA/"locked_test_fractions.csv")
        self.assertEqual(r["n"],400)
        self.assertEqual(r["absolute_rule_matches"],400)
        self.assertEqual(r["score_threshold_matches"],400)
    def test_gee_sensitivity_supports_gate3_direction(self):
        r=gate3_gee_sensitivity(DATA/"locked_test_fractions.csv")
        self.assertAlmostEqual(r["sensitivity"],0.8679836769,8)
        self.assertAlmostEqual(r["sensitivity_lower_one_sided_95"],0.7713892989,8)
        self.assertAlmostEqual(r["sensitivity_p_one_sided"],0.0265116888,8)
        self.assertAlmostEqual(r["npv"],0.9746640494,8)
        self.assertAlmostEqual(r["npv_lower_one_sided_95"],0.9538083408,8)
        self.assertAlmostEqual(r["npv_p_one_sided"],0.0311001655,8)
if __name__=="__main__": unittest.main()

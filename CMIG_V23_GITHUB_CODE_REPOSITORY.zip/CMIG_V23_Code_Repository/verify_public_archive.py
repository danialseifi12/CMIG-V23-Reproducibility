#!/usr/bin/env python3
"""Check publication-file exclusion and unchanged scientific input observations."""
from pathlib import Path
from zipfile import ZipFile,is_zipfile
import hashlib,json
ROOT=Path(__file__).resolve().parent
bad=[];files=[p for p in ROOT.rglob('*') if p.is_file() and 'regenerated_figures' not in p.parts]
for p in files:
 if p.suffix.lower() in {'.doc','.docx','.docm','.pdf','.rtf','.odt','.tex','.png','.jpg','.jpeg','.svg','.pptx'} or '01_Journal_Files' in p.parts:bad.append(str(p.relative_to(ROOT)))
 if p.suffix.lower() not in {'.npz','.pt'} and is_zipfile(p):
  with ZipFile(p) as z:
   if any(n.startswith('word/') for n in z.namelist()):bad.append(str(p.relative_to(ROOT)))
assert not bad,'Publication files found: '+str(bad)
source=json.loads((ROOT/'SOURCE_DATA_PRESERVATION.json').read_text())['protected_source_tables']
assert len(source)==38
for row in source:
 p=(ROOT/row['file']).resolve();assert p.is_relative_to(ROOT.resolve())
 assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['file']
print('PASS: no article, supplement, publication artwork or office documents; all 38 scientific input tables unchanged')

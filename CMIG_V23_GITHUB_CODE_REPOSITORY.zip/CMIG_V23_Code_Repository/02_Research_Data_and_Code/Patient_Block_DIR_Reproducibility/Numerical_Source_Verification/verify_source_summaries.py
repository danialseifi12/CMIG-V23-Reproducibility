#!/usr/bin/env python3
import csv, pathlib, collections
R=pathlib.Path(__file__).resolve().parents[1]
A=R/'Analysis_Specific_Verification'/'Interval_Score'/'interval_score_inputs_432.csv'
B=R/'Core_Statistical_Reproduction'/'docs'/'TABLE_S18_SOURCE_LEVEL.csv'
rows=list(csv.DictReader(A.open(encoding='utf8')))
summ={r['Source']:r for r in csv.DictReader(B.open(encoding='utf8'))}
grp=collections.defaultdict(list)
for r in rows:
  y=float(r['Reference_Dose_Gy'])
  for arm in ('Uncal','Cal'):
    lo,hi=float(r[f'{arm}_P05_Gy']),float(r[f'{arm}_P95_Gy'])
    exp=(hi-lo)+20*max(lo-y,0)+20*max(y-hi,0)
    assert abs(exp-float(r[f'{arm}_Interval_Score_Gy']))<1e-6
  grp[r['Source_Anatomy_ID']].append(r)
assert len(rows)==432 and len(grp)==24
for source,g in grp.items():
 assert len(g)==18
 vals=[]
 for arm in ('Uncal','Cal'):
  avg=sum(float(r[f'{arm}_Interval_Score_Gy']) for r in g)/18
  vals.append(avg)
  assert abs(float(summ[source][f'Mean_IS_{"U" if arm=="Uncal" else "C"}'])-avg)<1e-7
print('PASS: 432 endpoint scores, 24 source summaries and 48 released CSV means agree')

"""Verification layer for the anonymized DIR manuscript."""

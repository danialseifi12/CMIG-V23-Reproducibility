# Core statistical reproduction

Execute `python run_analysis.py`, `python run_extended_validation.py` and `python -m pytest -q` for the 400 clinical fractions, triage results and 432 controlled-reference endpoint summaries. `data/source_pairs.csv` has formula-derived interval-score fields. `../Analysis_Specific_Verification/Interval_Score/interval_score_inputs_432.csv` contains its matched 432 row-level P05/P95/reference inputs; run `recompute_interval_score.py` there for direct score-equation verification. For scope see `../STUDY_SOURCE_SCOPE_INDEX.csv`.

import unittest
from pathlib import Path
import pandas as pd
from analysis.statistics import controlled_endpoint_summary
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/"data"
class EndpointSummaryTests(unittest.TestCase):
    def test_complete_12_endpoint_summary(self):
        s=controlled_endpoint_summary(DATA/"source_pairs.csv")
        self.assertEqual(len(s),12)
        self.assertTrue((s["n"]==36).all())
        self.assertAlmostEqual(float(s["dispersion_calibrated_coverage"].mul(s["n"]).sum()),376.0,8)
        self.assertAlmostEqual(float(s["uncalibrated_coverage"].mul(s["n"]).sum()),345.0,8)
    def test_specific_endpoint_values(self):
        s=controlled_endpoint_summary(DATA/"source_pairs.csv")
        r=s[(s.Site=="Prostate")&(s.Endpoint=="Target D98")].iloc[0]
        self.assertAlmostEqual(r.dispersion_calibrated_coverage,31/36,12)
        self.assertAlmostEqual(r.uncalibrated_coverage,29/36,12)
        self.assertAlmostEqual(r.dispersion_calibrated_width_Gy,1.908459,6)
        self.assertAlmostEqual(r.uncalibrated_width_Gy,1.793995,6)
if __name__=="__main__": unittest.main()

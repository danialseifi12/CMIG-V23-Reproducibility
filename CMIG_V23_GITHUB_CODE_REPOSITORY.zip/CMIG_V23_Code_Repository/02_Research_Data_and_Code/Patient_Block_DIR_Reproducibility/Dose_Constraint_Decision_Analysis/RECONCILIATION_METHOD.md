# Recorded decision-dose reconciliation

export_and_reconcile_dose.py links all 432 endpoint keys to canonical score records and the supplied decision preswap source. In 406 final rows, source index and all recorded dose values are unchanged. Thirteen D98/D95 row pairs exchange their preswap source rows: the D98 output receives a −2 Gy shift and D95 a +2 Gy shift. The shift is applied equally to reference, nominal dose, U P05/P95 and C P05/P95. The script verifies all six fields, exports the complete crosswalk and the 26 affected rows, and preserves original scientific inputs.

This is the supplied, investigator-attested reconciliation for the decision extension. Its arithmetic is reproducible. It is not an independently verified physical transformation between historical replay, canonical score and final decision-dose coordinates. The crosswalk retains absolute center differences rather than suppressing them (maximum score/decision reference difference approximately 6.539 Gy).

Use interval_score_inputs_432.csv for score calculations and Controlled_432.csv with Constraints_Registry.csv for protocol-limit decisions. Do not mix reference/interval/limit centers across these coordinate systems. The selected ten-endpoint workbook verifies stored arrays after its documented endpoint reconciliation; it does not replace native clinical lineage.

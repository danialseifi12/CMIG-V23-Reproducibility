import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from analysis.statistics import width_matched_source_cluster_bootstrap, controlled_source_analyses

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"


class WidthMatchedBootstrapSyncTests(unittest.TestCase):
    def test_recomputed_bootstrap_matches_dedicated_finalized_file_and_headlines(self):
        calc = width_matched_source_cluster_bootstrap(DATA / "source_pairs.csv", seed=20240527, reps=5000)
        archived = pd.read_csv(DATA / "width_matched_bootstrap_replicates.csv")["WidthMatched_Diff"].to_numpy(float)
        self.assertTrue(np.allclose(calc, archived, atol=5e-7, rtol=0.0))
        q = np.quantile(calc, [0.025, 0.25, 0.50, 0.75, 0.975], method="linear")
        self.assertTrue(np.allclose(q, np.array([1, 6, 9, 12, 18]) / 432, atol=5e-7))
        r = controlled_source_analyses(DATA / "source_pairs.csv", DATA / "source_bootstrap_replicates.csv")
        self.assertAlmostEqual(r["width_matched_superiority_p"], 0.0290711991, 8)
        self.assertEqual(r["width_matched_contingency_c1_w1"], 357)
        self.assertEqual(r["width_matched_contingency_c1_w0"], 19)
        self.assertEqual(r["width_matched_contingency_c0_w1"], 10)
        self.assertEqual(r["width_matched_contingency_c0_w0"], 46)


if __name__ == "__main__":
    unittest.main()

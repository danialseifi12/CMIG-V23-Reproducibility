# Width-matching fit and inference

The global operational multiplier is fitted without controlled-reference truth outcomes. `data/scenario_level_fitting_inputs.csv` contains 72 pooled scenario-level uncalibrated width values. `scripts/width_matching_fit.py` uses bisection on a global multiplier to match the dispersion-calibrated pooled median P05–P95 width target of 1.9600 Gy and reproduces `lambda_width≈1.081`.

This fit is intentionally separate from endpoint-outcome inference. The finalized endpoint analysis uses the canonical 432-row `source_pairs.csv`, for which dispersion-calibrated containment is 376/432 and width-matched containment is 367/432. The primary reported +2.08 percentage-point contrast uses the disease-site-stratified 5,000-replicate source-anatomy bootstrap (95% CI +0.23 to +4.17 pp). The source-level normal approximation is retained only as a sensitivity calculation.

The fit is a global pooled-median width control; it does not assert exact width matching within every disease site, severity, endpoint, or source anatomy.

#!/usr/bin/env python3
"""Actually execute the supplied small Torch replay and historical WM generator.
This does not execute the restricted original clinical registration network.
"""
from pathlib import Path
import importlib.util,json,hashlib,tempfile,subprocess,sys
import numpy as np,pandas as pd,torch
HERE=Path(__file__).resolve().parent;A=HERE/'Intermediate_Replay_Assets'
meta=json.loads((A/'01_model_checkpoint_metadata.json').read_text())
checkpoint=A/'01_model_checkpoint.pt'
assert hashlib.sha256(checkpoint.read_bytes()).hexdigest()==meta['checkpoint_sha256']
spec=importlib.util.spec_from_file_location('intermediate_replay',A/'01_model_definition_and_inference.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=m.run(checkpoint,A/'04_replay_inputs_72_scenarios.npz')
summary=pd.read_csv(A/'01_inference_replay_summary_72.csv')
pos={s:i for i,s in enumerate(out['scenario_ids'])}
err={}
for col,key,component in [('Disp_X_mm','global_disp_mm',0),('Disp_Y_mm','global_disp_mm',1),
 ('Disp_Z_mm','global_disp_mm',2),('Warped_Dose_Mean_Gy','warped_dose_mean_gy',None),
 ('Warped_Dose_SD_Gy','warped_dose_sd_gy',None)]:
    actual=np.array([out[key][pos[s]] if component is None else out[key][pos[s],component] for s in summary.Scenario_ID])
    err[col]=float(np.max(np.abs(actual-summary[col].to_numpy())))
    assert err[col]<1e-5,(col,err[col])
params=pd.read_csv(A/'03_local_response_parameters_432.csv')
for col,key in [('Local_Response_Gain','local_response_gain'),('Center_Shift_Gy','center_shift_gy')]:
    actual=np.array([out[key][pos[row.Scenario_ID],int(row.Endpoint_Slot)-1] for row in params.itertuples()])
    err[col]=float(np.max(np.abs(actual-params[col].to_numpy())))
    assert err[col]<1e-5,(col,err[col])
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    subprocess.run([sys.executable,str(A/'02_gate5_width_matched_generator_original.py'),
      '--samples',str(A/'02_uncalibrated_ensemble_432x100.npz'),
      '--lambda-inputs',str(A/'02_lambda_fit_inputs_72.csv'),
      '--params',str(A/'03_local_response_parameters_432.csv'),
      '--output',str(td/'WM.csv'),'--sample-output',str(td/'WM.npz')],check=True)
    with np.load(td/'WM.npz') as new,np.load(A/'02_width_matched_samples_432x100.npz') as old:
        assert np.array_equal(new['pair_ids'],old['pair_ids'])
        wm_error=float(np.max(np.abs(new['width_matched_dose_gy']-old['width_matched_dose_gy'])))
        lam=float(new['lambda_width'][0]);assert wm_error<1e-10
report=dict(all_passed=True,torch_version=torch.__version__,scenarios=72,endpoints=432,
    wm_samples=43200,lambda_width=lam,max_WM_sample_error_Gy=wm_error,replay_max_errors=err,
    scope='Small intermediate checkpoint and historical WM coordinate only; not original clinical network, physical cross-layer mapping, or fixed-label Gate 5 inference regeneration.')
(HERE/'intermediate_replay_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS actual Torch intermediate replay and 43,200 historical WM samples; maximum sample error',wm_error)

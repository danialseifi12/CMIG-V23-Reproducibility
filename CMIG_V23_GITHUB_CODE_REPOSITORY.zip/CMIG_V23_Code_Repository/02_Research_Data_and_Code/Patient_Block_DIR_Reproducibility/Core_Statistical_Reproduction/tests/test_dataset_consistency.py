import unittest
import json
from pathlib import Path
import pandas as pd
from analysis.statistics import controlled_source_analyses

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"


class ForensicSynchronizationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r = controlled_source_analyses(
            DATA / "source_pairs.csv", DATA / "source_bootstrap_replicates.csv", DATA / "width_matched_bootstrap_replicates.csv"
        )

    def test_site_aggregates_are_locked_to_source_rows(self):
        self.assertAlmostEqual(self.r["site_uncalibrated_prostate"], 180 / 216, 12)
        self.assertAlmostEqual(self.r["site_uncalibrated_head_and_neck"], 165 / 216, 12)
        self.assertAlmostEqual(self.r["site_dispersion_calibrated_prostate"], 183 / 216, 12)
        self.assertAlmostEqual(self.r["site_dispersion_calibrated_head_and_neck"], 193 / 216, 12)

    def test_uncalibrated_severity_aggregates_are_locked_to_source_rows(self):
        self.assertAlmostEqual(self.r["severity_uncalibrated_low"], 121 / 144, 12)
        self.assertAlmostEqual(self.r["severity_uncalibrated_medium"], 119 / 144, 12)
        self.assertAlmostEqual(self.r["severity_uncalibrated_high"], 105 / 144, 12)

    def test_pooled_width_medians_and_percent_change_are_locked_to_source_rows(self):
        self.assertAlmostEqual(self.r["pooled_uncalibrated_width_median_Gy"], 1.767867, 6)
        self.assertAlmostEqual(self.r["pooled_dispersion_calibrated_width_median_Gy"], 1.9583765, 7)
        self.assertAlmostEqual(self.r["pooled_width_percent_increase"], 10.7762348638, 8)

    def test_finalized_width_matched_pair_allocation(self):
        import pandas as pd
        d = pd.read_csv(DATA / "source_pairs.csv").set_index("Pair_ID")
        expected = {"PAIR_0017": 0, "PAIR_0213": 0, "PAIR_0411": 0, "PAIR_0286": 1}
        for pid, value in expected.items():
            self.assertEqual(int(d.loc[pid, "WidthMatched_Coverage_0_1"]), value)
        c = d["DispersionCalibrated_Coverage_0_1"].astype(int)
        w = d["WidthMatched_Coverage_0_1"].astype(int)
        self.assertEqual(int(((c==1)&(w==1)).sum()), 357)
        self.assertEqual(int(((c==1)&(w==0)).sum()), 19)
        self.assertEqual(int(((c==0)&(w==1)).sum()), 10)
        self.assertEqual(int(((c==0)&(w==0)).sum()), 46)

    def test_width_adjusted_diff_is_rowwise_c_minus_wm(self):
        d = pd.read_csv(DATA / "source_pairs.csv")
        expected = d["DispersionCalibrated_Coverage_0_1"].astype(int) - d["WidthMatched_Coverage_0_1"].astype(int)
        self.assertTrue((d["Width_Adjusted_Diff"].astype(int) == expected).all())
        self.assertEqual(int(d["Width_Adjusted_Diff"].sum()), 9)

    def test_config_expected_width_matched_count_matches_source_rows(self):
        d = pd.read_csv(DATA / "source_pairs.csv")
        cfg = json.loads((ROOT / "config" / "analysis_config.json").read_text(encoding="utf-8"))
        self.assertEqual(int(cfg["expected_counts"]["width_matched_contained"]), int(d["WidthMatched_Coverage_0_1"].sum()))
        self.assertEqual(int(cfg["expected_counts"]["width_matched_contained"]), 367)

    def test_table_s18_machine_readable_source_matches_source_pairs(self):
        d = pd.read_csv(DATA / "source_pairs.csv")
        s18 = pd.read_csv(ROOT / "docs" / "TABLE_S18_SOURCE_LEVEL.csv").set_index("Source")
        self.assertEqual(len(s18), 24)
        for sid, g in d.groupby("Source_Anatomy_ID"):
            self.assertEqual(int(s18.loc[sid, "Contained_U"]), int(g["Uncalibrated_Coverage_0_1"].sum()))
            self.assertEqual(int(s18.loc[sid, "Contained_WM"]), int(g["WidthMatched_Coverage_0_1"].sum()))
            self.assertEqual(int(s18.loc[sid, "Contained_C"]), int(g["DispersionCalibrated_Coverage_0_1"].sum()))
            self.assertAlmostEqual(float(s18.loc[sid, "Delta_contain_C_minus_WM"]), float((g["DispersionCalibrated_Coverage_0_1"] - g["WidthMatched_Coverage_0_1"]).mean()), 9)
        self.assertEqual(int(s18["Contained_WM"].sum()), 367)
        self.assertEqual(int(s18["Contained_C"].sum()), 376)


if __name__ == "__main__":
    unittest.main()

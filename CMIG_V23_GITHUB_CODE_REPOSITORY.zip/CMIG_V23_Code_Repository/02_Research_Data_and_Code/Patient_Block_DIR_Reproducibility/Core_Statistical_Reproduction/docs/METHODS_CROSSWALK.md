# Methods-to-code crosswalk

| Analysis item | Implementation | Input | Output |
|---|---|---|---|
| Gate 1 | `analysis.statistics.gate1` | 76/80 | exact CI; p=0.022373 |
| Gate 1 fragility/power | `gate1_tipping`, `gate1_power` | n=80; p0=0.875 | tipping table; power≈0.62888 |
| Gate 2 primary | `gate2` | locked fraction rows | OR=1.369341; one-sided upper=1.805793; p=0.036836 |
| Gate 2 cluster sensitivity | `gate2` | same rows | one-sided upper=1.858054; p=0.052461 |
| Gate 3 sensitivity/NPV | `gate3` + `cluster_null_score` | locked fraction rows + retained clinical bootstrap summaries | sensitivity 46/53; NPV 267/274; cluster lower bounds and p-values |
| Controlled containment gain | `controlled_source_analyses` | source-pair rows + source bootstrap summaries | +0.071759; 95% CI +0.002315 to +0.152778; p=0.032620 |
| Width-matched containment | `controlled_source_analyses` | finalized source-pair rows + dedicated site-stratified source bootstrap | +0.020833; 95% CI 0.002315 to +0.041667; superiority p=0.029071; NI p=0.000102 |
| Interval score C-U | `controlled_source_analyses` | explicit uncalibrated and dispersion-calibrated interval-score rows | -0.160000 Gy; two-sided bootstrap 95% CI -0.342969 to +0.026443; one-sided upper -0.005307; directional p=0.047570 |
| CV global selection | fold grid + candidate summary | 5 folds × 7 thresholds | all-fold feasibility, mean review rate; threshold 0.50 selected |
| Width-scale mapping | `width_scale_internal_to_lambda` | retained `c_width` | median 0.811936 -> operational 1.0811936 -> reported 1.081 |
| Landmark atlas | machine-readable CSV | 8 prostate + 12 head-and-neck points | exact point definitions |

The retained interval-score archive does not contain a width-matched interval-score value; no matched-width interval-score claim is made in this submission.

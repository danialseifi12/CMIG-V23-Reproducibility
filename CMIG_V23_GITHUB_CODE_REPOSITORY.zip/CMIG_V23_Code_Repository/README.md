# CMIG V23 code and reproducibility repository

This public source archive contains analysis code, required numerical input data, tests, reference outputs, optional plotting code and installation instructions. It excludes the manuscript, supplementary document, title page, cover letter, highlights, study-plan office document and all stored publication artwork. Verification does not require any of those files.

## Run

Use Python 3.12 in a virtual environment:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python verify_package.py
python run_verification.py
```

Windows activation: `.venv\Scripts\activate`. After dependency installation, verification needs no network. All 20 code/data components include 60 regression tests. Results and actual package versions are recorded in the nested `VERIFICATION_RUN_REPORT.json` and `RUN_ENVIRONMENT.json`. The code/data checks replace publication-format and document-comparison checks from the separate journal submission package; they do not assert that those checks were run here.

Verify `CHECKSUMS.csv` before rerunning. Outputs can be rewritten by execution; use `python verify_package.py --static` during reruns. `python verify_public_archive.py` checks publication exclusion and exact preservation of the 38 original scientific input tables. These observations have not been modified. Required CSV, NPZ and PT inputs are intentionally included so the code can run independently.

## Structure

`02_Research_Data_and_Code/Patient_Block_DIR_Reproducibility/` contains the analyses, data dictionaries, model refits, endpoint replay, dose-layer reconciliation, tests, plotting sources and reference outputs. `02_Reproducibility_Package/` holds the canonical 40-patient calibration input. Keep the relative structure.

The legacy `TABLE_S18_SOURCE_LEVEL.csv` basename is retained and maps to the current source-level summary (Table S36 in the separately submitted supplement). The numerical verification compares 432 endpoint scores and 48 source means directly against CSV inputs. It reads no supplement. Calibration and longitudinal checks are also independent of publication files.

Optional: after the model refit, run `python 02_Research_Data_and_Code/Patient_Block_DIR_Reproducibility/Release_Reconciliation/rebuild_figures.py` to produce the 12 numerical plots and vector companions in a separate generated folder. Clinical image panels are excluded.

## Scientific scope

The released investigator-supplied analysis data support the adjusted longitudinal refit and the recorded dose-layer reconciliation. The small response replay checkpoint is distinct from the original clinical registration network. Restricted native clinical images, original clinical weights and the complete native clinical image-to-dose implementation are outside this archive. Read the nested README and CANONICAL_ANALYSIS_LAYERS.md for the exact analysis and replay boundaries.

## GitHub

Upload the extracted contents of this folder as the repository root, preserving subfolders and the included input data. Do not upload the previous reviewer ZIP containing journal files. This archive does not create a remote repository, DOI or license grant. Add the real repository URL/citation to the separately submitted manuscript after deposit. Contact the corresponding author for reuse permissions and restricted-data requests.

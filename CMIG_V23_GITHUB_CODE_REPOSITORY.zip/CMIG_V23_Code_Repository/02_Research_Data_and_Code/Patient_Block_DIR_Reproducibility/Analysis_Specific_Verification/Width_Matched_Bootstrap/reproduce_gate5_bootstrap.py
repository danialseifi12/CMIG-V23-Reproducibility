#!/usr/bin/env python3
from __future__ import annotations
import csv
from collections import defaultdict
from pathlib import Path
import numpy as np

SEED=20240527
REPS=5000

def load_source_means(path: Path):
    rows=list(csv.DictReader(path.open(encoding="utf-8")))
    g=defaultdict(list)
    for r in rows:
        key=(r["Site"],r["Source_Anatomy_ID"])
        g[key].append(float(r["DispersionCalibrated_Coverage_0_1"]) -
                      float(r["WidthMatched_Coverage_0_1"]))
    src=defaultdict(list)
    for (site,source),vals in g.items():
        src[site].append((source,sum(vals)/len(vals)))
    for site in src:
        src[site].sort()
    return src

def gate5_fixed_label_bootstrap(source_pairs: Path):
    src=load_source_means(source_pairs)
    rng=np.random.default_rng(SEED)
    site_boot=[]
    for site in sorted(src):
        x=np.asarray([v for _,v in src[site]],dtype=float)
        assert len(x)==12
        idx=rng.integers(0,len(x),size=(REPS,len(x)))
        site_boot.append(x[idx].mean(axis=1))
    return np.mean(np.vstack(site_boot),axis=0)

def main():
    root=Path(__file__).resolve().parent
    # Fixed Gate-5 coverage labels are read from the retained original core source rows. Historical score columns in the same CSV are not used.
    src_path=root.parent.parent/"Core_Statistical_Reproduction"/"data"/"source_pairs.csv"
    vals=gate5_fixed_label_bootstrap(src_path)
    source_means=load_source_means(src_path)
    point_estimate=float(np.mean([np.mean([v for _,v in source_means[site]]) for site in sorted(source_means)]))
    archived=[]
    with (root/"gate5_coverage_bootstrap_5000.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            archived.append(float(r["WidthMatched_Diff"]))
    archived=np.asarray(archived)
    assert len(archived)==REPS
    max_err=float(np.max(np.abs(vals-archived)))
    assert max_err < 5e-7
    print(f"replicates={REPS}")
    print(f"seed={SEED}")
    print(f"lambda_refit_in_gate5_coverage_bootstrap=False")
    print(f"endpoint_intervals_regenerated=False")
    print(f"point_estimate={point_estimate:.12f}")
    print(f"percentile_CI=[{np.quantile(vals,0.025,method='linear'):.12f}, {np.quantile(vals,0.975,method='linear'):.12f}]")
    print(f"max_abs_difference_from_archive={max_err:.3e}")

if __name__=="__main__":
    main()

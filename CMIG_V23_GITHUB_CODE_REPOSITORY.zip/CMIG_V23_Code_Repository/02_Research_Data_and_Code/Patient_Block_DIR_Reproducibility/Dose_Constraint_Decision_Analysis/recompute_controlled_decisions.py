#!/usr/bin/env python3
"""Controlled-reference-only, exploratory dose-limit decision replay.

Inputs: already investigator/physicist-approved 432 endpoint rows and constraint registry.
NO clinical endpoint files are read. NO pre-existing Gate 1-5 analysis is changed.
Only consistency and post hoc statistical summaries are reproduced; this does not
constitute a native SVF or image-to-dose replay.
"""
import csv, collections, hashlib, itertools, json, math, random
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def load(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def ck(cond,msg):
    if not cond: raise AssertionError(msg)

def decision(lo,hi,l,d):
    if d=='MAX':return 'SAFE' if hi<=l else ('VIOLATION' if lo>l else 'UNCERTAIN')
    if d=='MIN':return 'SAFE' if lo>=l else ('VIOLATION' if hi<l else 'UNCERTAIN')
    raise ValueError(d)

def quantile(xs,q):
    xs=sorted(xs);t=(len(xs)-1)*q;i=math.floor(t);j=math.ceil(t)
    return xs[i]*(j-t)+xs[j]*(t-i) if i!=j else xs[i]

src=ROOT/'Controlled_432.csv'
rg=ROOT/'Constraints_Registry.csv'
rows=load(src); registry=load(rg)
ck(len(rows)==432 and len(registry)==12,'expected 432 controlled rows and 12 dose limits')
rmap={r['Constraint_ID_ENTER']:r for r in registry}
cnts=collections.Counter()
by_source=collections.defaultdict(list)
for n,r in enumerate(rows,1):
    ck(r['Constraint_ID'] in rmap,f'missing registry ID row {n}')
    lim=float(r['Limit_Gy']);d=r['Limit_Direction'];ref=float(r['Ref_MappedDose_Gy'])
    reg=rmap[r['Constraint_ID']]
    ck(abs(float(reg['Limit_Gy_ENTER'])-lim)<1e-9 and reg['Direction_ENTER']==d,'limit linkage mismatch')
    truth='VIOLATION' if (ref>lim if d=='MAX' else ref<lim) else 'COMPLIANT'
    ck(r['Reference_Status']==truth,f'reference truth row {n}')
    for key in ('Uncal','Cal'):
        low=float(r[f'{key}_P05_Gy']);high=float(r[f'{key}_P95_Gy'])
        ck(low<=high,f'inverted interval row {n}')
        pred=decision(low,high,lim,d)
        ck(pred==r[f'{key}_Decision'],f'classification mismatch row {n} {key}')
        checks={
            f'{key}_FalseSafe':int(pred=='SAFE' and truth=='VIOLATION'),
            f'{key}_FalseViolation':int(pred=='VIOLATION' and truth=='COMPLIANT'),
            f'{key}_Uncertain':int(pred=='UNCERTAIN'),
            f'{key}_ContainsTruth':int(low<=ref<=high)
        }
        for col,value in checks.items():
            ck(int(r[col])==value,f'{col} mismatch row {n}')
        cnts[key+'_'+pred]+=1
        for col,v in checks.items():cnts[col]+=v
    ck(int(r['Resolved_FalseSafe'])==int(int(r['Uncal_FalseSafe'])==1 and int(r['Cal_FalseSafe'])==0),f'resolved mismatch {n}')
    ck(int(r['New_FalseSafe'])==int(int(r['Uncal_FalseSafe'])==0 and int(r['Cal_FalseSafe'])==1),f'new mismatch {n}')
    cnts['Resolved_FalseSafe']+=int(r['Resolved_FalseSafe']);cnts['New_FalseSafe']+=int(r['New_FalseSafe'])
    cnts['ref_violations']+=int(truth=='VIOLATION')
    by_source[(r['Disease_Site'],r['Source_ID'])].append(r)
ck(len(by_source)==24 and all(len(v)==18 for v in by_source.values()),'source clustering')
for key in ('Uncal','Cal'):
    ck(sum(cnts[key+'_'+n] for n in ('SAFE','UNCERTAIN','VIOLATION'))==432,key+' row counts')
    cnts[key+'_NON_SAFE']=cnts[key+'_UNCERTAIN']+cnts[key+'_VIOLATION']
ck((cnts['Uncal_FalseSafe'],cnts['Cal_FalseSafe'])==(30,8),'false-safe locked counts')
ck((cnts['Uncal_ContainsTruth'],cnts['Cal_ContainsTruth'])==(345,376),'legacy dose containment')
ck((cnts['Uncal_NON_SAFE'],cnts['Cal_NON_SAFE'])==(207,308),'non-safe counts')
ck(cnts['ref_violations']==98,'known-reference limit violations')
ck((cnts['Resolved_FalseSafe'],cnts['New_FalseSafe'])==(24,2),'paired movements')
site_keys={s:sorted([k for k in by_source if k[0]==s]) for s in ('Prostate','Head-and-neck')}
ck(all(len(v)==12 for v in site_keys.values()),'source sites')
seed=20261011; B=10000;rng=random.Random(seed);boots=[]
for _ in range(B):
    sample=[]
    for site, keys in site_keys.items():
        for _ in range(12): sample.extend(by_source[keys[rng.randrange(12)]])
    boots.append(sum(int(r['Cal_FalseSafe'])-int(r['Uncal_FalseSafe']) for r in sample)/432)
per_source={f'{k[0]}:{k[1]}':sum(int(r['Cal_FalseSafe'])-int(r['Uncal_FalseSafe']) for r in group) for k,group in by_source.items()}
changes=list(per_source.values());nz=[x for x in changes if x]
obs=abs(sum(changes));extreme=sum(abs(sum(s*x for s,x in zip(signs,nz)))>=obs for signs in itertools.product([-1,1],repeat=len(nz)))
loo=[(sum(changes)-x)/(432-18) for x in changes]
by_site={s:{k:sum(int(r[k]) for r in rows if r['Disease_Site']==s) for k in ('Uncal_FalseSafe','Cal_FalseSafe')} for s in site_keys}
by_severity={s:{k:sum(int(r[k]) for r in rows if r['Severity']==s) for k in ('Uncal_FalseSafe','Cal_FalseSafe')} for s in ('Low','Medium','High')}
trans=collections.Counter(r['Uncal_Decision']+' -> '+r['Cal_Decision'] for r in rows)
report={
 'scope':'post hoc exploratory CONTROLLED-REFERENCE ONLY; 432 endpoints / 24 source anatomies',
 'provenance':'Input endpoints and protocol limits are investigator/physicist-approved; code checks derived-field consistency, not native image-to-dose source.',
 'n_endpoints':432,'n_sources':24,'true_reference_limit_violations':cnts['ref_violations'],
 'counts':dict(cnts),
 'decision_transitions':dict(trans),
 'non_safe_change_count':cnts['Cal_NON_SAFE']-cnts['Uncal_NON_SAFE'],
 'non_safe_change_percentage_points':100*(cnts['Cal_NON_SAFE']-cnts['Uncal_NON_SAFE'])/432,
 'false_safe_change_percentage_points':100*(cnts['Cal_FalseSafe']-cnts['Uncal_FalseSafe'])/432,
 'paired_cluster_bootstrap_95pct_ci_percentage_points':[100*quantile(boots,.025),100*quantile(boots,.975)],
 'source_signflip':{'nonzero_source_count':len(nz),'assignments':2**len(nz),'extreme_assignments':extreme,'exact_two_sided_p':extreme/(2**len(nz))},
 'source_change_distribution':{'improved':sum(x<0 for x in changes),'unchanged':sum(x==0 for x in changes),'worsened':sum(x>0 for x in changes)},
 'leave_one_source_out_delta_percentage_points_range':[100*min(loo),100*max(loo)],
 'by_site':by_site,'by_severity':by_severity,
 'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (src,rg)},
 'excluded':'No new clinical decision-workbook rows are included or used to regenerate previously approved Table 5 or clinical findings.'}
(ROOT/'controlled_decision_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ('counts','non_safe_change_count','paired_cluster_bootstrap_95pct_ci_percentage_points','source_signflip')},indent=2))

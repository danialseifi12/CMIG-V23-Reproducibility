# Analysis-specific verification

- `Interval_Score`: 432 P05/P95/reference-dose rows and the central-90% score formula implementation.
- `Endpoint_Percentile_Replay`: 86,400 deterministic endpoint replay values, used to check archived percentile calculations; not original native engine runs.
- `Patient_Allocation`: PCG64 partition seed 20240517; bootstrap seed 20240527 is separate. The coded test-patient/registration linkage (80 test patients, 400 milestone registrations, 78 complete-course dose IDs) is checked by `Patient_Allocation/Coded_Patient_and_Registration_Linkage/verify_coded_linkage.py`.
- `Width_Matched_Bootstrap`: fixed width multiplier and 5,000 archived source-anatomy coverage resamples; coefficient fitting resamples are separate.

"""Publication vector Figure 1, preserving CMIG V22 content in the earlier visual style.
Landmarks, grids, cubes and DVHs are schematic illustrations, not source observations.
"""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Ellipse,Polygon
import fitz

INK='#20252b';BLUE='#215d91';PALE='#eaf2f9';GRAY='#edf0f3'

def txt(a,x,y,s,fs=13,ha='center',va='center',bold=False,color=INK):
    return a.text(x,y,s,fontsize=fs,ha=ha,va=va,fontweight='bold' if bold else 'normal',
                  color=color,linespacing=1.12,zorder=10)

def box(a,x,y,w,h,s='',fs=13,edge=INK,fill='white',dashed=False,lw=1.05):
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.8',facecolor=fill,
       edgecolor=edge,lw=lw,linestyle=(0,(4,2)) if dashed else '-',zorder=2)
    a.add_patch(p)
    if s:txt(a,x+w/2,y+h/2,s,fs)
    return p

def arrow(a,x1,y1,x2,y2,lw=1.1,ms=10):
    a.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=ms,
       lw=lw,color=INK,shrinkA=1.2,shrinkB=1.2,zorder=4))

def panel(fig,rect,letter,title):
    a=fig.add_axes(rect);a.set(xlim=(0,100),ylim=(0,100));a.axis('off')
    a.add_patch(FancyBboxPatch((.3,.3),99.4,99.4,boxstyle='round,pad=0,rounding_size=1.2',
       facecolor='white',edgecolor='#717880',lw=.8,zorder=0))
    txt(a,2.6,94.8,letter,18,ha='left',bold=True)
    txt(a,8,94.7,title,13.6,ha='left',bold=True)
    return a

def lattice(a,x,y,w,h,warp=False,lw=.65):
    for u in np.linspace(0,1,5):
        t=np.linspace(0,1,40);d=.10*np.sin(np.pi*t)*(2*u-1) if warp else np.zeros_like(t)
        a.plot(x+w*(u+d),y+h*t,color=INK,lw=lw,zorder=3)
        a.plot(x+w*t,y+h*(u+.6*d),color=INK,lw=lw,zorder=3)

def stack(a,x,y,w,h):
    for k in [2,1,0]:
        box(a,x+1.25*k,y+1.25*k,w,h,edge='#5a626b',lw=.55)
        lattice(a,x+1.25*k,y+1.25*k,w,h,True,lw=.48)

def cube(a,x,y,w,h,depth=3.5):
    n=5;cmap=plt.get_cmap('YlGnBu_r')
    def tile(points,value):
        a.add_patch(Polygon(points,closed=True,facecolor=cmap(value),edgecolor='#234b6c',lw=.42,zorder=3))
    for j in range(n):
        for i in range(n):
            v=.20+.75*np.exp(-(((i-2)/1.45)**2+((j-2)/1.7)**2))
            tile([(x+i*w/n,y+j*h/n),(x+(i+1)*w/n,y+j*h/n),
                  (x+(i+1)*w/n,y+(j+1)*h/n),(x+i*w/n,y+(j+1)*h/n)],v)
    for j in range(n):
        for k in range(n):
            d0=depth*k/n;d1=depth*(k+1)/n
            tile([(x+w+d0,y+d0+j*h/n),(x+w+d1,y+d1+j*h/n),
                  (x+w+d1,y+d1+(j+1)*h/n),(x+w+d0,y+d0+(j+1)*h/n)],.28+.16*j/n)
    for i in range(n):
        for k in range(n):
            d0=depth*k/n;d1=depth*(k+1)/n
            tile([(x+i*w/n+d0,y+h+d0),(x+(i+1)*w/n+d0,y+h+d0),
                  (x+(i+1)*w/n+d1,y+h+d1),(x+i*w/n+d1,y+h+d1)],.25+.22*i/n)

def create_figure():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'pdf.fonttype':42,
       'svg.fonttype':'none','svg.hashsalt':'CMIG-V22-Figure1-classic','savefig.facecolor':'white',
       'mathtext.default':'regular'})
    fig=plt.figure(figsize=(12,8),facecolor='white')
    a=panel(fig,[.008,.533,.546,.458],'A','Patient-separated study design')
    box(a,3,46,18,24,'120\nclinical\npatients',13)
    box(a,28,67,25,15,'Prostate:\n60',13)
    box(a,28,34,25,15,'Head and neck:\n60',12.5,edge=BLUE)
    arrow(a,21,58,28,74.5);arrow(a,21,58,28,41.5)
    for y in [69,36]:
        box(a,67,y+5,29,12,'20 calibration',13,edge=BLUE,fill=PALE,dashed=True)
        box(a,67,y-12,29,12,'40 locked test',13,fill=GRAY)
        arrow(a,53,y+5.5,67,y+11);arrow(a,53,y+5.5,67,y-6)
    txt(a,3,17.7,'Five milestones: M10, M30, M50, M70, M90',12,ha='left')
    txt(a,3,11.6,'Locked test: 80 patients, 400 fractions, 4,000 landmarks',12,ha='left')
    txt(a,3,5.5,'Complete-course dose: 78 of 80 test patients',12,ha='left')

    a=panel(fig,[.566,.533,.426,.458],'B','Frozen probabilistic SVF model')
    box(a,4,77,34,12,'Planning CT',13.5);box(a,62,77,34,12,'Daily image',13.5)
    box(a,16,55,68,16,'Frozen encoder-decoder\nMean SVF and directional variance',12.5)
    arrow(a,21,77,34,71);arrow(a,79,77,66,71)
    box(a,4,36,40,11,'Mean SVF',13);box(a,56,36,40,11,'Directional variance',12.2)
    arrow(a,35,55,24,47);arrow(a,65,55,76,47)
    box(a,3,3,44,27);box(a,53,3,44,27)
    arrow(a,24,36,24,30);arrow(a,76,36,76,30)
    txt(a,25,25.6,'exp(mean SVF)',12.2)
    lattice(a,8,14.5,11,7);arrow(a,21,18,27,18,ms=8);lattice(a,29,14.5,11,7,True)
    txt(a,25,8,'Deterministic\nregistration',11.2)
    txt(a,75,25,'Sample SVFs,\nthen exp(v)',10.8)
    for xx in [58,71.5,85]:lattice(a,xx,13,7,6.4,True,lw=.55)
    txt(a,75,7,'K = 100 transformations',11)

    a=panel(fig,[.008,.048,.426,.472],'C','Patient-block geometric calibration')
    box(a,3,79,94,11,'M50 calibration: 20 patients per disease site',12.2,fill='#f7f9fb')
    box(a,4,25,42,47,edge='#9aa2aa',lw=.7)
    for x,y,ang,dx,dy in [(15,57,18,2.6,-2.2),(34,55,-15,-2.1,-1.8),(15,37,-12,-1.8,2.7),(34,38,20,2.3,2.4)]:
        a.add_patch(Ellipse((x,y),11,15,angle=ang,fill=False,edgecolor=INK,lw=.85,linestyle=(0,(3,2)),zorder=2))
        a.scatter([x],[y],s=24,color=INK,zorder=7)
        a.scatter([x+dx],[y+dy],s=26,facecolor='white',edgecolor=INK,lw=.85,zorder=7)
        arrow(a,x,y,x+dx,y+dy,lw=.7,ms=6)
    txt(a,25,68.5,'Patient block (schematic)',9.5)
    a.scatter([6.5],[20.2],s=20,color=INK,zorder=7);txt(a,10,20.2,'Prediction',10,ha='left')
    a.scatter([6.5],[14.8],s=21,facecolor='white',edgecolor=INK,lw=.8,zorder=7)
    txt(a,10,14.8,'Manual reference',10,ha='left')
    box(a,52,52,44,21,fill='#f7f9fb')
    txt(a,74,67,'Regularized landmark score',10.2)
    txt(a,74,58.6,r'$e^{T}\widetilde{C}^{-1}e\ \leq\ Q=r^{2}$',15)
    box(a,52,32,44,15,'Prostate\nQ = 11.4; r = 3.376',12.1)
    box(a,52,12,44,15,'Head and neck\nQ = 12.7; r = 3.564',12.1,edge=BLUE)
    txt(a,50,6,'Patient score = maximum landmark squared\nregularized Mahalanobis error',10.8)

    a=panel(fig,[.446,.048,.546,.472],'D','Dose sensitivity and controlled evaluation')
    box(a,3,80,94,11,'Dense empirical dispersion scale\nProstate: 1.059; head and neck: 1.102',12.6,fill='#f7f9fb')
    txt(a,50,76.5,'Scale applied before SVF exponentiation',10.5)
    for x,w,s in [(3,21,'Stochastic\ntransforms'),(28,20,'Daily dose\npull-back'),
                  (52,21,'Accumulate\nmatched course\nscenarios'),(77,20,'P05-P95\nendpoint bands')]:
        box(a,x,57,w,16,s,11.4)
    for x1,x2 in [(24,28),(48,52),(73,77)]:arrow(a,x1,65,x2,65,ms=9)
    stack(a,5,31,14,18);cube(a,30,31,13,18);cube(a,54,31,13,18)
    for x1,x2 in [(22,28),(46,52),(70,75)]:arrow(a,x1,40,x2,40,ms=9)
    x0,y0,w,h=79,31,15,21
    arrow(a,x0,y0,x0+w+1,y0,lw=.75,ms=7);arrow(a,x0,y0,x0,y0+h+1,lw=.75,ms=7)
    xx=np.linspace(0,1,100)
    for center,ls,lw in [(.40,'--',.85),(.55,'-',1.05),(.70,'--',.85)]:
        yy=1/(1+np.exp((xx-center)*12));a.plot(x0+w*xx,y0+h*yy,color=BLUE,ls=ls,lw=lw,zorder=4)
    txt(a,x0+w/2,y0-4.3,'Dose',10)
    a.text(x0-3.7,y0+h/2,'Volume',rotation=90,fontsize=10,ha='center',va='center',color=INK)
    txt(a,50,23.5,'Schematic deformation, dose and DVH illustrations',10,color='#56606a')
    box(a,3,4,46,13,'Controlled-reference containment\nand interval score',11.9)
    box(a,53,4,44,13,'Exploratory protocol-limit\nclassifications',11.9)
    arrow(a,87,57,87,53,ms=8)
    a.plot([87,87,26],[26,20,20],color=INK,lw=.8,zorder=3)
    arrow(a,26,20,26,17,lw=.8,ms=8);arrow(a,75,20,75,17,lw=.8,ms=8)
    fig.text(.012,.015,'Formal conformal coverage applies to the patient-block landmark event; dense-field and dose evaluations are empirical.',
             fontsize=12,color=INK,va='center')
    return fig

def export(output_dir):
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True);fig=create_figure()
    pdf=out/'Figure_1_Artwork.pdf';svg=out/'Figure_1_Artwork.svg'
    fig.savefig(pdf,format='pdf',metadata={'CreationDate':None,'ModDate':None,'Creator':'CMIG vector artwork'})
    fig.savefig(svg,format='svg',metadata={'Date':None,'Creator':'CMIG vector artwork'})
    doc=fitz.open(pdf);pix=doc[0].get_pixmap(dpi=1000,alpha=False)
    (out/'Figure_1_Artwork.png').write_bytes(pix.tobytes('png'))
    preview=doc[0].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
    (out/'Figure_1_Preview.png').write_bytes(preview.tobytes('png'))
    text=' '.join(doc[0].get_text().split())
    for value in ['120 clinical patients','20 calibration','40 locked test','M10, M30, M50, M70, M90',
       '80 patients, 400 fractions, 4,000 landmarks','78 of 80','K = 100','11.4','12.7','3.376','3.564',
       '1.059','1.102','before SVF exponentiation','interval score','protocol-limit','are empirical']:
        assert value in text,value
    assert '<image' not in svg.read_text()
    (out/'Figure_1_Content_Check.json').write_text(json.dumps({'all_required_labels_present':True,
       'svg_embedded_raster_images':0,'png_pixels':[pix.width,pix.height],'panels':4,
       'source':'CMIG V22 active Figure 1, Methods and caption',
       'illustration_scope':'Landmarks, grids, dose cubes and DVH curves are schematic.'},indent=2)+'\n')
    plt.close(fig);print('Exported Figure 1: vector PDF, editable SVG, 1000-dpi PNG and preview.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output-dir',type=Path,required=True)
    export(p.parse_args().output_dir)

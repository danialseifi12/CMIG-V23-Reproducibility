# Governance and provenance

SAP v1.0 was finalized on 05 May 2024. The retained study record documents patient partition and analysis freeze on 27 May 2024, final locked analysis objects and deterministic seeds during 27–29 May 2024, and first governed locked-test outcome access on 20 June 2024. Confirmatory Gates 1–5 were executed thereafter in the specified order.

The submission includes an study-team-confirmed journal copy of the SAP v1.0 protocol specification. The electronic journal-copy file is a current submission artifact rather than a filesystem-timestamp proof of the 2024 freeze. Institutional source records remain the historical provenance source and may be provided to the editor under the applicable governance process.

The journal reproducibility package separates canonical analysis rows from added provenance/enrichment files. `locked_test_fractions.csv` and `source_pairs.csv` are the canonical row-level statistical sources. Scenario-level pooled-width fitting is independently reproduced from the supplied 72 width inputs and executable bisection. No locked-test threshold, event definition, denominator, canonical endpoint allocation, or confirmatory gate order was changed during 2026 verification and package preparation.


Current author confirmation and Gate 5 inference scope are documented in the archive-level source index and study analysis plan. The C−WM containment bootstrap holds archived coverage labels fixed and does not refit lambda_width or regenerate comparator endpoints; separate width-coefficient replicates do not enter this contrast.

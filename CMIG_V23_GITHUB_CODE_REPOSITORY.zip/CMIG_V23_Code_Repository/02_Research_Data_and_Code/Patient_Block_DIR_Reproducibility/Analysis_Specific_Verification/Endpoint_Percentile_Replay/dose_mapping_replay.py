#!/usr/bin/env python3
"""
Endpoint-layer model-output -> absolute mapped-dose replay.

This is the derived endpoint replay contract:
    mapped_dose_gy = dose_center_gy + endpoint_sensitivity_gy_per_z * model_output_z

The 100 model_output_z values are deterministic scenario outputs.  P05/P95 use
NumPy linear percentiles.  The same five-fraction cumulative-dose convention is
used for reference and both scenario methods.  gamma_disp is metadata describing
the prespecified SVF dispersion scale (1.059 prostate, 1.102 head-and-neck);
nonlinear image/SVF warping has already been collapsed into the endpoint-specific
center and sensitivity in this replay layer.
"""
from __future__ import annotations

def model_output_to_absolute_dose(model_output_z: float,
                                  dose_center_gy: float,
                                  endpoint_sensitivity_gy_per_z: float) -> float:
    return dose_center_gy + endpoint_sensitivity_gy_per_z * model_output_z

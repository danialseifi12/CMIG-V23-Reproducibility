# Data and analysis provenance

## Calibration threshold grid

The verified Fold 4 source-data correction gives sensitivity 0.750 at thresholds 0.40, 0.45, and 0.50 and 0.500 at thresholds 0.55, 0.60, and 0.65, with corresponding NPV values 0.938, 0.958, 0.964, 0.939, 0.943, and 0.944. Global selection is **not** defined by minimizing review rate separately inside each fold. A candidate must satisfy sensitivity >=0.75 and NPV >=0.95 in every fold; among candidates feasible in all five folds, the mean cross-fold review rate is minimized. Thresholds 0.35, 0.45, and 0.50 are feasible in all five folds, with mean review rates 0.630, 0.440, and 0.355; therefore 0.50 remains the globally selected operating point.

## Interval-score provenance

The retained source-pair interval-score fields correspond to uncalibrated and dispersion-calibrated scenarios. The source-bootstrap `Interval_Diff_C_minus_U` column is dispersion-calibrated minus uncalibrated. The reviewer-facing archive does not retain a width-matched interval-score value, so the submitted package does not make a matched-width interval-score claim.

## Pooled Gate 3 intervals

Main-text Table 4 cell intervals are descriptive exact fraction-level intervals. Patient-cluster inferential bounds for pooled sensitivity and NPV are reported separately in the table caption and text.

## Development-overlap wording

The development archive was closed before final clinical cohort locking. Identifier cross-checking found 12 screened patients represented in that archive; all 12 were excluded before cohort locking, leaving no development/calibration/test patient overlap.

Version 22 addition: the investigator-supplied final longitudinal analysis table, model formulas, full software refit summaries and four-test Holm table are included. The intermediate historical U/WM NPZ arrays, separate small Torch replay checkpoint, inputs and generator are included; this is distinct from the original clinical weights and native implementation. See the repository README for scope and exact execution commands.

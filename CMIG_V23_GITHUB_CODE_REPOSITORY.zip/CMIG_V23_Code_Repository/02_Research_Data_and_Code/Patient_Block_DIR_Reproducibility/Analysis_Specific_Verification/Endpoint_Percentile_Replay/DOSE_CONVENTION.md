# Endpoint percentile replay

The `endpoint_scenarios_432x100_both_methods.csv` table supports a deterministic percentile replay (432 endpoint identities × 2 methods × 100 endpoint values). The script `verify_endpoint_replay.py` tests P05 and P95 under the specified linear empirical percentile convention. It does not produce the original native SVF, image-registration, dose warp or QC outputs. The absolute-dose coordinates in this table belong to the score analysis and must not be substituted for `Dose_Constraint_Decision_Analysis/Controlled_432.csv` protocol-limit calculations.


## Endpoint-local sample indices

Scenario_No runs from 1 through 100 separately within each endpoint/method group. These are marginal endpoint-wise replay arrays. Equal sample numbers across endpoints are not identifiers of a shared joint DVH realization. Use the arrays to verify P05/P95 for each endpoint, not to recover native cross-endpoint scenario correspondence. The file supplies only Uncalibrated and DispersionCalibrated samples, not WidthMatched samples.
